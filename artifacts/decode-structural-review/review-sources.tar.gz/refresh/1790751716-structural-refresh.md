# Engine benchmark `structural-refresh`

- model `/home/socol/models/qwen3.5-0.8b/Qwen3.5-0.8B-Q8_0.gguf` (sha256 `37ae482d336108d23516fa35e8e0c4126688d81018b87178a18d752a1357814f`)
- prompt ids `/home/socol/Workspace/apeiron/tests/fixtures/qwen35-prompt2.ids` (sha256 `894a166ae31393f33425ed7d1fd0b3eed0801c26a3c7095d90825d66fb240443`), pp 200, tg 64, 5 rounds
- git `e33977aa72534ad56775110be99cf002ca96fa37` with 49 dirty paths; src sha256 `46a5b1746eb7cc87bbf6c7f2da2087f3e732111261d815b0a8377fd6eb95170f`
- Intel(R) Core(TM) i9-14900KF; governor powersave; 32 CPUs; rustc 1.97.0-nightly (17584a181 2026-04-13)
- read ceiling (1 GiB sum, best of 3): 77.4 / 86.3 / 91.1 GB/s at 8 / 16 / 32 threads
- llama.cpp `0324696b8`, threads 8,16,24,32
- quiet gate busy < 0.05: every round passed

| metric (tok/s) | median | min | max |
|---|---:|---:|---:|
| apeiron pp | 366.70 | 29.33 | 392.04 |
| llama.cpp pp (best threads) | 559.49 | 499.07 | 578.10 |
| ratio pp (per round) | 0.64 | 0.06 | 0.72 |
| apeiron tg | 77.30 | 4.06 | 79.67 |
| llama.cpp tg (best threads) | 52.74 | 49.26 | 54.69 |
| ratio tg (per round) | 1.42 | 0.08 | 1.51 |
| apeiron spec (e2e) | 57.13 | 6.46 | 59.28 |
| spec acceptance | 0.24 | 0.24 | 0.24 |
| apeiron pp busy cores | 23.56 | 7.22 | 23.62 |
| apeiron tg busy cores | 23.86 | 7.62 | 23.88 |
| mean MHz before pp | 2848.78 | 1898.64 | 4457.70 |
| mean MHz before tg | 4550.00 | 1979.95 | 4645.98 |

### Traced phases

#### pp: 200 tokens, 2.94 ms/token wall

| phase | ms/token | share of wall | calls | GB/s | GMAC/s |
|---|---:|---:|---:|---:|---:|
| embed | 0.002 | 0.1% | 5 | - | - |
| norm | 0.065 | 2.2% | 245 | - | - |
| residual | 0.052 | 1.8% | 240 | - | - |
| attn.proj_in | 0.049 | 1.7% | 30 | 17.0 | 638.4 |
| attn.core | 0.252 | 8.6% | 30 | - | - |
| attn.proj_out | 0.035 | 1.2% | 30 | 9.5 | 358.0 |
| affine.proj_in | 0.224 | 7.6% | 90 | 18.0 | 676.5 |
| affine.conv | 0.282 | 9.6% | 90 | - | - |
| affine.heads | 1.156 | 39.3% | 90 | - | - |
| affine.proj_out | 0.104 | 3.5% | 90 | 9.7 | 364.4 |
| ffn | 0.688 | 23.4% | 120 | 10.2 | 383.8 |
| head | 0.012 | 0.4% | 1 | 112.5 | 105.8 |
| untraced in pass | 0.006 | 0.2% | 0 | - | - |
| outside passes | 0.016 | 0.5% | 0 | - | - |
| pool.wait (overlay; tasks/dispatch 70.1) | 0.882 | 30.0% | 2035 | - | - |

#### tg: 64 tokens, 13.71 ms/token wall

| phase | ms/token | share of wall | calls | GB/s | GMAC/s |
|---|---:|---:|---:|---:|---:|
| embed | 0.003 | 0.0% | 64 | - | - |
| norm | 0.188 | 1.4% | 3136 | - | - |
| residual | 0.048 | 0.3% | 3072 | - | - |
| attn.proj_in | 0.633 | 4.6% | 384 | 52.8 | 49.7 |
| attn.core | 0.468 | 3.4% | 384 | - | - |
| attn.proj_out | 0.216 | 1.6% | 384 | 62.0 | 58.3 |
| affine.proj_in | 2.843 | 20.7% | 1152 | 56.6 | 53.3 |
| affine.conv | 0.690 | 5.0% | 1152 | - | - |
| affine.heads | 1.490 | 10.9% | 1152 | - | - |
| affine.proj_out | 0.638 | 4.6% | 1152 | 62.9 | 59.2 |
| ffn | 4.049 | 29.5% | 1536 | 69.3 | 65.3 |
| head | 2.411 | 17.6% | 64 | 112.0 | 105.4 |
| untraced in pass | 0.036 | 0.3% | 0 | - | - |
| outside passes | 0.001 | 0.0% | 0 | - | - |
| pool.wait (overlay; tasks/dispatch 42.3) | 2.525 | 18.4% | 17856 | - | - |

#### spec: 64 tokens, 20.41 ms/token wall

| phase | ms/token | share of wall | calls | GB/s | GMAC/s |
|---|---:|---:|---:|---:|---:|
| embed | 0.003 | 0.0% | 52 | - | - |
| norm | 0.247 | 1.2% | 2548 | - | - |
| residual | 0.087 | 0.4% | 2496 | - | - |
| attn.proj_in | 0.671 | 3.3% | 364 | 47.2 | 83.3 |
| attn.core | 0.437 | 2.1% | 364 | - | - |
| attn.proj_out | 0.349 | 1.7% | 364 | 36.3 | 64.0 |
| affine.proj_in | 2.559 | 12.5% | 936 | 51.1 | 95.3 |
| affine.conv | 0.919 | 4.5% | 936 | - | - |
| affine.heads | 2.297 | 11.3% | 936 | - | - |
| affine.proj_out | 0.898 | 4.4% | 936 | 36.3 | 67.7 |
| ffn | 5.499 | 26.9% | 1300 | 43.2 | 79.3 |
| head | 4.442 | 21.8% | 103 | 55.8 | 98.1 |
| restore | 1.690 | 8.3% | 39 | - | - |
| untraced in pass | 0.145 | 0.7% | 0 | - | - |
| outside passes | 0.167 | 0.8% | 0 | - | - |
| pool.wait (overlay; tasks/dispatch 84.5) | 4.871 | 23.9% | 23657 | - | - |
