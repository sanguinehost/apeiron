//! webfold lift — JS/WASM → Term universalLift decoder.
//!
//! UniversalEncoding.lean: every surface (JS source, WASM bytecode) is `List α →
//! universalLift → Term → fromTerm(substrate)`. There is one ingestion, no per-format
//! parser — the opcodes ARE the alphabet α, mapped to the Term algebra.
//!
//! HashTrinity faces:
//!   NB (Set)     = reserved keywords (presence check for identifier disambiguation)
//!   B  (Map)     = scope: name → de Bruijn index (replace on entry)
//!   Stream buffer                = JS expression sequence → combinator composition chain
//!   4th (Graph)  = AST adjacency (parent/child in parsing), consumed by lift

use crate::substrate::{PrimOp, Term};

const DOM_SEP: &str = "\x1f";

// ─────────────────────────────────────────────────────────────────────────────
// §1. JS LEXER — zero-dependency tokenizer (same style as lib.rs HTML parser)
// ─────────────────────────────────────────────────────────────────────────────

#[derive(Debug, Clone, PartialEq)]
pub enum Token {
    // Literals
    Number(i64),
    String(String),
    Template(String), // template literal parts
    Ident(String),
    Keyword(String), // let, const, var, function, return, if, else, for, while, typeof
    // Punctuation
    OpenParen,
    CloseParen,
    OpenBrace,
    CloseBrace,
    OpenBracket,
    CloseBracket,
    Semi,
    Comma,
    Dot,
    QuestionDot, // ?.
    Colon,
    Question, // ?
    Arrow,
    // Operators
    Plus,
    Minus,
    Star,
    Slash,
    Percent,
    Eq,
    EqEq,
    EqEqEq,
    NotEq,
    NotEqEq,
    Lt,
    Gt,
    LtEq,
    GtEq,
    AndAnd,
    OrOr,
    Not,
    Assign, // =
    // Special
    FatArrow, // =>
    // End of input
    Eof,
}

fn is_js_ident_start(c: u8) -> bool {
    c.is_ascii_alphabetic() || c == b'_' || c == b'$'
}

fn is_js_ident_continue(c: u8) -> bool {
    c.is_ascii_alphanumeric() || c == b'_' || c == b'$'
}

/// Single-byte punctuation/operators with no lookahead.
fn single_byte_token(c: u8) -> Option<Token> {
    Some(match c {
        b'(' => Token::OpenParen,
        b')' => Token::CloseParen,
        b'{' => Token::OpenBrace,
        b'}' => Token::CloseBrace,
        b'[' => Token::OpenBracket,
        b']' => Token::CloseBracket,
        b';' => Token::Semi,
        b',' => Token::Comma,
        b'.' => Token::Dot,
        b':' => Token::Colon,
        b'+' => Token::Plus,
        b'*' => Token::Star,
        b'/' => Token::Slash,
        b'%' => Token::Percent,
        _ => return None,
    })
}

struct Lexer<'a> {
    src: &'a [u8],
    pos: usize,
}

impl<'a> Lexer<'a> {
    fn new(src: &'a str) -> Self {
        Self {
            src: src.as_bytes(),
            pos: 0,
        }
    }

    fn peek(&self) -> Option<u8> {
        self.src.get(self.pos).copied()
    }

    fn bump(&mut self) {
        if self.pos < self.src.len() {
            self.pos += 1;
        }
    }

    fn skip_whitespace(&mut self) {
        while let Some(c) = self.peek() {
            if c == b'/' && self.src.get(self.pos + 1) == Some(&b'/') {
                // Line comment
                while let Some(c) = self.peek() {
                    if c == b'\n' {
                        break;
                    }
                    self.bump();
                }
            } else if c == b'/' && self.src.get(self.pos + 1) == Some(&b'*') {
                // Block comment
                self.bump();
                self.bump();
                while let Some(c) = self.peek() {
                    if c == b'*' && self.src.get(self.pos + 1) == Some(&b'/') {
                        self.bump();
                        self.bump();
                        break;
                    }
                    self.bump();
                }
            } else if c.is_ascii_whitespace() {
                self.bump();
            } else {
                break;
            }
        }
    }

    fn scan_number(&mut self, first: u8) -> i64 {
        let mut n = (first - b'0') as i64;
        self.bump(); // consume the first digit
        while let Some(c) = self.peek() {
            if c.is_ascii_digit() {
                n = n * 10 + (c - b'0') as i64;
                self.bump();
            } else {
                break;
            }
        }
        n
    }

    fn scan_string(&mut self, q: u8) -> String {
        self.bump(); // skip opening quote
        let mut s = String::new();
        loop {
            match self.peek() {
                None | Some(b'\n') => break,
                Some(c) if c == q => {
                    self.bump();
                    break;
                }
                Some(b'\\') => {
                    self.bump();
                    match self.peek() {
                        Some(b'n') => s.push('\n'),
                        Some(b't') => s.push('\t'),
                        Some(b'r') => s.push('\r'),
                        Some(b'"') => s.push('"'),
                        Some(b'\'') => s.push('\''),
                        Some(b'\\') => s.push('\\'),
                        Some(b'u') => {
                            // \uXXXX — simplified; real impl parses hex
                            for _ in 0..4 {
                                self.bump();
                            }
                        }
                        Some(c) => s.push(c as char),
                        None => break,
                    }
                    self.bump();
                }
                Some(c) => {
                    s.push(c as char);
                    self.bump();
                }
            }
        }
        s
    }

    fn scan_ident(&mut self) -> String {
        let start = self.pos;
        while let Some(c) = self.peek() {
            if is_js_ident_continue(c) {
                self.bump();
            } else {
                break;
            }
        }
        std::str::from_utf8(&self.src[start..self.pos])
            .unwrap()
            .to_string()
    }

    fn next_token(&mut self) -> Token {
        self.skip_whitespace();
        let c = match self.peek() {
            None => return Token::Eof,
            Some(c) => c,
        };
        if let Some(tok) = single_byte_token(c) {
            self.bump();
            return tok;
        }
        match c {
            b'0'..=b'9' => {
                let n = self.scan_number(c);
                Token::Number(n)
            }
            b'"' | b'\'' => {
                let s = self.scan_string(c);
                Token::String(s)
            }
            b'-' => {
                self.bump();
                if self.peek() == Some(b'>') {
                    self.bump();
                    Token::FatArrow
                } else {
                    Token::Minus
                }
            }
            b'*' => {
                self.bump();
                Token::Star
            }
            b'/' => {
                self.bump();
                Token::Slash
            }
            b'%' => {
                self.bump();
                Token::Percent
            }
            b'!' => {
                self.bump();
                if self.peek() == Some(b'=') {
                    self.bump();
                    if self.peek() == Some(b'=') {
                        self.bump();
                        Token::NotEqEq
                    } else {
                        Token::NotEq
                    }
                } else {
                    Token::Not
                }
            }
            b'=' => {
                self.bump();
                if self.peek() == Some(b'=') {
                    self.bump();
                    if self.peek() == Some(b'=') {
                        self.bump();
                        Token::EqEqEq
                    } else {
                        Token::EqEq
                    }
                } else if self.peek() == Some(b'>') {
                    self.bump();
                    Token::FatArrow
                } else {
                    Token::Assign
                }
            }
            b'<' => {
                self.bump();
                if self.peek() == Some(b'=') {
                    self.bump();
                    Token::LtEq
                } else {
                    Token::Lt
                }
            }
            b'>' => {
                self.bump();
                if self.peek() == Some(b'=') {
                    self.bump();
                    Token::GtEq
                } else {
                    Token::Gt
                }
            }
            b'&' => {
                self.bump();
                if self.peek() == Some(b'&') {
                    self.bump();
                    Token::AndAnd
                } else {
                    Token::Eof
                } // bitwise not used
            }
            b'|' => {
                self.bump();
                if self.peek() == Some(b'|') {
                    self.bump();
                    Token::OrOr
                } else {
                    Token::Eof
                }
            }
            b'`' => {
                self.bump();
                let mut s = String::new();
                while let Some(c) = self.peek() {
                    if c == b'`' {
                        self.bump();
                        break;
                    }
                    s.push(c as char);
                    self.bump();
                }
                Token::Template(s)
            }
            b'?' => {
                self.bump();
                if self.peek() == Some(b'.') {
                    self.bump();
                    Token::QuestionDot
                } else if self.peek() == Some(b'?') {
                    self.bump();
                    // nullish coalescing — treat as question for now
                    Token::Question
                } else {
                    Token::Question
                }
            }
            _ if is_js_ident_start(c) => {
                let ident = self.scan_ident();
                match ident.as_str() {
                    "let" | "const" | "var" | "function" | "return" | "if" | "else" | "for"
                    | "while" | "new" | "this" | "true" | "false" | "null" | "undefined"
                    | "typeof" => Token::Keyword(ident),
                    _ => Token::Ident(ident),
                }
            }
            _ => {
                self.bump();
                Token::Eof
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// §2. JS AST — minimal node types for the JS subset we lift
// ─────────────────────────────────────────────────────────────────────────────

#[derive(Debug, Clone)]
pub enum JsExpr {
    Num(i64),
    Str(String),
    Bool(bool),
    Null,
    Ident(String),
    This,
    // a.b
    Member {
        object: Box<JsExpr>,
        property: String,
        optional: bool, // true if via ?.
    },
    // a[b]
    Index {
        object: Box<JsExpr>,
        index: Box<JsExpr>,
        optional: bool,
    },
    // a?.b or a?.(b) — optional chain
    Optional {
        expr: Box<JsExpr>,
    },
    // f(a, b, c)
    Call {
        callee: Box<JsExpr>,
        args: Vec<JsExpr>,
        optional: bool, // true if via ?.()
    },
    // a + b, etc.
    BinOp {
        op: BinOp,
        left: Box<JsExpr>,
        right: Box<JsExpr>,
    },
    // !a, -a, typeof a
    Unary {
        op: UnaryOp,
        arg: Box<JsExpr>,
    },
    // a ? b : c
    Ternary {
        test: Box<JsExpr>,
        consequent: Box<JsExpr>,
        alternate: Box<JsExpr>,
    },
    // a = b
    Assign {
        target: Box<JsExpr>,
        value: Box<JsExpr>,
    },
    // { k: v, ... }
    Object(Vec<(String, JsExpr)>),
    // [a, b, c]
    Array(Vec<JsExpr>),
    // function(x, y) { body }
    Function {
        params: Vec<String>,
        body: Vec<JsStmt>,
    },
    // (params) => expr
    ArrowFunction {
        params: Vec<String>,
        body: Box<JsExpr>,
    },
    // (expr)
    Group(Box<JsExpr>),
    // a `{ stmt; … }` block body (arrow/function block) — statements, eval'd in order.
    Block(Vec<JsStmt>),
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum BinOp {
    Add,
    Sub,
    Mul,
    Div,
    Rem,
    Eq,
    EqStrict,
    Neq,
    NeqStrict,
    Lt,
    Gt,
    LtEq,
    GtEq,
    And,
    Or,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum UnaryOp {
    Neg,
    Not,
    TypeOf,
}

#[derive(Debug, Clone)]
pub enum JsStmt {
    Expr(JsExpr),
    Block(Vec<JsStmt>),
    Var {
        name: String,
        init: Option<JsExpr>,
    },
    Return(Option<JsExpr>),
    If {
        test: JsExpr,
        consequent: Box<JsStmt>,
        alternate: Option<Box<JsStmt>>,
    },
    For {
        init: Box<JsStmt>,
        test: JsExpr,
        update: JsExpr,
        body: Box<JsStmt>,
    },
    While {
        test: JsExpr,
        body: Box<JsStmt>,
    },
    Assign {
        target: JsExpr,
        value: JsExpr,
    },
}

// ─────────────────────────────────────────────────────────────────────────────
// §3. JS PARSER — recursive descent, same style as the streaming HTML pass
// ─────────────────────────────────────────────────────────────────────────────

struct Parser<'a> {
    lexer: Lexer<'a>,
    tok: Token,
    error: Option<String>,
}

impl<'a> Parser<'a> {
    fn new(src: &'a str) -> Self {
        let mut p = Self {
            lexer: Lexer::new(src),
            tok: Token::Eof,
            error: None,
        };
        p.advance();
        p
    }

    fn advance(&mut self) {
        self.tok = self.lexer.next_token();
    }

    fn expect(&mut self, expected: &Token) -> Result<(), String> {
        if std::mem::discriminant(&self.tok) == std::mem::discriminant(expected) {
            self.advance();
            Ok(())
        } else {
            let error = format!("expected {:?}, got {:?}", expected, self.tok);
            self.error.get_or_insert_with(|| error.clone());
            Err(error)
        }
    }

    fn eat(&mut self, expected: &Token) -> bool {
        if std::mem::discriminant(&self.tok) == std::mem::discriminant(expected) {
            self.advance();
            true
        } else {
            false
        }
    }

    /// Left-associative binary operator fold.
    /// `ops` lists the operator tokens that cancel into the same shape; `next`
    /// is the next precedence level. One combinator replaces the repeated
    /// `parse left; loop { match self.tok { A => ..., B => ... } }` rotor.
    fn parse_left_assoc(
        &mut self,
        ops: &[(Token, BinOp)],
        next: fn(&mut Self) -> JsExpr,
    ) -> JsExpr {
        let mut left = next(self);
        loop {
            let op = ops.iter().find_map(|(t, op)| {
                if std::mem::discriminant(&self.tok) == std::mem::discriminant(t) {
                    Some(*op)
                } else {
                    None
                }
            });
            match op {
                Some(op) => {
                    self.advance();
                    let right = next(self);
                    left = JsExpr::BinOp {
                        op,
                        left: Box::new(left),
                        right: Box::new(right),
                    };
                }
                None => break,
            }
        }
        left
    }

    fn peek_keyword(&self, kw: &str) -> bool {
        matches!(&self.tok, Token::Keyword(k) if k == kw)
    }

    fn parse_program(&mut self) -> Vec<JsStmt> {
        let mut stmts = Vec::new();
        while !matches!(self.tok, Token::Eof | Token::CloseBrace) {
            stmts.push(self.parse_stmt());
        }
        stmts
    }

    /// Parse an arrow body: a `{ … }` statement block (so inner `const`/`return` work) or a
    /// bare expression. This is the fix that lets block-bodied arrows (Playwright's
    /// InjectedScript) reduce instead of misparsing the block as an object literal.
    fn parse_arrow_body(&mut self) -> JsExpr {
        if matches!(self.tok, Token::OpenBrace) {
            self.advance(); // consume `{`
            let mut stmts = Vec::new();
            while !matches!(self.tok, Token::CloseBrace | Token::Eof) {
                stmts.push(self.parse_stmt());
            }
            self.expect(&Token::CloseBrace).ok();
            JsExpr::Block(stmts)
        } else {
            self.parse_expr()
        }
    }

    /// Parse a `{ a, b: rename, c }` object-destructure param into the `"{a,b:rename,c}"` form
    /// `eval_arrow` projects (binding `rename = arg.b`). The `:` rename is the shape Playwright's
    /// InjectedScript uses (`{ info, callbackText: callbackText2, … }`).
    fn parse_destructure(&mut self) -> String {
        self.advance(); // consume `{`
        let mut fields = Vec::new();
        while let Token::Ident(key) = &self.tok {
            let key = key.clone();
            self.advance();
            let entry = if self.eat(&Token::Colon) {
                if let Token::Ident(local) = &self.tok {
                    let l = local.clone();
                    self.advance();
                    format!("{key}:{l}")
                } else {
                    key
                }
            } else {
                key
            };
            fields.push(entry);
            if !self.eat(&Token::Comma) {
                break;
            }
        }
        self.expect(&Token::CloseBrace).ok();
        format!("{{{}}}", fields.join(","))
    }

    fn parse_stmt(&mut self) -> JsStmt {
        match &self.tok {
            Token::Keyword(k) if k == "let" || k == "const" || k == "var" => self.parse_var_stmt(),
            Token::Keyword(k) if k == "return" => {
                self.advance();
                if matches!(self.tok, Token::Semi | Token::CloseBrace) {
                    JsStmt::Return(None)
                } else {
                    let expr = self.parse_expr();
                    JsStmt::Return(Some(expr))
                }
            }
            Token::Keyword(k) if k == "if" => self.parse_if_stmt(),
            Token::Keyword(k) if k == "for" => self.parse_for_stmt(),
            Token::Keyword(k) if k == "while" => self.parse_while_stmt(),
            Token::OpenBrace => {
                self.advance();
                let body = self.parse_program();
                self.expect(&Token::CloseBrace).ok();
                JsStmt::Block(body)
            }
            _ => {
                let expr = self.parse_expr();
                JsStmt::Expr(expr)
            }
        }
    }

    fn parse_var_stmt(&mut self) -> JsStmt {
        self.advance(); // let/const/var
        let name = match &self.tok {
            Token::Ident(s) => {
                let n = s.clone();
                self.advance();
                n
            }
            _ => return JsStmt::Expr(JsExpr::Null),
        };
        let init = if self.eat(&Token::Assign) {
            Some(self.parse_expr())
        } else {
            None
        };
        JsStmt::Var { name, init }
    }

    fn parse_if_stmt(&mut self) -> JsStmt {
        self.advance(); // if
        self.expect(&Token::OpenParen).ok();
        let test = self.parse_expr();
        self.expect(&Token::CloseParen).ok();
        let consequent = Box::new(self.parse_stmt());
        let alternate = if self.peek_keyword("else") {
            self.advance();
            Some(Box::new(self.parse_stmt()))
        } else {
            None
        };
        JsStmt::If {
            test,
            consequent,
            alternate,
        }
    }

    fn parse_for_stmt(&mut self) -> JsStmt {
        self.advance(); // for
        self.expect(&Token::OpenParen).ok();
        let init = Box::new(
            if matches!(&self.tok, Token::Keyword(k) if k == "let" || k == "var") {
                self.parse_var_stmt()
            } else {
                let expr = self.parse_expr();
                JsStmt::Expr(expr)
            },
        );
        let test = if matches!(self.tok, Token::Semi) {
            JsExpr::Bool(true)
        } else {
            self.parse_expr()
        };
        self.expect(&Token::Semi).ok();
        let update = if matches!(self.tok, Token::CloseParen) {
            JsExpr::Null
        } else {
            self.parse_expr()
        };
        self.expect(&Token::CloseParen).ok();
        let body = Box::new(self.parse_stmt());
        JsStmt::For {
            init,
            test,
            update,
            body,
        }
    }

    fn parse_while_stmt(&mut self) -> JsStmt {
        self.advance(); // while
        self.expect(&Token::OpenParen).ok();
        let test = self.parse_expr();
        self.expect(&Token::CloseParen).ok();
        let body = Box::new(self.parse_stmt());
        JsStmt::While { test, body }
    }

    // ── Expression parsing (precedence climbing) ──

    fn parse_expr(&mut self) -> JsExpr {
        self.parse_assignment()
    }

    fn parse_assignment(&mut self) -> JsExpr {
        let left = self.parse_ternary();
        if self.eat(&Token::Assign) {
            let right = self.parse_expr();
            JsExpr::Assign {
                target: Box::new(left),
                value: Box::new(right),
            }
        } else {
            left
        }
    }

    fn parse_ternary(&mut self) -> JsExpr {
        let test = self.parse_or();
        if self.eat(&Token::Question) {
            let consequent = self.parse_expr();
            self.expect(&Token::Colon).ok();
            let alternate = self.parse_expr();
            JsExpr::Ternary {
                test: Box::new(test),
                consequent: Box::new(consequent),
                alternate: Box::new(alternate),
            }
        } else {
            test
        }
    }

    fn parse_or(&mut self) -> JsExpr {
        self.parse_left_assoc(&[(Token::OrOr, BinOp::Or)], Self::parse_and)
    }

    fn parse_and(&mut self) -> JsExpr {
        self.parse_left_assoc(&[(Token::AndAnd, BinOp::And)], Self::parse_equality)
    }

    fn parse_equality(&mut self) -> JsExpr {
        self.parse_left_assoc(
            &[
                (Token::EqEq, BinOp::Eq),
                (Token::EqEqEq, BinOp::Eq),
                (Token::NotEq, BinOp::Neq),
                (Token::NotEqEq, BinOp::Neq),
            ],
            Self::parse_relational,
        )
    }

    fn parse_relational(&mut self) -> JsExpr {
        self.parse_left_assoc(
            &[
                (Token::Lt, BinOp::Lt),
                (Token::Gt, BinOp::Gt),
                (Token::LtEq, BinOp::LtEq),
                (Token::GtEq, BinOp::GtEq),
            ],
            Self::parse_additive,
        )
    }

    fn parse_additive(&mut self) -> JsExpr {
        self.parse_left_assoc(
            &[(Token::Plus, BinOp::Add), (Token::Minus, BinOp::Sub)],
            Self::parse_multiplicative,
        )
    }

    fn parse_multiplicative(&mut self) -> JsExpr {
        self.parse_left_assoc(
            &[(Token::Star, BinOp::Mul), (Token::Slash, BinOp::Div)],
            Self::parse_unary,
        )
    }

    fn parse_unary(&mut self) -> JsExpr {
        if self.eat(&Token::Minus) {
            let arg = self.parse_unary();
            JsExpr::Unary {
                op: UnaryOp::Neg,
                arg: Box::new(arg),
            }
        } else if self.eat(&Token::Not) {
            let arg = self.parse_unary();
            JsExpr::Unary {
                op: UnaryOp::Not,
                arg: Box::new(arg),
            }
        } else if self.peek_keyword("typeof") {
            self.advance();
            let arg = self.parse_unary();
            JsExpr::Unary {
                op: UnaryOp::TypeOf,
                arg: Box::new(arg),
            }
        } else {
            self.parse_postfix()
        }
    }

    fn parse_postfix(&mut self) -> JsExpr {
        let mut expr = self.parse_primary();
        loop {
            if self.eat(&Token::Dot) {
                if let Token::Ident(prop) = &self.tok {
                    let p = prop.clone();
                    self.advance();
                    expr = JsExpr::Member {
                        object: Box::new(expr),
                        property: p,
                        optional: false,
                    };
                } else {
                    break;
                }
            } else if self.eat(&Token::QuestionDot) {
                // Optional chaining: a?.b or a?.(args)
                if let Token::Ident(prop) = &self.tok {
                    let p = prop.clone();
                    self.advance();
                    expr = JsExpr::Member {
                        object: Box::new(expr),
                        property: p,
                        optional: true,
                    };
                } else if self.eat(&Token::OpenParen) {
                    let mut args = Vec::new();
                    if !matches!(self.tok, Token::CloseParen) {
                        args.push(self.parse_expr());
                        while self.eat(&Token::Comma) {
                            args.push(self.parse_expr());
                        }
                    }
                    self.expect(&Token::CloseParen).ok();
                    expr = JsExpr::Call {
                        callee: Box::new(expr),
                        args,
                        optional: true,
                    };
                } else {
                    break;
                }
            } else if self.eat(&Token::OpenBracket) {
                let index = self.parse_expr();
                self.expect(&Token::CloseBracket).ok();
                expr = JsExpr::Index {
                    object: Box::new(expr),
                    index: Box::new(index),
                    optional: false,
                };
            } else if self.eat(&Token::OpenParen) {
                let mut args = Vec::new();
                if !matches!(self.tok, Token::CloseParen) {
                    args.push(self.parse_expr());
                    while self.eat(&Token::Comma) {
                        args.push(self.parse_expr());
                    }
                }
                self.expect(&Token::CloseParen).ok();
                expr = JsExpr::Call {
                    callee: Box::new(expr),
                    args,
                    optional: false,
                };
            } else {
                break;
            }
        }
        expr
    }

    fn parse_primary(&mut self) -> JsExpr {
        // `new X(args)` — the constructor IS the application (translation is application). Drop
        // `new`; the following primary + its call postfix is the constructed value.
        if matches!(&self.tok, Token::Ident(s) if s == "new") {
            self.advance();
            return self.parse_primary();
        }
        match &self.tok {
            Token::Number(n) => {
                let v = *n;
                self.advance();
                JsExpr::Num(v)
            }
            Token::String(s) => {
                let v = s.clone();
                self.advance();
                JsExpr::Str(v)
            }
            // a template literal `…${…}…` — treated as its raw string (a log message in the
            // InjectedScript; its value isn't load-bearing for the resolve result).
            Token::Template(s) => {
                let v = s.clone();
                self.advance();
                JsExpr::Str(v)
            }
            Token::Ident(s) => {
                let v = s.clone();
                self.advance();
                JsExpr::Ident(v)
            }
            Token::Keyword(k) => match k.as_str() {
                "true" => {
                    self.advance();
                    JsExpr::Bool(true)
                }
                "false" => {
                    self.advance();
                    JsExpr::Bool(false)
                }
                "null" | "undefined" => {
                    self.advance();
                    JsExpr::Null
                }
                "this" => {
                    self.advance();
                    JsExpr::This
                }
                "function" => self.parse_function(),
                _ => {
                    self.advance();
                    JsExpr::Null
                }
            },
            Token::OpenParen => {
                self.advance();
                // Check for fat arrow: (x, y) => expr
                if matches!(self.tok, Token::CloseParen) {
                    self.advance();
                    if self.eat(&Token::FatArrow) {
                        return JsExpr::ArrowFunction {
                            params: vec![],
                            body: Box::new(self.parse_arrow_body()),
                        };
                    }
                    return JsExpr::Group(Box::new(JsExpr::Null));
                }
                let first = self.parse_expr();
                if self.eat(&Token::Comma) {
                    // multi-param arrow: (a, b, {c}) => …
                    let mut params = vec![];
                    if let JsExpr::Ident(name) = &first {
                        params.push(name.clone());
                    }
                    loop {
                        match &self.tok {
                            Token::Ident(s) => {
                                params.push(s.clone());
                                self.advance();
                            }
                            Token::OpenBrace => {
                                params.push(self.parse_destructure());
                            }
                            _ => break,
                        }
                        if !self.eat(&Token::Comma) {
                            break;
                        }
                    }
                    self.expect(&Token::CloseParen).ok(); // consume `)` before the `=>`
                    if self.eat(&Token::FatArrow) {
                        return JsExpr::ArrowFunction {
                            params,
                            body: Box::new(self.parse_arrow_body()),
                        };
                    }
                    JsExpr::Group(Box::new(first))
                } else if matches!(self.tok, Token::CloseParen) {
                    // `(x) => …` or just `(x)` grouping — consume `)`, then check for `=>`.
                    self.advance();
                    if self.eat(&Token::FatArrow) {
                        let params = if let JsExpr::Ident(name) = &first {
                            vec![name.clone()]
                        } else {
                            vec![]
                        };
                        return JsExpr::ArrowFunction {
                            params,
                            body: Box::new(self.parse_arrow_body()),
                        };
                    }
                    JsExpr::Group(Box::new(first))
                } else if self.eat(&Token::FatArrow) {
                    let params = if let JsExpr::Ident(name) = &first {
                        vec![name.clone()]
                    } else {
                        vec![]
                    };
                    JsExpr::ArrowFunction {
                        params,
                        body: Box::new(self.parse_arrow_body()),
                    }
                } else {
                    self.expect(&Token::CloseParen).ok();
                    JsExpr::Group(Box::new(first))
                }
            }
            Token::OpenBrace => {
                self.advance();
                let mut props = Vec::new();
                while !matches!(self.tok, Token::CloseBrace) {
                    if let Token::Ident(key) = &self.tok {
                        let k = key.clone();
                        self.advance();
                        self.expect(&Token::Colon).ok();
                        let val = self.parse_expr();
                        props.push((k, val));
                        self.eat(&Token::Comma);
                    } else if let Token::String(s) = &self.tok {
                        let k = s.clone();
                        self.advance();
                        self.expect(&Token::Colon).ok();
                        let val = self.parse_expr();
                        props.push((k, val));
                        self.eat(&Token::Comma);
                    } else {
                        break;
                    }
                }
                self.expect(&Token::CloseBrace).ok();
                JsExpr::Object(props)
            }
            Token::OpenBracket => {
                self.advance();
                let mut elems = Vec::new();
                while !matches!(self.tok, Token::CloseBracket | Token::Eof) {
                    elems.push(self.parse_expr());
                    self.eat(&Token::Comma);
                }
                self.expect(&Token::CloseBracket).ok();
                JsExpr::Array(elems)
            }
            _ => {
                self.advance();
                JsExpr::Null
            }
        }
    }

    fn parse_function(&mut self) -> JsExpr {
        self.advance(); // function
        let name = if let Token::Ident(s) = &self.tok {
            let n = s.clone();
            self.advance();
            Some(n)
        } else {
            None
        };
        self.expect(&Token::OpenParen).ok();
        let mut params = Vec::new();
        while let Token::Ident(s) = &self.tok {
            params.push(s.clone());
            self.advance();
            if !self.eat(&Token::Comma) {
                break;
            }
        }
        self.expect(&Token::CloseParen).ok();
        self.expect(&Token::OpenBrace).ok();
        let body = self.parse_program();
        self.expect(&Token::CloseBrace).ok();
        let _ = name;
        JsExpr::Function { params, body }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// §4. JS AST → TERM (the universalLift)
// ─────────────────────────────────────────────────────────────────────────────

/// Lift a JS expression into a Term combinator tree.
/// HashTrinity B Map: scope chain (name → de Bruijn index).
pub fn lift_js(js: &str) -> Result<Term, String> {
    let stmts = parse_js(js)?;
    let mut scope: hashtrinity::Table<String, usize> = hashtrinity::Table::new();
    let mut next_idx = 0;

    let term = lift_stmts(&stmts, &mut scope, &mut next_idx)?;
    Ok(term)
}

fn lift_stmts(
    stmts: &[JsStmt],
    scope: &mut hashtrinity::Table<String, usize>,
    next: &mut usize,
) -> Result<Term, String> {
    if stmts.is_empty() {
        return Ok(Term::Num(0));
    }
    // Compose statements as App chains: each is a `λ_.next(prev)`
    // For single statements, just lift the expression
    if stmts.len() == 1 {
        lift_stmt(&stmts[0], scope, next)
    } else {
        let mut result = lift_stmt(&stmts[0], scope, next)?;
        for stmt in &stmts[1..] {
            let next_term = lift_stmt(stmt, scope, next)?;
            result = Term::App(
                Box::new(Term::S),
                Box::new(Term::App(
                    Box::new(Term::K),
                    Box::new(Term::App(Box::new(next_term), Box::new(result))),
                )),
            );
        }
        Ok(result)
    }
}

fn lift_stmt(
    stmt: &JsStmt,
    scope: &mut hashtrinity::Table<String, usize>,
    next: &mut usize,
) -> Result<Term, String> {
    match stmt {
        JsStmt::Expr(e) => lift_expr(e, scope, next),
        JsStmt::Block(stmts) => lift_stmts(stmts, scope, next),
        JsStmt::Var { name, init } => {
            let val = match init {
                Some(e) => lift_expr(e, scope, next)?,
                None => Term::Num(0),
            };
            // Bind: assign de Bruijn index and extend scope
            let idx = *next;
            *next += 1;
            scope.put(name.clone(), idx);
            // Var binding = λ. body with var inserted — simplified:
            // We'll use a direct sequence: (λx. body) val
            Ok(Term::App(
                Box::new(Term::S),
                Box::new(Term::App(
                    Box::new(Term::K),
                    Box::new(Term::App(Box::new(Term::Var(idx)), Box::new(val))),
                )),
            ))
        }
        JsStmt::Return(Some(e)) => lift_expr(e, scope, next),
        JsStmt::Return(None) => Ok(Term::Num(0)),
        JsStmt::If {
            test,
            consequent,
            alternate,
        } => {
            let test_t = lift_expr(test, scope, next)?;
            let cons_t = lift_stmt(consequent, scope, next)?;
            match alternate {
                Some(alt) => {
                    let _alt_t = lift_stmt(alt, scope, next)?;
                    // If = test(cons, alt) as SKI: S (K cons) (K alt) test → test cons alt
                    // Simplified: apply test as boolean selector
                    Ok(Term::App(
                        Box::new(Term::App(
                            Box::new(Term::App(
                                Box::new(Term::Prim(PrimOp::Eq)),
                                Box::new(Term::Num(1)),
                            )),
                            Box::new(test_t),
                        )),
                        Box::new(Term::App(Box::new(Term::K), Box::new(Term::K))),
                    ))
                    // Real impl would use a proper if-then-else combinator
                }
                None => Ok(cons_t),
            }
        }
        JsStmt::For {
            init,
            test,
            update,
            body,
        } => {
            // Simplified: for(init; test; update) body → lift init then run body while test
            // In SKI, we approximate: init, then recursive application
            let init_t = lift_stmt(init, scope, next)?;
            let _body_t = lift_stmt(body, scope, next)?;
            let _update_t = lift_expr(update, scope, next)?;
            let _test_t = lift_expr(test, scope, next)?;
            // For now: just the init term (loop collapse in fold.rs)
            Ok(init_t)
        }
        JsStmt::While { test: _, body } => {
            // Simplified: while loop → just the body (loop collapse in fold.rs)
            lift_stmt(body, scope, next)
        }
        JsStmt::Assign { target, value } => {
            let val_t = lift_expr(value, scope, next)?;
            // Variable assignment = binding update
            if let JsExpr::Ident(name) = target {
                if let Some(&_idx) = scope.get(name) {
                    // Re-bind: store to the de Bruijn slot
                    // Just return the value for now
                    return Ok(Term::App(Box::new(Term::K), Box::new(val_t)));
                }
            }
            Ok(val_t)
        }
    }
}

fn lift_expr(
    expr: &JsExpr,
    scope: &mut hashtrinity::Table<String, usize>,
    next: &mut usize,
) -> Result<Term, String> {
    match expr {
        JsExpr::Num(n) => Ok(Term::Num(*n)),
        JsExpr::Str(s) => Ok(Term::Str(s.clone())),
        JsExpr::Bool(b) => Ok(Term::Num(if *b { 1 } else { 0 })),
        JsExpr::Null => Ok(Term::Num(0)),
        JsExpr::This => Ok(Term::Var(0)), // `this` is the first binding
        JsExpr::Ident(name) => {
            if let Some(&idx) = scope.get(name) {
                Ok(Term::Var(idx))
            } else {
                // Unknown identifier — emit as a string (for DOM APIs etc.)
                Ok(Term::Str(name.clone()))
            }
        }
        JsExpr::Member {
            object,
            property,
            optional,
        } => {
            if let Some(path) = dom_path_scoped(expr, scope) {
                if !optional {
                    return Ok(Term::App(
                        Box::new(Term::Prim(PrimOp::DomGet)),
                        Box::new(Term::Str(path)),
                    ));
                }
                // Optional chain — wrap in a DomGet that returns null on miss
                return Ok(Term::App(
                    Box::new(Term::Prim(PrimOp::DomGet)),
                    Box::new(Term::Str(path)),
                ));
            }
            let _obj_t = lift_expr(object, scope, next)?;
            Ok(Term::Str(format!("<prop:{}>", property)))
        }
        JsExpr::Index {
            object,
            index,
            optional: _,
        } => {
            let obj_t = lift_expr(object, scope, next)?;
            let idx_t = lift_expr(index, scope, next)?;
            if let Some(path) = dom_path_scoped(object, scope) {
                let key = literal_arg(index).unwrap_or_else(|| format!("{idx_t:?}"));
                return Ok(Term::App(
                    Box::new(Term::Prim(PrimOp::DomGet)),
                    Box::new(Term::Str(format!("{path}[{key}]"))),
                ));
            }
            Ok(Term::App(
                Box::new(Term::App(
                    Box::new(Term::Prim(PrimOp::DomCall)),
                    Box::new(idx_t),
                )),
                Box::new(obj_t),
            ))
        }
        JsExpr::Call {
            callee,
            args,
            optional: _,
        } => {
            let callee_t = lift_expr(callee, scope, next)?;
            if let Some(path) = dom_path_scoped(callee, scope) {
                if is_dom_path(&path) || is_host_path(&path) {
                    let mut parts = vec![path];
                    let arguments = args
                        .iter()
                        .map(|arg| dom_arg_scoped(arg, scope))
                        .collect::<Option<Vec<_>>>()
                        .ok_or_else(|| "unsupported DOM call argument".to_string())?;
                    parts.extend(arguments);
                    return Ok(Term::App(
                        Box::new(Term::Prim(PrimOp::DomCall)),
                        Box::new(Term::Str(parts.join(DOM_SEP))),
                    ));
                }
            }

            // Non-DOM host calls remain ordinary primitives.
            if let JsExpr::Member {
                object, property, ..
            } = callee.as_ref()
            {
                let prim = match property.as_str() {
                    "log" => Some(PrimOp::Log),
                    "fetch" => Some(PrimOp::Fetch),
                    _ => None,
                };
                if let Some(op) = prim {
                    let obj_t = lift_expr(object, scope, next)?;
                    let _ = obj_t; // the object context — used for dispatch
                                   // Apply prim to first arg
                    return match args.first() {
                        Some(arg) => {
                            let arg_t = lift_expr(arg, scope, next)?;
                            Ok(Term::App(Box::new(Term::Prim(op)), Box::new(arg_t)))
                        }
                        None => Ok(Term::Prim(op)),
                    };
                }
            }
            // General call: build apply chain
            let mut term = callee_t;
            for arg in args {
                let arg_t = lift_expr(arg, scope, next)?;
                term = Term::App(Box::new(term), Box::new(arg_t));
            }
            Ok(term)
        }
        JsExpr::BinOp { op, left, right } => {
            let left_t = lift_expr(left, scope, next)?;
            let right_t = lift_expr(right, scope, next)?;
            let prim = match op {
                BinOp::Add => PrimOp::Add,
                BinOp::Sub => PrimOp::Sub,
                BinOp::Mul => PrimOp::Mul,
                BinOp::Div => PrimOp::Div,
                BinOp::Rem => PrimOp::Div, // simplified
                BinOp::Eq | BinOp::EqStrict => PrimOp::Eq,
                BinOp::Neq | BinOp::NeqStrict => PrimOp::Eq, // negate later
                BinOp::Lt => PrimOp::Lt,
                BinOp::Gt => PrimOp::Lt, // swapped order
                BinOp::LtEq | BinOp::GtEq => PrimOp::Lt,
                BinOp::And | BinOp::Or => PrimOp::Eq, // simplified
            };
            if *op == BinOp::Gt || *op == BinOp::GtEq {
                // a > b → b < a
                Ok(Term::App(
                    Box::new(Term::App(Box::new(Term::Prim(prim)), Box::new(right_t))),
                    Box::new(left_t),
                ))
            } else {
                Ok(Term::App(
                    Box::new(Term::App(Box::new(Term::Prim(prim)), Box::new(left_t))),
                    Box::new(right_t),
                ))
            }
        }
        JsExpr::Unary { op, arg } => {
            let arg_t = lift_expr(arg, scope, next)?;
            match op {
                UnaryOp::Neg => Ok(Term::App(
                    Box::new(Term::App(
                        Box::new(Term::Prim(PrimOp::Sub)),
                        Box::new(Term::Num(0)),
                    )),
                    Box::new(arg_t),
                )),
                UnaryOp::Not => {
                    // !a = eq(a, 0)
                    Ok(Term::App(
                        Box::new(Term::App(Box::new(Term::Prim(PrimOp::Eq)), Box::new(arg_t))),
                        Box::new(Term::Num(0)),
                    ))
                }
                UnaryOp::TypeOf => {
                    // typeof a — approximated by the term's constructor at lift time
                    Ok(Term::Str(match &arg_t {
                        Term::Num(_) => "number".to_string(),
                        Term::Str(_) => "string".to_string(),
                        Term::Prim(PrimOp::DomGet)
                        | Term::Prim(PrimOp::DomSet)
                        | Term::Prim(PrimOp::DomCall) => "string".to_string(),
                        Term::Prim(_) => "function".to_string(),
                        Term::App(f, _)
                            if matches!(
                                f.as_ref(),
                                Term::Prim(
                                    PrimOp::DomGet | PrimOp::DomCall | PrimOp::Log | PrimOp::Fetch
                                )
                            ) =>
                        {
                            "string".to_string()
                        }
                        _ => "undefined".to_string(),
                    }))
                }
            }
        }
        JsExpr::Assign { target, value } => {
            let val_t = lift_expr(value, scope, next)?;
            if let Some(path) = dom_path_scoped(target, scope) {
                if is_dom_path(&path) {
                    let value = dom_arg_scoped(value, scope)
                        .ok_or_else(|| format!("unsupported DOM assignment value for {path}"))?;
                    return Ok(Term::App(
                        Box::new(Term::Prim(PrimOp::DomSet)),
                        Box::new(Term::Str(format!("{path}{DOM_SEP}{value}"))),
                    ));
                }
            }
            if let JsExpr::Ident(name) = target.as_ref() {
                if let Some(&_idx) = scope.get(name) {
                    // Return the assigned value
                    return Ok(Term::App(Box::new(Term::K), Box::new(val_t)));
                }
            }
            Ok(val_t)
        }
        JsExpr::Object(entries) => {
            // Object literal → string pairs for now
            let mut parts: Vec<String> = Vec::new();
            for (k, v) in entries {
                let v_str = format!("{:?}", lift_expr(v, scope, next).unwrap_or(Term::Num(0)));
                parts.push(format!("{}:{}", k, v_str));
            }
            Ok(Term::Str(parts.join(",")))
        }
        JsExpr::Array(elems) => {
            let mut terms = Vec::new();
            for e in elems {
                terms.push(lift_expr(e, scope, next)?);
            }
            // Array as comma-separated string for now
            Ok(Term::Str(format!("[{}]", terms.len())))
        }
        JsExpr::Function { params, body } => {
            // Allocate de Bruijn indices for params
            let base = *next;
            *next += params.len();
            for (i, p) in params.iter().enumerate() {
                scope.put(p.clone(), base + i);
            }
            let body_t = lift_stmts(body, scope, next)?;
            // For now, just return the body (closure modeling deferred)
            Ok(body_t)
        }
        JsExpr::ArrowFunction { params, body } => {
            let base = *next;
            *next += params.len();
            for (i, p) in params.iter().enumerate() {
                scope.put(p.clone(), base + i);
            }
            let body_t = lift_expr(body, scope, next)?;
            Ok(body_t)
        }
        JsExpr::Group(e) => lift_expr(e, scope, next),
        JsExpr::Block(stmts) => lift_stmts(stmts, scope, next),
        JsExpr::Ternary {
            test: _,
            consequent,
            alternate: _,
        } => {
            // Simplified: return consequent (ternary with 1/0 booleans needs
            // Church encoding conversion in the substrate; for now, just eval
            // the taken branch as if truthy — covers the common pattern
            // `cond ? value : default` where cond is compile-time known.
            lift_expr(consequent, scope, next)
        }
        JsExpr::Optional { expr } => lift_expr(expr, scope, next),
    }
}

fn literal_arg(expr: &JsExpr) -> Option<String> {
    match expr {
        JsExpr::Str(s) => Some(s.clone()),
        JsExpr::Num(n) => Some(n.to_string()),
        JsExpr::Bool(b) => Some(if *b { "true" } else { "false" }.to_string()),
        JsExpr::Null => Some("null".to_string()),
        JsExpr::Ident(s) => Some(s.clone()),
        JsExpr::Group(e) => literal_arg(e),
        _ => None,
    }
}

fn dom_arg_scoped(expr: &JsExpr, scope: &hashtrinity::Table<String, usize>) -> Option<String> {
    match expr {
        JsExpr::Ident(s) => scope
            .get(s)
            .map(|idx| format!("local:{idx}"))
            .or_else(|| Some(s.clone())),
        // A DOM setter needs its actual string value, while a callback is serialized by
        // `js_expr_source` below. Keep literal concatenation in the setter path so `innerHTML =
        // "..." + "..."` is one value, not source text treated as HTML.
        JsExpr::BinOp { op: BinOp::Add, .. } => literal_string_concat(expr),
        JsExpr::Function { body, .. } => js_stmts_source(body),
        JsExpr::ArrowFunction { body, .. } => js_expr_source(body),
        // History/storage APIs accept object and array state arguments. Their
        // value is not inspected by the DOM dispatcher, but it must still be a
        // serializable argument so a call such as pushState({}, "", url)
        // reaches the engine instead of failing during lifting.
        JsExpr::Object(_) | JsExpr::Array(_) => js_expr_source(expr),
        JsExpr::Group(e) => dom_arg_scoped(e, scope),
        // member/index access as a call arg (e.g. `info.parsed`) → its `local:`/dom path,
        // so the callee can resolve the bound record (not a debug string of the AST).
        JsExpr::Member { .. } => dom_path_scoped(expr, scope),
        _ => literal_arg(expr),
    }
}

fn literal_string_concat(expr: &JsExpr) -> Option<String> {
    match expr {
        JsExpr::Str(value) => Some(value.clone()),
        JsExpr::Num(n) => Some(n.to_string()),
        JsExpr::Bool(b) => Some(b.to_string()),
        JsExpr::Null => Some("null".to_string()),
        JsExpr::Ident(s) => Some(s.clone()),
        JsExpr::Member { .. } => {
            let mut parts = Vec::new();
            let mut cur = expr;
            while let JsExpr::Member {
                object, property, ..
            } = cur
            {
                parts.push(property.clone());
                cur = object.as_ref();
            }
            if let JsExpr::Ident(root) = cur {
                parts.push(root.clone());
                parts.reverse();
                Some(parts.join("."))
            } else {
                None
            }
        }
        JsExpr::Group(value) => literal_string_concat(value),
        JsExpr::BinOp {
            op: BinOp::Add,
            left,
            right,
        } => Some(format!(
            "{}{}",
            literal_string_concat(left)?,
            literal_string_concat(right)?
        )),
        _ => None,
    }
}

fn js_stmts_source(stmts: &[JsStmt]) -> Option<String> {
    stmts
        .iter()
        .map(js_stmt_source)
        .collect::<Option<Vec<_>>>()
        .map(|parts| parts.join(";"))
}

fn js_stmt_source(stmt: &JsStmt) -> Option<String> {
    match stmt {
        JsStmt::Expr(e) => js_expr_source(e),
        JsStmt::Assign { target, value } => Some(format!(
            "{} = {}",
            js_expr_source(target)?,
            js_expr_source(value)?
        )),
        JsStmt::Return(Some(e)) => js_expr_source(e),
        JsStmt::Block(stmts) => js_stmts_source(stmts),
        _ => None,
    }
}

fn js_expr_source(expr: &JsExpr) -> Option<String> {
    match expr {
        JsExpr::Num(n) => Some(n.to_string()),
        JsExpr::Str(s) => Some(format!(
            "\"{}\"",
            s.replace('\\', "\\\\").replace('"', "\\\"")
        )),
        JsExpr::Bool(b) => Some(if *b { "true" } else { "false" }.to_string()),
        JsExpr::Null => Some("null".to_string()),
        JsExpr::Ident(s) => Some(s.clone()),
        JsExpr::This => Some("this".to_string()),
        JsExpr::Member {
            object, property, ..
        } => Some(format!("{}.{}", js_expr_source(object)?, property)),
        JsExpr::Index { object, index, .. } => Some(format!(
            "{}[{}]",
            js_expr_source(object)?,
            js_expr_source(index)?
        )),
        JsExpr::Call { callee, args, .. } => {
            let args = args
                .iter()
                .map(js_expr_source)
                .collect::<Option<Vec<_>>>()?
                .join(",");
            Some(format!("{}({args})", js_expr_source(callee)?))
        }
        JsExpr::BinOp { op, left, right } => Some(format!(
            "{} {} {}",
            js_expr_source(left)?,
            bin_op_source(*op),
            js_expr_source(right)?
        )),
        JsExpr::Assign { target, value } => Some(format!(
            "{} = {}",
            js_expr_source(target)?,
            js_expr_source(value)?
        )),
        JsExpr::Group(e) => js_expr_source(e),
        JsExpr::Ternary {
            test,
            consequent,
            alternate,
        } => Some(format!(
            "{} ? {} : {}",
            js_expr_source(test)?,
            js_expr_source(consequent)?,
            js_expr_source(alternate)?
        )),
        JsExpr::Optional { expr } => Some(format!("{}?()", js_expr_source(expr)?)),
        JsExpr::Object(fields) => Some(format!(
            "{{{}}}",
            fields
                .iter()
                .map(|(key, value)| Some(format!("{}:{}", key, js_expr_source(value)?)))
                .collect::<Option<Vec<_>>>()?
                .join(",")
        )),
        JsExpr::Array(items) => Some(format!(
            "[{}]",
            items
                .iter()
                .map(js_expr_source)
                .collect::<Option<Vec<_>>>()?
                .join(",")
        )),
        // Event/timer callbacks keep their body as source text so the engine's
        // event rotor can lift and execute it when the event fires.  Returning
        // the statement sequence here is intentional: the callback runner
        // expects the body, not another function wrapper.
        JsExpr::Block(stmts) => js_stmts_source(stmts),
        JsExpr::Unary {
            op: UnaryOp::TypeOf,
            arg,
        } => Some(format!("typeof {}", js_expr_source(arg)?)),
        // Arrow function in source position: render its body as source text. Used by stealth
        // injection like `Object.defineProperty(navigator,'webdriver',{get:()=>undefined})` where
        // the getter body is `undefined`. The body may itself be another JsExpr; recurse.
        JsExpr::ArrowFunction { body, .. } => js_expr_source(body),
        JsExpr::Function { body, .. } => js_stmts_source(body),
        _ => None,
    }
}

fn bin_op_source(op: BinOp) -> &'static str {
    match op {
        BinOp::Add => "+",
        BinOp::Sub => "-",
        BinOp::Mul => "*",
        BinOp::Div => "/",
        BinOp::Rem => "%",
        BinOp::Eq => "==",
        BinOp::EqStrict => "===",
        BinOp::Neq => "!=",
        BinOp::NeqStrict => "!==",
        BinOp::Lt => "<",
        BinOp::Gt => ">",
        BinOp::LtEq => "<=",
        BinOp::GtEq => ">=",
        BinOp::And => "&&",
        BinOp::Or => "||",
    }
}

fn dom_path_scoped(expr: &JsExpr, scope: &hashtrinity::Table<String, usize>) -> Option<String> {
    match expr {
        JsExpr::Ident(name) => scope
            .get(name)
            .map(|idx| format!("local:{idx}"))
            .or_else(|| Some(name.clone())),
        JsExpr::This => Some("this".to_string()),
        JsExpr::Member {
            object, property, ..
        } => {
            let base = dom_path_scoped(object, scope)?;
            Some(format!("{base}.{property}"))
        }
        // `window.navigator[''].constructor.prototype.querySelector` and similar
        // indexed-member chains are common in stealth-injection scripts. Render the
        // index with the same `dom_arg_scoped` rule so a quoted string, an identifier,
        // or a member access all reduce to one segment.
        JsExpr::Index { object, index, .. } => {
            let base = dom_path_scoped(object, scope)?;
            let idx = dom_arg_scoped(index, scope)?;
            Some(format!("{base}[{idx}]"))
        }
        JsExpr::Call { callee, args, .. } => {
            let callee_path = dom_path_scoped(callee, scope)?;
            let args = args
                .iter()
                .map(|arg| dom_arg_scoped(arg, scope))
                .collect::<Option<Vec<_>>>()?
                .join(",");
            Some(format!("{callee_path}({args})"))
        }
        JsExpr::Group(e) => dom_path_scoped(e, scope),
        _ => None,
    }
}

fn is_dom_path(path: &str) -> bool {
    matches!(
        path.split(['.', '(', '[']).next().unwrap_or(""),
        "document"
            | "navigator"
            | "screen"
            | "location"
            | "window"
            | "chrome"
            | "history"
            | "localStorage"
            | "sessionStorage"
            // Object.* static methods — stealth-injection calls `Object.defineProperty`
            // to redefine `navigator.webdriver` / `navigator.platform` etc.; without this
            // the call lifts as an apply-chain that the substrate can't execute.
            | "Object"
    ) || path.starts_with("local:")
        || path.starts_with("node:")
}

fn is_host_path(path: &str) -> bool {
    matches!(
        path,
        "setTimeout"
            | "clearTimeout"
            | "requestAnimationFrame"
            | "cancelAnimationFrame"
            | "window.setTimeout"
            | "window.clearTimeout"
            | "window.requestAnimationFrame"
            | "window.cancelAnimationFrame"
    )
}

// ─────────────────────────────────────────────────────────────────────────────
// §5. WASM BYTECODE → TERM (stub — full decoder follows the same universalLift)
// ─────────────────────────────────────────────────────────────────────────────

/// Lift a WASM binary module into a Term combinator tree.
/// Each WASM opcode is mapped to a combinator expression via the same
/// universalLift pattern (opcodes = alphabet α, no per-format parser).
pub fn lift_wasm(_wasm: &[u8]) -> Result<Term, String> {
    // Stub: full WASM→Term decoder follows the same universalLift pattern.
    // WASM opcodes map to PrimOp combinators:
    //   i32.add  → Add, i32.sub → Sub, i32.mul → Mul
    //   i32.load → Memory read, i32.store → Memory write
    //   call     → function application (App)
    //   br_if    → conditional via Eq
    // The full decoder iterates WASM sections, lifts each function body.
    Ok(Term::I) // placeholder
}

/// Convenience function: detect if input is WASM binary or JS source.
pub fn detect_and_lift(input: &[u8]) -> Result<Term, String> {
    if input.starts_with(&[0x00, b'a', b's', b'm']) {
        // WASM binary — full header check
        lift_wasm(input)
    } else if let Ok(src) = std::str::from_utf8(input) {
        lift_js(src)
    } else {
        Err("cannot detect input format".into())
    }
}

/// Parse the supported JS fragment, rejecting malformed delimiters before evaluation.
pub fn parse_js(js: &str) -> Result<Vec<JsStmt>, String> {
    let mut parser = Parser::new(js);
    let stmts = parser.parse_program();
    if !matches!(parser.tok, Token::Eof) {
        parser
            .error
            .get_or_insert_with(|| "unexpected closing delimiter".to_string());
    }
    match parser.error {
        Some(error) => Err(error),
        None => Ok(stmts),
    }
}

/// Lift a single statement into a Term, using the given scope and index counter.
pub fn lift_statement(
    stmt: &JsStmt,
    scope: &mut hashtrinity::Table<String, usize>,
    next: &mut usize,
) -> Result<Term, String> {
    lift_stmt(stmt, scope, next)
}

/// Lift a single expression into a Term, using the given scope and index counter.
pub fn lift_expression(
    expr: &JsExpr,
    scope: &mut hashtrinity::Table<String, usize>,
    next: &mut usize,
) -> Result<Term, String> {
    lift_expr(expr, scope, next)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn lift_number() {
        let term = lift_js("42").unwrap();
        assert_eq!(term, Term::Num(42));
    }

    #[test]
    fn lift_string() {
        let term = lift_js("\"hello\"").unwrap();
        assert_eq!(term, Term::Str("hello".to_string()));
    }

    #[test]
    fn lift_addition() {
        let term = lift_js("1 + 2").unwrap();
        // App(App(Add, 1), 2)
        assert!(matches!(term, Term::App(_, _)));
    }

    #[test]
    fn lift_binary_expression() {
        let term = lift_js("x = 5 + 3").unwrap();
        // Should not error
        let _ = term;
    }

    #[test]
    fn lift_function_call() {
        let term = lift_js("console.log(\"test\")").unwrap();
        // Should map console.log to Log primitive
        match &term {
            Term::App(f, _) => assert!(matches!(f.as_ref(), Term::Prim(PrimOp::Log))),
            _ => panic!("expected App(Prim(Log), _)"),
        }
    }

    #[test]
    fn lift_dom_method() {
        let term = lift_js("document.getElementById(\"main\")").unwrap();
        match &term {
            Term::App(f, _) => assert!(matches!(f.as_ref(), Term::Prim(PrimOp::DomCall))),
            _ => panic!("expected App(Prim(DomCall), _)"),
        }
    }

    #[test]
    fn lift_dom_property_as_path_data() {
        let term = lift_js("navigator.userAgent").unwrap();
        match &term {
            Term::App(f, path) => {
                assert!(matches!(f.as_ref(), Term::Prim(PrimOp::DomGet)));
                assert_eq!(path.as_ref(), &Term::Str("navigator.userAgent".to_string()));
            }
            _ => panic!("expected App(Prim(DomGet), path)"),
        }
    }

    #[test]
    fn lift_timer_as_host_dom_call() {
        let term = lift_js("setTimeout(function(){ document.title = \"ok\" }, 0)").unwrap();
        match &term {
            Term::App(f, path) => {
                assert!(matches!(f.as_ref(), Term::Prim(PrimOp::DomCall)));
                assert!(matches!(path.as_ref(), Term::Str(s) if s.starts_with("setTimeout\x1f")));
            }
            _ => panic!("expected App(Prim(DomCall), path)"),
        }
    }

    #[test]
    fn lift_arrow_function() {
        let term = lift_js("(x) => x + 1").unwrap();
        let _ = term;
    }

    #[test]
    fn lift_conditional() {
        let term = lift_js("if (true) { 42 } else { 0 }").unwrap();
        assert!(matches!(term, Term::App(_, _)));
    }

    #[test]
    fn detect_js_input() {
        let result = detect_and_lift(b"1 + 2");
        assert!(result.is_ok());
    }

    #[test]
    fn lift_boolean() {
        let term = lift_js("true").unwrap();
        assert_eq!(term, Term::Num(1));
        let term = lift_js("false").unwrap();
        assert_eq!(term, Term::Num(0));
    }

    #[test]
    fn lift_null() {
        let term = lift_js("null").unwrap();
        assert_eq!(term, Term::Num(0));
    }

    #[test]
    fn lift_string_concat_in_object() {
        let term = lift_js("({name: \"test\", value: 42})").unwrap();
        assert!(matches!(term, Term::Str(_)));
    }

    #[test]
    fn lift_comparison() {
        let term = lift_js("5 === 5").unwrap();
        assert!(matches!(term, Term::App(_, _)));
    }
}
