//! webfold substrate — combinator evaluation engine: `System` over execution state.
//!
//! Evaluates combinator terms (SKI / Iota calculus) with variable bindings and linear memory.
//! K reduces as constant projection, S routes arguments, and App represents function application.
//!
//! Core data structure roles:
//!   Presence set / Stack        = value stack (scoped locals)
//!   Key-value map / Table       = linear memory (byte array, indexed lookup/write)
//!   Append-only accumulator/Log = call frames and execution traces
//!   Graph adjacency             = combinator expression tree
//!
// ─────────────────────────────────────────────────────────────────────────────
// §1. THE TERM — combinator abstract syntax tree
// ─────────────────────────────────────────────────────────────────────────────

/// The combinator tree representation.
/// Constructors: `{Var, K, S, I, Iota, App, Num, Str, Prim}`.
///
/// The SKI/Iota combinator basis:
/// K = `λab.a` (constant projection), S = `λabc.ac(bc)` (substitution),
/// I = SKK = λa.a (identity), Iota = λf.fSK (universal combinator).
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub enum Term {
    Var(usize),                // de Bruijn index
    K,                         // λab.a — constant/projection
    S,                         // λabc.ac(bc) — routing/substitution
    I,                         // λa.a — identity (SKK)
    Iota,                      // λf.fSK — universal (routes to K/S)
    App(Box<Term>, Box<Term>), // application
    Num(i64),                  // native number (Z/2ⁿ via DiscreteArithmetic)
    Str(String),               // native string (for DOM text, console, etc.)
    Prim(PrimOp),              // primitive operations — the syscall bridge
}

/// Primitive operations supported by the substrate evaluation engine.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum PrimOp {
    // Arithmetic (DiscreteArithmetic — O(1) via Z/2ⁿ)
    Add,
    Sub,
    Mul,
    Div,
    // Comparison
    Eq,
    Lt,
    // DOM operations (the page-level syscall bridge): path + args are data.
    DomGet,
    DomSet,
    DomCall,
    // Side effects
    Fetch,
    Log,
    Store,
}

impl Term {
    /// Normal-form check: irreducible if it's not an App with a combinator head.
    #[must_use]
    pub fn is_normal(&self) -> bool {
        !matches!(self, Term::App(_, _))
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// §2. THE CARRIER — linear memory + stack + value set for one substrate
// ─────────────────────────────────────────────────────────────────────────────

/// A typed value in the substrate. The substrate's value domain: numbers,
/// strings, combinators, and function closures (suspended Terms with
/// a pending argument count).
#[derive(Debug, Clone, PartialEq)]
pub enum Value {
    Num(i64),
    Str(String),
    Bool(bool),
    Closure {
        body: Term,
        args_pending: usize,
    },
    Term(Term), // raw term (for composability)
    /// A record — JS object as a Term (UniversalEncoding: a record is K-encoded pairs,
    /// member access is projection). Key → value.
    Record(Vec<(String, Value)>),
    /// A list — JS array / DOM NodeList. `.length` is the count (Web.lean preduce).
    List(Vec<Value>),
    Null,
}

impl Value {
    /// Project a field from a record (member access); `length` reads a list/record size.
    #[must_use]
    pub fn project(&self, key: &str) -> Value {
        match self {
            Value::Record(fields) => fields
                .iter()
                .find(|(k, _)| k == key)
                .map_or(Value::Null, |(_, v)| v.clone()),
            Value::List(items) if key == "length" => Value::Num(items.len() as i64),
            _ => Value::Null,
        }
    }
}

/// Linear memory — a WASM-style byte array. The carrier for all substrate state.
/// HashTrinity B Map face: byte offset → byte value, replace-on-write.
#[derive(Debug, Clone)]
pub struct Memory {
    bytes: Vec<u8>,
}

impl Memory {
    pub fn new(size: usize) -> Self {
        Self {
            bytes: vec![0u8; size],
        }
    }

    pub fn read(&self, offset: usize, len: usize) -> Option<&[u8]> {
        self.bytes.get(offset..offset.checked_add(len)?)
    }

    pub fn write(&mut self, offset: usize, data: &[u8]) -> Option<()> {
        let end = offset.checked_add(data.len())?;
        self.bytes.get_mut(offset..end)?;
        self.bytes[offset..end].copy_from_slice(data);
        Some(())
    }

    pub fn grow(&mut self, additional: usize) {
        self.bytes.extend(std::iter::repeat(0u8).take(additional));
    }

    pub fn size(&self) -> usize {
        self.bytes.len()
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// §3. THE SYSTEM — execution context
// ─────────────────────────────────────────────────────────────────────────────

/// One substrate execution context (e.g. per-page/tab or sandbox). Owns linear memory,
/// value stack (scoped locals), and variable bindings.
///
/// `System::apply(term)` reduces a Term to a Value by evaluating it in this execution context.
pub struct System {
    /// Linear memory (byte array)
    pub memory: Memory,
    /// Value stack for evaluation (scoped locals)
    stack: Vec<Value>,
    /// Local variable bindings (index → Value)
    locals: Vec<Value>,
    /// Origin for CORS checks (set at page load)
    pub origin: String,
    /// Console output buffer
    pub console: Vec<String>,
}

impl System {
    pub fn new(mem_size: usize, origin: &str) -> Self {
        Self {
            memory: Memory::new(mem_size),
            stack: Vec::new(),
            locals: Vec::new(),
            origin: origin.to_string(),
            console: Vec::new(),
        }
    }

    /// Push a value onto the stack.
    pub fn push(&mut self, v: Value) {
        self.stack.push(v);
    }

    /// Pop a value from the stack.
    pub fn pop(&mut self) -> Option<Value> {
        self.stack.pop()
    }

    /// Peek at the top of the stack.
    pub fn peek(&self) -> Option<&Value> {
        self.stack.last()
    }

    /// Bind a local variable by index.
    pub fn bind(&mut self, idx: usize, v: Value) {
        if idx >= self.locals.len() {
            self.locals.resize(idx + 1, Value::Null);
        }
        self.locals[idx] = v;
    }

    /// Get a local variable by index.
    pub fn get_local(&self, idx: usize) -> Option<&Value> {
        self.locals.get(idx)
    }

    /// Current number of local slots — a closure binds its params ABOVE this so it never
    /// clobbers the caller's bindings.
    pub fn locals_len(&self) -> usize {
        self.locals.len()
    }

    /// Enter a new scope: push frame marker on the locals stack.
    pub fn enter_scope(&mut self) -> usize {
        let depth = self.locals.len();
        self.locals.push(Value::Null); // scope marker
        depth
    }

    /// Exit a scope, restoring locals.
    pub fn exit_scope(&mut self, marker: usize) {
        self.locals.truncate(marker);
    }

    // ── Console output ──
    fn log(&mut self, msg: String) {
        self.console.push(msg);
    }

    // ── Helpers for detecting fully-applied primitives and combinators ──
    fn is_prim_app(f: &Term) -> bool {
        match f {
            Term::App(op, _) => matches!(op.as_ref(), Term::Prim(_)),
            _ => false,
        }
    }

    fn is_k_app(f: &Term) -> bool {
        matches!(f, Term::App(op, _) if *op.as_ref() == Term::K)
    }

    fn is_s_app(f: &Term) -> bool {
        matches!(f, Term::App(op, _) if *op.as_ref() == Term::S)
    }

    fn extract_s_args<'a>(f: &'a Term, z: &'a Term) -> Option<(&'a Term, &'a Term, &'a Term)> {
        if let Term::App(inner_f, y) = f {
            if let Term::App(s, x) = inner_f.as_ref() {
                if **s == Term::S {
                    return Some((x.as_ref(), y.as_ref(), z));
                }
            }
        }
        None
    }

    fn extract_binop(inner: &Term, arg: &Term) -> Option<(PrimOp, i64, i64)> {
        if let Term::App(op, a) = inner {
            if let Term::Prim(p) = op.as_ref() {
                if let (Term::Num(a_val), Term::Num(b_val)) = (a.as_ref(), arg) {
                    return Some((*p, *a_val, *b_val));
                }
            }
        }
        None
    }

    // ─────────────────────────────────────────────────────────────────────────
    // §4. APPLY — the one reduction rule
    // ─────────────────────────────────────────────────────────────────────────

    /// Reduce one step of the Term under this substrate's applicative.
    /// Returns Ok(Some(Term)) for one step, Ok(None) if normal (no step taken),
    /// or Err(message) for a runtime error.
    pub fn reduce(&mut self, term: &Term) -> Result<Option<Term>, String> {
        match term {
            // K x y = x: App(App(K, x), y) → x
            Term::App(f, x) if Self::is_k_app(f) => match f.as_ref() {
                Term::App(_, a) => Ok(Some(*a.clone())),
                _ => Err("impossible: k_app but not App(K, _)".into()),
            },
            // S x y z = (x z) (y z): App(App(App(S, x), y), z) → App(App(x, z), App(y, z))
            Term::App(f, z) if Self::extract_s_args(f, z).is_some() => {
                let (x, y, z) = Self::extract_s_args(f, z).unwrap();
                let xz = Term::App(Box::new(x.clone()), Box::new(z.clone()));
                let yz = Term::App(Box::new(y.clone()), Box::new(z.clone()));
                Ok(Some(Term::App(Box::new(xz), Box::new(yz))))
            }
            // Check for fully applied primitive: App(App(Prim(op), a), b)
            Term::App(f, x) if Self::is_prim_app(f) => {
                match Self::extract_binop(f.as_ref(), x.as_ref()) {
                    Some((op, a, b)) => match op {
                        PrimOp::Add => Ok(Some(Term::Num(a.wrapping_add(b)))),
                        PrimOp::Sub => Ok(Some(Term::Num(a.wrapping_sub(b)))),
                        PrimOp::Mul => Ok(Some(Term::Num(a.wrapping_mul(b)))),
                        PrimOp::Div => {
                            if b == 0 {
                                Err("division by zero".into())
                            } else {
                                Ok(Some(Term::Num(a / b)))
                            }
                        }
                        PrimOp::Eq => Ok(Some(Term::Num(i64::from(a == b)))),
                        PrimOp::Lt => Ok(Some(Term::Num(i64::from(a < b)))),
                        _ => Err(format!("unimplemented binary prim: {op:?}")),
                    },
                    None => {
                        // Args aren't all numbers yet — reduce the inner App first
                        if let Term::App(bf, bx) = f.as_ref() {
                            let inner = Term::App(bf.clone(), bx.clone());
                            match self.reduce(&inner)? {
                                Some(reduced) => Ok(Some(Term::App(Box::new(reduced), x.clone()))),
                                None => match self.reduce(x.as_ref())? {
                                    Some(xr) => Ok(Some(Term::App(f.clone(), Box::new(xr)))),
                                    None => Err(format!("stuck prim app: {f:?} {x:?}")),
                                },
                            }
                        } else {
                            Err(format!("is_prim_app true but not App(Prim,_): {f:?}"))
                        }
                    }
                }
            }
            Term::App(f, x) => {
                match f.as_ref() {
                    Term::K => {
                        // K x = normal — needs a second arg. (K x y → x handled above.)
                        Ok(None)
                    }
                    Term::S => {
                        // S x = normal — needs three args. (S x y z → x z (y z) handled above.)
                        Ok(None)
                    }
                    Term::I => {
                        // I a = a — always reduces with one arg
                        Ok(Some(*x.clone()))
                    }
                    Term::Iota => {
                        // Iota f = f S K
                        let body = *x.clone();
                        Ok(Some(Term::App(
                            Box::new(Term::App(Box::new(body), Box::new(Term::S))),
                            Box::new(Term::K),
                        )))
                    }
                    // Unary prim: App(Prim(op), x) — partially applied, don't evaluate yet
                    Term::Prim(op) => {
                        match op {
                            PrimOp::Log => {
                                let msg = self.eval_to_string(x)?;
                                self.log(msg);
                                Ok(Some(Term::Num(0)))
                            }
                            PrimOp::Fetch => {
                                let url = self.eval_to_string(x)?;
                                Ok(Some(Term::Str(format!("<fetch:{url}>"))))
                            }
                            PrimOp::DomGet => {
                                let path = self.eval_to_string(x)?;
                                Ok(Some(Term::Str(format!("<dom:get:{path}>"))))
                            }
                            PrimOp::DomSet => {
                                let path = self.eval_to_string(x)?;
                                Ok(Some(Term::Str(format!("<dom:set:{path}>"))))
                            }
                            PrimOp::DomCall => {
                                let path = self.eval_to_string(x)?;
                                Ok(Some(Term::Str(format!("<dom:call:{path}>"))))
                            }
                            PrimOp::Store => {
                                let val = self.eval_to_string(x)?;
                                Ok(Some(Term::Str(val)))
                            }
                            // Binary prims with one arg: try reducing the arg first
                            PrimOp::Add
                            | PrimOp::Sub
                            | PrimOp::Mul
                            | PrimOp::Div
                            | PrimOp::Eq
                            | PrimOp::Lt => {
                                match self.reduce(x.as_ref())? {
                                    Some(xr) => {
                                        Ok(Some(Term::App(Box::new(Term::Prim(*op)), Box::new(xr))))
                                    }
                                    None => Ok(None), // partial application — normal
                                }
                            }
                        }
                    }
                    Term::Var(idx) => {
                        let v = self
                            .get_local(*idx)
                            .ok_or_else(|| format!("unbound variable ${idx}"))?;
                        Ok(Some(v.clone().into_term()))
                    }
                    // Application of an application: (f a) b
                    // Reduce the inner App f first
                    Term::App(f_inner, x_inner) => {
                        let inner = Term::App(f_inner.clone(), x_inner.clone());
                        match self.reduce(&inner)? {
                            Some(reduced) => Ok(Some(Term::App(Box::new(reduced), x.clone()))),
                            None => {
                                // inner is normal — try the outer arg
                                if let Some(x_reduced) = self.reduce(x.as_ref())? {
                                    Ok(Some(Term::App(Box::new(inner), Box::new(x_reduced))))
                                } else if Self::is_k_app(&inner) || Self::is_s_app(&inner) {
                                    // Partially applied K (1 arg) or S (1 or 2 args) is in normal form
                                    Ok(None)
                                } else {
                                    Err(format!("stuck: {:?} {:?}", inner, x))
                                }
                            }
                        }
                    }
                    Term::Num(_) | Term::Str(_) => {
                        // Num or Str applied to something — stuck state, return the arg
                        Err(format!("cannot apply function to {x:?}"))
                    }
                }
            }
            // Normal forms
            Term::K
            | Term::S
            | Term::I
            | Term::Iota
            | Term::Num(_)
            | Term::Str(_)
            | Term::Prim(_) => Ok(None),
            Term::Var(idx) => {
                // Substitute from locals if bound, otherwise normal (unbound)
                match self.get_local(*idx) {
                    Some(v) => Ok(Some(v.clone().into_term())),
                    None => Ok(None),
                }
            }
        }
    }

    pub const MAX_REDUCTION_STEPS: usize = 256;

    /// Fully reduce a Term to a Value (call-by-value, bounded step budget).
    pub fn eval(&mut self, term: &Term) -> Result<Value, String> {
        self.eval_bounded(term, Self::MAX_REDUCTION_STEPS)
    }

    /// Reduce a Term to a Value with an explicit step budget to guarantee termination.
    pub fn eval_bounded(&mut self, term: &Term, max_steps: usize) -> Result<Value, String> {
        let mut t = term.clone();
        let mut steps = 0;
        while let Some(next) = self.reduce(&t)? {
            steps += 1;
            if steps >= max_steps {
                return Err(format!(
                    "reduction step budget exceeded ({max_steps} steps)"
                ));
            }
            t = next;
        }
        Ok(self.term_to_value(&t))
    }

    fn term_to_value(&mut self, term: &Term) -> Value {
        match term {
            Term::Num(n) => Value::Num(*n),
            Term::Str(s) => Value::Str(s.clone()),
            Term::K | Term::S | Term::I | Term::Iota | Term::Prim(_) | Term::App(_, _) => {
                Value::Term(term.clone())
            }
            Term::Var(idx) => self.get_local(*idx).cloned().unwrap_or(Value::Null),
        }
    }

    /// Evaluate a Term to a number, expecting a Num result.
    #[allow(dead_code)]
    fn eval_to_num(&mut self, term: &Term) -> Result<i64, String> {
        match self.eval(term)? {
            Value::Num(n) => Ok(n),
            Value::Str(s) => s
                .parse::<i64>()
                .map_err(|e| format!("cannot parse num: {e}")),
            _ => Err(format!("expected number, got {term:?}")),
        }
    }

    /// Eval but expect Num — used when the function has already been evaluated.
    fn eval_to_string(&mut self, term: &Term) -> Result<String, String> {
        match self.eval(term)? {
            Value::Str(s) => Ok(s),
            Value::Num(n) => Ok(n.to_string()),
            _ => Err(format!("expected string, got {term:?}")),
        }
    }
}

impl Value {
    pub fn into_term(self) -> Term {
        match self {
            Value::Num(n) => Term::Num(n),
            Value::Str(s) => Term::Str(s),
            Value::Bool(b) => Term::Num(i64::from(b)),
            Value::Closure { body, .. } => body,
            Value::Term(t) => t,
            // records/lists carry through as opaque terms (re-wrapped on read).
            Value::Record(_) | Value::List(_) | Value::Null => Term::Num(0),
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// §5. SUBSTRATE CONSTRUCTION — the applicative as a builder
// ─────────────────────────────────────────────────────────────────────────────

/// Builder for creating substrate instances. Follows the same pattern as
/// `BrowserConfig` / `StealthConfig` in the rest of webfold.
#[derive(Debug, Clone)]
pub struct SubstrateConfig {
    pub memory_pages: usize, // 64KB pages
    pub origin: String,
    pub max_stack_depth: usize,
}

impl Default for SubstrateConfig {
    fn default() -> Self {
        Self {
            memory_pages: 1, // 64KB default
            origin: "about:blank".to_string(),
            max_stack_depth: 1024,
        }
    }
}

impl SubstrateConfig {
    pub fn new() -> Self {
        Self::default()
    }
    #[must_use]
    pub fn memory(mut self, pages: usize) -> Self {
        self.memory_pages = pages;
        self
    }
    #[must_use]
    pub fn origin(mut self, origin: impl Into<String>) -> Self {
        self.origin = origin.into();
        self
    }
    pub fn build(self) -> System {
        System::new(self.memory_pages * 65536, &self.origin)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn k_reduces_to_identity() {
        let mut sys = System::new(1024, "https://test/");
        // K a b = a — first, K a = identity waiting for b
        // K applied to one arg: we have App(K, x) which reduces to x
        let term = Term::App(
            Box::new(Term::App(Box::new(Term::K), Box::new(Term::Num(42)))),
            Box::new(Term::Num(7)),
        );
        let res = sys.eval(&term).unwrap();
        assert_eq!(res, Value::Num(42));
    }

    #[test]
    fn i_is_identity() {
        let mut sys = System::new(1024, "https://test/");
        let term = Term::App(Box::new(Term::I), Box::new(Term::Num(99)));
        let res = sys.eval(&term).unwrap();
        assert_eq!(res, Value::Num(99));
    }

    #[test]
    fn iota_routes_to_sk() {
        let mut sys = System::new(1024, "https://test/");
        // Iota K = K S K = S (iota is λf.fSK)
        let term = Term::App(Box::new(Term::Iota), Box::new(Term::K));
        let res = sys.eval(&term).unwrap();
        assert_eq!(res, Value::Term(Term::S));
    }

    #[test]
    fn arithmetic_via_prims() {
        let mut sys = System::new(1024, "https://test/");
        // (Add 2) 3 = 5
        let add2 = Term::App(Box::new(Term::Prim(PrimOp::Add)), Box::new(Term::Num(2)));
        let term = Term::App(Box::new(add2), Box::new(Term::Num(3)));
        let res = sys.eval(&term).unwrap();
        assert_eq!(res, Value::Num(5));
    }

    #[test]
    fn locals_bind_and_read() {
        let mut sys = System::new(1024, "https://test/");
        sys.bind(0, Value::Num(42));
        let term = Term::Var(0);
        let res = sys.eval(&term).unwrap();
        assert_eq!(res, Value::Num(42));
    }

    #[test]
    fn console_log_output() {
        let mut sys = System::new(1024, "https://test/");
        let term = Term::App(
            Box::new(Term::Prim(PrimOp::Log)),
            Box::new(Term::Str("hello".into())),
        );
        let res = sys.eval(&term).unwrap();
        assert_eq!(res, Value::Num(0));
        assert_eq!(sys.console, vec!["hello".to_string()]);
    }

    #[test]
    fn division_by_zero_errors() {
        let mut sys = System::new(1024, "https://test/");
        let div5 = Term::App(Box::new(Term::Prim(PrimOp::Div)), Box::new(Term::Num(5)));
        let term = Term::App(Box::new(div5), Box::new(Term::Num(0)));
        let res = sys.eval(&term);
        assert!(res.is_err());
    }

    #[test]
    fn memory_read_write() {
        let mut mem = Memory::new(64);
        assert_eq!(mem.size(), 64);
        mem.write(4, &[0xde, 0xad, 0xbe, 0xef]).unwrap();
        assert_eq!(mem.read(4, 4), Some(&[0xde, 0xad, 0xbe, 0xef][..]));
    }

    #[test]
    fn memory_grow() {
        let mut mem = Memory::new(64);
        mem.grow(64);
        assert_eq!(mem.size(), 128);
    }

    #[test]
    fn eq_primitive() {
        let mut sys = System::new(1024, "https://test/");
        let eq5 = Term::App(Box::new(Term::Prim(PrimOp::Eq)), Box::new(Term::Num(5)));
        let term = Term::App(Box::new(eq5), Box::new(Term::Num(5)));
        let res = sys.eval(&term).unwrap();
        assert_eq!(res, Value::Num(1));
        let eq5 = Term::App(Box::new(Term::Prim(PrimOp::Eq)), Box::new(Term::Num(5)));
        let term = Term::App(Box::new(eq5), Box::new(Term::Num(7)));
        let res = sys.eval(&term).unwrap();
        assert_eq!(res, Value::Num(0));
    }

    #[test]
    fn step_budget_prevents_infinite_reduction_loop() {
        let mut sys = System::new(1024, "https://test/");
        // W = S I I  (λx. x x)
        let s_i = Term::App(Box::new(Term::S), Box::new(Term::I));
        let w = Term::App(Box::new(s_i), Box::new(Term::I));
        // Omega = W W  ((λx. x x)(λx. x x) -> infinite reduction)
        let omega = Term::App(Box::new(w.clone()), Box::new(w));

        let res = sys.eval_bounded(&omega, 32);
        assert!(res.is_err());
        assert!(res
            .unwrap_err()
            .contains("reduction step budget exceeded (32 steps)"));
    }
}
