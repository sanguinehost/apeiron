### Verdict: APPROVE

**Question:** *Does this safely reject unregistered optimization implementation before a worker starts?*  
**Answer:** Yes. With `tools/dispatch/contracts.json` holding `"contracts": {}`, any implementation proposal is deterministically rejected at `check_proposal` (`ADMISSION_UNREGISTERED_CONTRACT`) before any worker subprocess is spawned.

---

### Architectural Review

1. **Fail-Closed Admission Boundary**
   - In `tools/dispatch/admit.py`, `check_proposal()` requires `data['contracts'].get(proposal['contract'])` to be a dictionary. With the production registry empty, any proposal fails immediately.
   - `launch()` calls `check_proposal()` first; no worker command executes upon failure.
   - No reusable tokens or cached approvals exist; admission is evaluated fresh from source text on each invocation.

2. **Exact Certificate Type**
   - `proof/DispatchAdmission.lean` defines `ProofDispatch.Admission` over explicit `Input`, `Output`, `before`, `after`, `reachable`, `admissible`, `beforeCost`, and `afterCost`.
   - `admit.py` verifies the certificate against this exact type signature via a synthesized `Check.lean` evaluated with `warningAsError true`.

3. **Axiom Audit**
   - Transitive axiom collection (`#audit_admission`) in `DispatchAdmission.lean` restricts the axiom cone to `{propext, Classical.choice, Quot.sound}`.
   - Any unpermitted axiom (such as `sorryAx` or untrusted external axioms) throws `ADMISSION_AXIOM_REJECT`. `admit.py` verifies both exit code 0 and presence of `ADMISSION_KERNEL_OK`.

4. **Witness Nonvacuity**
   - The certificate requires an explicit `witness : Input` and `joint : reachable witness ∧ admissible witness`.
   - Vacuous truth via contradictory hypotheses is prevented: if `reachable ∧ admissible` is everywhere false, the structure cannot be instantiated.

5. **Cost Model Trust**
   - The certificate proves improvement strictly within the formal cost function (`afterCost x < beforeCost x`), explicitly non-predictive of physical execution timing.
   - The registry enforces `grade == 'source-connected-cost-model'`.

6. **Digest and Worker Binding**
   - Strict SHA-256 validation covers the registry (`registry_sha256`), contract proof files, and required infrastructure (`proof/extract/lib.rs`, `proof/regen.sh`, `proof/ApeironWord.lean`, `proof/DispatchAdmission.lean`, `tools/dispatch/admit.py`, and `proof/corpus/lean-toolchain`).
   - `proposal['worker']` is strictly bound to `contract['worker']`.
   - Identity digests are validated both during contract verification and immediately before subprocess execution to prevent TOCTOU substitution.

7. **Package Identity and Self-Tests**
   - Lean invocations are anchored in `proof/corpus` with toolchain pin verification (`leanprover/lean4:v4.31.0`), serialized via `flock /tmp/opencode/apeiron-lane.lock` and bounded by `systemd-run` (12 GiB, no swap, 1 thread).
   - `--self-test` executes against isolated synthetic fixtures in a scratch directory and cannot install production contracts or launch production workers.

---

### Retained Trust Boundaries (Out of Scope / Trusted Perimeter)

1. **Direct Shell / Native Agent Bypass:**  
   `admit.py` governs only execution dispatched through this launcher. Native agents, direct shell commands, or unmediated processes operate outside this perimeter.
2. **Lead-Reviewed Source & Cost Model Registration:**  
   Correctness of the baseline Lean/Rust semantic correspondence, definition of the cost model function, and modifications to `contracts.json` are trusted to lead review.
