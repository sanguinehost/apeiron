### Verdict: APPROVE

The inspection confirms that `/home/socol/oc-tmp/wt/worktree-agent-APEIRON-PROOFDISPATCH-W1-T1/tools/dispatch/admit.py` correctly implements the required resource bounds, environment hygiene, and complexity annotations without running builds or modifying files.

---

### Verification of Changes

1. **Outer lane and memory enforcement on extraction check:**
   `proof/regen.sh --check` in `check_proposal` is wrapped under:
   ```python
   ['flock', '-w', seconds, '/tmp/opencode/apeiron-lane.lock',
    'systemd-run', '--user', '--scope', '-p', 'MemoryMax=12G', '-p', 'MemorySwapMax=0',
    'timeout', '--kill-after=2', seconds, 'proof/regen.sh', '--check']
   ```
   with environment overrides:
   `{'LEAN_NUM_THREADS': '1', 'LEAN_PATH': '', 'TMPDIR': str(stage)}`.
   This ensures:
   - Serialization on `/tmp/opencode/apeiron-lane.lock`.
   - Strict `12G` memory ceiling and `MemorySwapMax=0` via `systemd-run`.
   - Single-threaded Lean execution (`LEAN_NUM_THREADS=1`).
   - Isolation of temporary files to private scratch (`TMPDIR=str(stage)` under `/home/socol/oc-tmp/proof-dispatch/`).
   - Clearing inherited `LEAN_PATH` (`LEAN_PATH=''`) so fresh extraction checks do not resolve stale or mismatched olean trees.

2. **Lake dependency check enforcement:**
   `lake build` in `check_proposal` is identically guarded with `flock`, `systemd-run` (12G/0 swap), `timeout`, and `LEAN_NUM_THREADS: '1'`.

3. **Lean compiler wrapper (`lean()`):**
   Applies `flock`, `systemd-run` (12G/0 swap), `timeout`, `LEAN_NUM_THREADS: '1'`, and sets `LEAN_PATH` scoped to the staged directory (`str(stage)`).

4. **Complexity Comments:**
   Per AGENTS.md §8, non-trivial and streaming operations (`sha`, `inside`, `identities`, `run`, `lean`, `kernel`, `check_proposal`, `launch`, `self_test`, `main`) now carry explicit temporal and spatial complexity derivations.

---

### Retained Exclusions & Trust Boundaries

The following remain outside the checking boundary by specification:
- **Native shell / agent bypass:** Direct CLI execution, IDE edits, or subagent tasks bypassing `tools/dispatch/admit.py` are not intercepted by this executable.
- **Source and cost-model registration trust:** Correctness of the mathematical cost model and source-to-abstract-operation mapping in `contracts.json` relies on lead review prior to digest registration.
- **Dependency and execution environment trust:** Integrity of the underlying OS, systemd user manager, toolchains (`elan`, `lake`, Python, git), and shared kernel lock path `/tmp/opencode/apeiron-lane.lock`.
- **Concurrent source mutation race condition (TOCTOU):** The double identity check (`identities(root, expected)` before check and immediately before worker launch) catches pre/post-check drift, but concurrent in-place file mutation between the second hash read and the worker subshell remains an open race window.

---

### Precise Residuals (Pre-AGENTS Rule Integration)

1. **Governing AGENTS Integration:**
   `tools/dispatch/admit.py` enforces constraints when invoked, but repo-level governance (`AGENTS.md`) must formally bind agent dispatch workflows to invoke `admit.py` rather than spawning unbounded workers directly.
2. **Registry Empty State (`contracts.json`):**
   `tools/dispatch/contracts.json` has `contracts: {}`. Production dispatch remains fail-closed until a valid source-connected refinement and cost model are registered by the lead.
