#!/bin/sh
# One whole deadline and one compatible Lean lane, including controls and descendants.
set -eu
DISPATCH_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
exec timeout --kill-after=5 540 flock -w 530 /tmp/opencode/apeiron-lane.lock \
  systemd-run --user --scope -q -p MemoryMax=12G -p MemorySwapMax=0 \
  timeout --kill-after=5 530 env LEAN_NUM_THREADS=1 LEAN_PATH= \
  python3 "$DISPATCH_DIR/gate.py" "$@"
