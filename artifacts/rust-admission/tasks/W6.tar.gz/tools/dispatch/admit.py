#!/usr/bin/env python3
"""Fail-closed, proof-carrying implementation launcher. No reusable approval tokens.

The production registry is owned by the lead, not the proposed worker. Each entry fixes
an Aeneas root, reviewed module/type/domain/resource semantics, source/proof digests,
and owned paths. A module's `admission` value is checked against that exact type by a
fresh pinned Lean invocation and transitive axiom audit. Source identity is checked
again immediately before the bound argv is launched. Registration of source/cost
correspondences and protecting this checker/registry are explicit trusted boundaries.
Direct shell/native-agent invocations do not pass through this executable.

All commands and controls share one 540s deadline. Lean uses the lane lock, one thread,
12GiB and no swap. Self-test accepts only a synthetic marker worker in its own scratch
area; it cannot install a production contract or launch a supplied worker.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parents[2]
REGISTRY = ROOT / 'tools/dispatch/contracts.json'
MODEL = ROOT / 'proof/DispatchAdmission.lean'
# Use the configured package cwd, never `lake -d` from a toolchain-less root.
PACKAGE = ROOT / 'proof/corpus'
SCRATCH = Path('/home/socol/oc-tmp/proof-dispatch')
LOGS = Path('/tmp/opencode/proof-dispatch')
NAME = re.compile(r'[A-Za-z_][A-Za-z_0-9]*(?:\.[A-Za-z_][A-Za-z_0-9]*)*\Z')
DIGEST = re.compile(r'[0-9a-f]{64}\Z')
START = time.monotonic()
RECORDS: list[dict] = []

class Reject(Exception):
    pass

def require(ok, message):
    if not ok:
        raise Reject(message)

def remaining():
    left = 530 - (time.monotonic() - START)
    require(left > 0, 'ADMISSION_BUDGET_EXHAUSTED')
    return left

def sha(path):
    # O(B) bytes read, O(1 MiB) scratch: stream each of B file bytes once.
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(1048576), b''):
            h.update(block)
    return h.hexdigest()

def inside(root, relative):
    # O(P) path components resolved and O(P) path storage; no subtree traversal.
    require(isinstance(relative, str) and relative and not Path(relative).is_absolute(), 'ADMISSION_PATH_REJECT')
    p = root / relative
    require(not p.is_symlink() and p.resolve().is_relative_to(root.resolve()), 'ADMISSION_PATH_REJECT')
    return p

def identities(root, files):
    # O(B + P) bytes/components across all files; hashes stream with bounded scratch.
    require(isinstance(files, dict) and files, 'ADMISSION_IDENTITY_MISSING')
    for relative, expected in files.items():
        require(isinstance(expected, str) and DIGEST.fullmatch(expected), 'ADMISSION_DIGEST_REJECT')
        p = inside(root, relative)
        require(p.is_file() and sha(p) == expected, f'ADMISSION_STALE_SOURCE {relative}')

def run(argv, cwd, label, extra=None):
    # External work has the remaining whole-invocation deadline; O(L) log bytes read/stored.
    left = remaining()
    env = os.environ.copy()
    env.update(extra or {})
    begin = time.monotonic()
    with (LOGS / (label + '.log')).open('wb') as f:
        p = subprocess.Popen(argv, cwd=cwd, env=env, stdout=f, stderr=subprocess.STDOUT, start_new_session=True)
        try:
            p.wait(timeout=left)
        except BaseException:
            os.killpg(p.pid, signal.SIGKILL)
            p.wait()
            raise
    output = (LOGS / (label + '.log')).read_text(errors='replace')
    RECORDS.append(dict(label=label, argv=argv, cwd=str(cwd), exit=p.returncode, seconds=time.monotonic()-begin))
    return p.returncode, output

def lean(path, stage, label, output=None):
    # One bounded compiler invocation; its source/dependency work is not O(1).
    seconds = str(max(1, int(remaining()) - 2))
    env = {'LEAN_NUM_THREADS': '1', 'LEAN_PATH': str(stage)}
    cmd = ['flock', '-w', seconds, '/tmp/opencode/apeiron-lane.lock',
           'systemd-run', '--user', '--scope', '-p', 'MemoryMax=12G', '-p', 'MemorySwapMax=0',
           'timeout', '--kill-after=2', seconds, 'elan', 'run', 'leanprover/lean4:v4.31.0', 'lean', '-R', str(stage)]
    if label.startswith('production'):
        cmd[-6:] = ['lake', 'env', 'lean', '-R', str(stage)]
    if output is not None:
        cmd += ['-o', str(output)]
    return run(cmd + [str(path)], PACKAGE, label, env)

def kernel(contract, stage, label):
    # Copies B proof bytes, then performs two bounded Lean checks; O(B + L) local storage.
    for key in ['namespace', 'before', 'after', 'reachable', 'admissible', 'before_cost', 'after_cost', 'certificate']:
        require(isinstance(contract.get(key), str) and NAME.fullmatch(contract[key]), f'ADMISSION_NAME_REJECT {key}')
    proof_file = inside(ROOT, contract['proof_file']) if contract.get('_fixture_file') is None else contract['_fixture_file']
    # The admission module itself is always compiled from current text, never a cached olean.
    fresh = stage / 'Contract.lean'
    shutil.copy2(proof_file, fresh)
    code, text = lean(fresh, stage, label+'-module', stage / 'Contract.olean')
    require(code == 0, f'ADMISSION_LEAN_REJECT {label}: {text[-1800:]}')
    query = stage / 'Check.lean'
    query.write_text('import DispatchAdmission\nimport Contract\nset_option warningAsError true\n' +
        'def checkedAdmission : ProofDispatch.Admission ' +
        ' '.join(contract[k] for k in ['before','after','reachable','admissible','before_cost','after_cost']) +
        ' := ' + contract['certificate'] + '\n#audit_admission checkedAdmission\n')
    code, text = lean(query, stage, label+'-check')
    require(code == 0 and 'ADMISSION_KERNEL_OK' in text, f'ADMISSION_CERTIFICATE_REJECT {label}: {text[-1800:]}')

def check_proposal(proposal, registry, root, stage, label, fixture=False):
    # Two streaming identity sweeps plus bounded extraction/build/checks; no constant-time claim.
    require(isinstance(proposal, dict) and set(proposal) == {'task','contract','registry_sha256','identity','owned_files','worker'}, 'ADMISSION_SCHEMA_REJECT')
    require(isinstance(proposal['task'],str) and proposal['task'].startswith('APEIRON-'), 'ADMISSION_TASK_REJECT')
    require(proposal['registry_sha256'] == sha(registry), 'ADMISSION_STALE_REGISTRY')
    data = json.loads(registry.read_text())
    require(data.get('schema') == 1 and isinstance(data.get('contracts'),dict), 'ADMISSION_REGISTRY_REJECT')
    contract = data['contracts'].get(proposal['contract'])
    require(isinstance(contract,dict), 'ADMISSION_UNREGISTERED_CONTRACT: source/refinement/cost-model task required')
    require(contract.get('grade') == 'source-connected-cost-model', 'ADMISSION_UNLINKED_MODEL')
    expected = contract.get('identity')
    require(proposal['identity'] == expected, 'ADMISSION_IDENTITY_SUBSTITUTION')
    identities(root, expected)
    paths = proposal['owned_files']
    require(isinstance(paths,list) and 0 < len(paths) <= 3 and len(set(paths)) == len(paths), 'ADMISSION_OWNERSHIP_REJECT')
    require(all(p in contract['owned_files'] for p in paths), 'ADMISSION_UNOWNED_PATH')
    for p in paths:
        inside(root,p)
    worker = proposal['worker']
    require(isinstance(worker,list) and worker and all(isinstance(x,str) and '\x00' not in x for x in worker), 'ADMISSION_ARGV_REJECT')
    require(worker == contract['worker'], 'ADMISSION_WORKER_SUBSTITUTION')
    if not fixture:
        roots = set(re.findall(r'--start-from crate::(\w+)', (root/'proof/regen.sh').read_text()))
        require(contract.get('source_root') in roots, 'ADMISSION_NOT_EXTRACTED')
        require(contract['proof_file'] in expected, 'ADMISSION_PROOF_IDENTITY_MISSING')
        require(isinstance(contract.get('build_target'), str) and NAME.fullmatch(contract['build_target']), 'ADMISSION_BUILD_TARGET_REJECT')
        for rel in ['proof/extract/lib.rs','proof/regen.sh','proof/ApeironWord.lean','proof/DispatchAdmission.lean','tools/dispatch/admit.py','proof/corpus/lean-toolchain']:
            require(rel in expected, f'ADMISSION_IDENTITY_CLOSURE_MISSING {rel}')
        # A hash/name is not a fresh extraction or dependency kernel check.
        code, text = run(['flock','-w',str(int(remaining())-2),'/tmp/opencode/apeiron-lane.lock',
            'systemd-run','--user','--scope','-p','MemoryMax=12G','-p','MemorySwapMax=0',
            'timeout','--kill-after=2',str(int(remaining())-2),'proof/regen.sh','--check'],root,label+'-regen',
            {'LEAN_NUM_THREADS':'1','LEAN_PATH':'','TMPDIR':str(stage)})
        require(code == 0, 'ADMISSION_EXTRACTION_REJECT: '+text[-1500:])
        code, text = run(['flock','-w',str(int(remaining())-2),'/tmp/opencode/apeiron-lane.lock',
            'systemd-run','--user','--scope','-p','MemoryMax=12G','-p','MemorySwapMax=0',
            'timeout','--kill-after=2',str(int(remaining())-2),'lake','build',contract['build_target']],root/'proof/corpus',label+'-build',{'LEAN_NUM_THREADS':'1'})
        require(code == 0, 'ADMISSION_DEPENDENCY_REJECT: '+text[-1500:])
    kernel(contract,stage,label)
    # Eliminate stale receipt/argument reuse: launch uses this object and a second identity read.
    identities(root, expected)
    require(proposal['registry_sha256'] == sha(registry), 'ADMISSION_STALE_REGISTRY')
    return worker

def launch(proposal,registry,root,stage,label,fixture=False):
    # Admission checks and worker execution share one deadline; log storage follows output bytes.
    worker = check_proposal(proposal,registry,root,stage,label,fixture)
    code,text = run(['timeout','--kill-after=2',str(int(remaining())-2),*worker],root,label+'-worker')
    require(code == 0, 'ADMISSION_WORKER_FAILED: '+text[-1000:])
    return text

FIXTURE = '''import DispatchAdmission
set_option warningAsError true
namespace Fixture
def before (x : Nat) := x + 0
def after (x : Nat) := x
def reachable (_ : Nat) : Prop := True
def admissible (_ : Nat) : Prop := True
def beforeCost (_ : Nat) := 10
def afterCost (_ : Nat) := 8
def admission : ProofDispatch.Admission before after reachable admissible beforeCost afterCost where
  witness := 1
  joint := ⟨True.intro, True.intro⟩
  preserves := fun _ _ _ => rfl
  improves := fun _ _ _ => by dsimp [beforeCost, afterCost]; decide
end Fixture
'''

def self_test(stage):
    # Fixed 15 controls, each bounded by the one shared deadline; artifacts scale with logs.
    # Synthetic kernel/launcher controls only; no source-connected Rust result is asserted.
    root = stage/'fixture';root.mkdir();(root/'src').mkdir()
    source = root/'src/source.rs';source.write_text('// fixture only\n')
    proof = root/'Contract.lean';proof.write_text(FIXTURE)
    marker = root/'worker-ran'
    worker = [sys.executable,'-c',"from pathlib import Path; Path('worker-ran').write_text('checked')"]
    contract = dict(grade='source-connected-cost-model',namespace='Fixture',before='Fixture.before',after='Fixture.after',
        reachable='Fixture.reachable',admissible='Fixture.admissible',before_cost='Fixture.beforeCost',after_cost='Fixture.afterCost',
        certificate='Fixture.admission',proof_file='Contract.lean',_fixture_file=proof,identity={'src/source.rs':sha(source)},
        owned_files=['src/result.rs'],worker=worker)
    registry=root/'registry.json'
    def proposal():
        serial={k:v for k,v in contract.items() if k!='_fixture_file'}
        registry.write_text(json.dumps({'schema':1,'contracts':{'fixture':serial}}))
        return dict(task='APEIRON-PROOFDISPATCH-CONTROL',contract='fixture',registry_sha256=sha(registry),identity=contract['identity'].copy(),owned_files=['src/result.rs'],worker=worker.copy())
    # Restore the fixture path after deserializing the synthetic registry, inside kernel only.
    original_root = globals()['ROOT'];globals()['ROOT']=root
    controls=[]
    try:
        p=proposal();launch(p,registry,root,stage,'positive',True);require(marker.read_text()=='checked','POSITIVE_NO_WORKER');marker.unlink()
        def reject(name, expected, text=None, mutate=None):
            proof.write_text(FIXTURE if text is None else text)
            p=proposal()
            if mutate:mutate(p)
            try:launch(p,registry,root,stage,name,True)
            except Reject as e:
                require(expected in str(e),f'CONTROL_WRONG_DIAGNOSTIC {name}: {e}')
                require(not marker.exists(),f'CONTROL_WORKER_STARTED {name}')
                controls.append(dict(name=name,diagnostic=str(e)));print('REJECT',name,flush=True)
            else:raise Reject('CONTROL_SURVIVED '+name)
        reject('vacuous-domain','ADMISSION_LEAN_REJECT',FIXTURE.replace('admissible (_ : Nat) : Prop := True','admissible (_ : Nat) : Prop := False'))
        reject('unreachable-domain','ADMISSION_LEAN_REJECT',FIXTURE.replace('reachable (_ : Nat) : Prop := True','reachable (_ : Nat) : Prop := False'))
        reject('rounded-reassociation','ADMISSION_LEAN_REJECT',FIXTURE.replace('x + 0','(x / 2) * 2'))
        reject('no-cost-reduction','ADMISSION_LEAN_REJECT',FIXTURE.replace('afterCost (_ : Nat) := 8','afterCost (_ : Nat) := 10'))
        weak=FIXTURE[:FIXTURE.index('def admission')]+'theorem admission : True := True.intro\nend Fixture\n'
        reject('weaker-theorem','ADMISSION_CERTIFICATE_REJECT',weak)
        sorry=FIXTURE.replace('preserves := fun _ _ _ => rfl','preserves := by sorry')
        reject('sorry','ADMISSION_LEAN_REJECT',sorry)
        trusted=FIXTURE.replace('  preserves := fun _ _ _ => rfl','  preserves := untrusted').replace('def admission :','axiom untrusted : ∀ x, reachable x → admissible x → after x = before x\ndef admission :')
        reject('extra-axiom','ADMISSION_CERTIFICATE_REJECT',trusted)
        reject('unknown-contract','ADMISSION_UNREGISTERED_CONTRACT',mutate=lambda p:p.update(contract='float-block'))
        reject('stale-source','ADMISSION_STALE_SOURCE',mutate=lambda p:source.write_text('// changed\n'))
        source.write_text('// fixture only\n')
        reject('stale-registry','ADMISSION_STALE_REGISTRY',mutate=lambda p:p.update(registry_sha256='0'*64))
        reject('identity-substitution','ADMISSION_IDENTITY_SUBSTITUTION',mutate=lambda p:p.update(identity={'src/source.rs':'0'*64}))
        reject('worker-substitution','ADMISSION_WORKER_SUBSTITUTION',mutate=lambda p:p.update(worker=[sys.executable,'-c',"raise SystemExit('bypass')"]))
        reject('unowned-path','ADMISSION_UNOWNED_PATH',mutate=lambda p:p.update(owned_files=['src/other.rs']))
        reject('too-many-files','ADMISSION_OWNERSHIP_REJECT',mutate=lambda p:p.update(owned_files=['a','b','c','d']))
        reject('boolean-approval','ADMISSION_SCHEMA_REJECT',mutate=lambda p:p.update(approved=True))
        proof.write_text(FIXTURE);p=proposal();launch(p,registry,root,stage,'restored',True);require(marker.read_text()=='checked','RESTORE_NO_WORKER')
        print('SELFTEST_SYNTHETIC_ONLY positive=1 controls='+str(len(controls))+' restored=1',flush=True)
        return controls
    finally:globals()['ROOT']=original_root

def main():
    # Parses proposal/registry bytes, stages proof bytes and runs bounded checks; streaming hashes.
    parser=argparse.ArgumentParser(description=__doc__)
    mode=parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--self-test',action='store_true')
    mode.add_argument('--check',type=Path,metavar='PROPOSAL_JSON')
    mode.add_argument('--launch',type=Path,metavar='PROPOSAL_JSON')
    args=parser.parse_args()
    LOGS.mkdir(parents=True,exist_ok=True);SCRATCH.mkdir(parents=True,exist_ok=True)
    # Must use the package's exact installed compiler. No fetching/rebuilding another toolchain.
    require((PACKAGE/'lean-toolchain').read_text().strip()=='leanprover/lean4:v4.31.0','ADMISSION_TOOLCHAIN_PIN_REJECT')
    receipt={'status':'failed','budget_seconds':540,'grade':'typed schema/launcher only','production_registry_sha256':sha(REGISTRY),'checker_sha256':sha(Path(__file__)),'admission_schema_sha256':sha(MODEL)}
    try:
        with tempfile.TemporaryDirectory(prefix='admission-',dir=SCRATCH) as d:
            stage=Path(d);shutil.copy2(MODEL,stage/'DispatchAdmission.lean')
            code,text=lean(stage/'DispatchAdmission.lean',stage,'schema',stage/'DispatchAdmission.olean')
            require(code==0,'ADMISSION_SCHEMA_COMPILE_REJECT: '+text[-2000:])
            if args.self_test:receipt['controls']=self_test(stage)
            else:
                p=json.loads((args.check or args.launch).read_text())
                if args.launch:launch(p,REGISTRY,ROOT,stage,'production')
                else:check_proposal(p,REGISTRY,ROOT,stage,'production')
                print('ADMISSION_CHECKED_NOW: no reusable launch token',flush=True)
            receipt['status']='passed'
    except BaseException as e:
        receipt['error']=str(e);raise
    finally:
        receipt.update(elapsed_seconds=time.monotonic()-START,records=RECORDS)
        (LOGS/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')

if __name__=='__main__':
    try:main()
    except (Reject,OSError,ValueError) as e:
        print(str(e),file=sys.stderr);raise SystemExit(1)
