// Test-only checkpoint capture. Time O(T*E*P) projection MACs and O(T*E)
// normalization words; space O(T*(E+P)) words. The four actual projection
// calls repeat activation preparation; this is excluded from kernel timing.
impl Engine {
    pub(crate) fn affine_probe_inputs(
        &self,
        ids: &[u32],
    ) -> Result<(usize, Vec<Vec<Vec<i64>>>, i64), StepError> {
        if ids.is_empty() || self.config.mixers.first() != Some(&MixerKind::Affine) {
            return Err(StepError::BadConfig("probe requires nonempty first affine layer"));
        }
        let layer = 0;
        let geom = self.config.affine.ok_or(StepError::BadConfig("affine geometry"))?;
        let eps = self.eps_fixed()?;
        let gain = self.decode_vectors().norms_of(layer)
            .and_then(|n| n[0].as_deref())
            .ok_or(StepError::BadConfig("probe first-layer norm"))?;
        let xs: Vec<Vec<i64>> = ids.iter().map(|&id| {
            let x = self.embedding_sched(id, Sched::Resident).map_err(StepError::Embedding)?;
            rms_with_gain_slice(gain, &x, eps)
        }).collect::<Result<_, _>>()?;
        let key = geom.n_k_heads * geom.head_k;
        let val = geom.n_v_heads * geom.head_v;
        let outs = [2 * key + val, val, geom.n_v_heads, geom.n_v_heads];
        let layers = self.resolve_layers();
        let mut projection = Vec::with_capacity(4);
        for (part, width) in [7, 8, 9, 10].into_iter().zip(outs) {
            projection.push(self.proj_cols(
                Some(&layers[layer]), layer, part, width, self.config.n_embd,
                &xs, Sched::Resident, KernelMode::Q8Act, None,
            )?);
        }
        Ok((layer, projection, eps))
    }
}
