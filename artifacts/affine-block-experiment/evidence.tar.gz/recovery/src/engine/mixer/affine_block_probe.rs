// Experimental first-layer capture; no executing carrier replacement.
#[path = "affine_block_candidate.rs"]
mod affine_block_candidate;

#[derive(Clone)]
struct AffineCapture {
    q: Vec<f32>,
    k: Vec<f32>,
    v: Vec<f32>,
    decay: Vec<f32>,
    beta: Vec<f32>,
    entry: Vec<f32>,
    oracle: Vec<f32>,
    exit: Vec<f32>,
    dk: usize,
    width: usize,
}

// O(tokens*dk*width) scalar work and O(dk*width + tokens*width) output storage.
fn affine_f64(c: &AffineCapture, n: usize) -> (Vec<f64>, Vec<f64>) {
    let mut s: Vec<f64> = c.entry.iter().map(|&x| f64::from(x)).collect();
    let mut out = vec![0.0; n * c.width];
    for t in 0..n {
        for x in &mut s {
            *x *= f64::from(c.decay[t]);
        }
        for j in 0..c.width {
            let mut prediction = 0.0;
            for i in 0..c.dk {
                prediction += s[i * c.width + j] * f64::from(c.k[t * c.dk + i]);
            }
            let d = f64::from(c.beta[t]) * (f64::from(c.v[t * c.width + j]) - prediction);
            for i in 0..c.dk {
                s[i * c.width + j] += f64::from(c.k[t * c.dk + i]) * d;
            }
            for i in 0..c.dk {
                out[t * c.width + j] += s[i * c.width + j] * f64::from(c.q[t * c.dk + i]);
            }
        }
    }
    (out, s)
}

fn affine_stats(label: &str, got: &[f32], oracle: &[f32]) {
    assert_eq!(got.len(), oracle.len());
    let mut bits = 0usize;
    let mut max = 0.0f64;
    let mut ss = 0.0f64;
    for (&a, &b) in got.iter().zip(oracle) {
        assert!(a.is_finite() && b.is_finite(), "nonfinite affine {label}");
        bits += usize::from(a.to_bits() != b.to_bits());
        let d = f64::from(a) - f64::from(b);
        max = max.max(d.abs());
        ss += d * d;
    }
    println!(
        "ERROR label={label} count={} bit_mismatches={bits} maxabs={max:.9e} rms={:.9e}",
        got.len(),
        (ss / got.len() as f64).sqrt()
    );
}

fn affine_check_f64(got: &[f32], oracle: &[f64], label: &str) {
    assert_eq!(got.len(), oracle.len());
    // Arithmetic smoke check only; this tolerance is not a quality acceptance threshold.
    let scale = oracle.iter().fold(1.0f64, |a, &b| a.max(b.abs()));
    let tolerance = 1e-3 * scale;
    let error = got
        .iter()
        .zip(oracle)
        .fold(0.0f64, |a, (&b, &c)| a.max((f64::from(b) - c).abs()));
    assert!(
        error <= tolerance,
        "blocked independent f64 algebra {label}: error={error:e} tolerance={tolerance:e}"
    );
    println!(
        "AFFINE_F64 label={label} maxabs={error:.9e} scale={scale:.9e} tolerance={tolerance:.9e}"
    );
}

// O(tokens*dk*width) actual source recurrence, O(width) per-token temporary.
fn affine_replay(c: &AffineCapture, n: usize) -> (Vec<f32>, Vec<f32>) {
    let mut s = c.entry.clone();
    let mut out = vec![0.0; n * c.width];
    for t in 0..n {
        f32_carrier::delta_step_f32_avx2(
            &mut s,
            &mut out[t * c.width..(t + 1) * c.width],
            &c.q[t * c.dk..(t + 1) * c.dk],
            &c.k[t * c.dk..(t + 1) * c.dk],
            &c.v[t * c.width..(t + 1) * c.width],
            c.decay[t],
            c.beta[t],
        );
    }
    (out, s)
}

fn affine_block_run(c: &AffineCapture, n: usize, chunk: usize) -> (Vec<f32>, Vec<f32>) {
    let mut s = c.entry.clone();
    let mut out = vec![0.0; n * c.width];
    affine_block_candidate::blocked(
        &mut s,
        &mut out,
        &c.q[..n * c.dk],
        &c.k[..n * c.dk],
        &c.v[..n * c.width],
        &c.decay[..n],
        &c.beta[..n],
        c.dk,
        c.width,
        chunk,
    )
    .expect("blocked geometry");
    (out, s)
}

fn affine_head_state(layer: &AffineLayer, head: usize) -> Vec<f32> {
    let state = layer.heads[head].lock().unwrap();
    let HeadState::F32 { s } = &state.state else {
        panic!("actual constructor carrier")
    };
    s.clone()
}

// Capture invokes the same convolution range and normalization/gate helpers as the carrier.
// O(tokens*channels + selected_heads*tokens*dk*width), matching their explicit loops.
fn affine_capture_pass(
    layer: &mut AffineLayer,
    g: &AffineGeom,
    p: &AffineVectors,
    proj: &[Vec<Vec<i64>>],
    eps: i64,
    validate: bool,
) -> Vec<AffineCapture> {
    let n = proj[0].len();
    let kd = g.n_k_heads * g.head_k;
    let vd = g.n_v_heads * g.head_v;
    let refs: Vec<&[i64]> = proj[0].iter().map(Vec::as_slice).collect();
    let conv = conv_silu_cols_carrier(layer, &p.conv, g.conv_kernel, &refs, Carrier::F32).unwrap();
    let staged = layer.staged_conv.lock().unwrap().clone();
    let mut all = vec![0.0; n * (2 * kd + vd)];
    if let Some(st) = staged {
        layer.ensure_packed_w(&p.conv, st.ch, 4);
        let packed = layer.conv_w_packed.lock().unwrap();
        let scalar = layer.conv_w_scalar.lock().unwrap();
        conv_silu_channel_range(
            &packed,
            &scalar,
            &st.window_f32,
            &st.xs_f32,
            st.ch,
            n,
            0,
            st.ch,
            &mut all,
        )
        .unwrap();
    } else {
        all.clone_from(&layer.conv_out_f32.lock().unwrap());
    }
    assert_eq!(all.len(), n * (2 * kd + vd));
    let cols: Vec<AffineCol<'_>> = (0..n)
        .map(|t| {
            (
                conv[t].as_slice(),
                proj[1][t].as_slice(),
                proj[2][t].as_slice(),
                proj[3][t].as_slice(),
            )
        })
        .collect();
    let ef = f32_carrier::q32_to_f32(eps);
    let width = g.head_v / layer.slices;
    let mut captures = Vec::new();
    for h in [0usize, 7, 15] {
        if h >= g.n_v_heads {
            continue;
        }
        let kh = h % g.n_k_heads;
        let mut q = vec![0.0; n * g.head_k];
        let mut k = q.clone();
        let mut beta = vec![0.0; n];
        let mut decay = beta.clone();
        for t in 0..n {
            let row = &all[t * (2 * kd + vd)..(t + 1) * (2 * kd + vd)];
            q[t * g.head_k..(t + 1) * g.head_k]
                .copy_from_slice(&row[kh * g.head_k..(kh + 1) * g.head_k]);
            k[t * g.head_k..(t + 1) * g.head_k]
                .copy_from_slice(&row[kd + kh * g.head_k..kd + (kh + 1) * g.head_k]);
            f32_carrier::l2_normalize_f32_in_place(
                &mut q[t * g.head_k..(t + 1) * g.head_k],
                ef,
                1.0 / (g.head_k as f32).sqrt(),
            )
            .unwrap();
            f32_carrier::l2_normalize_f32_in_place(
                &mut k[t * g.head_k..(t + 1) * g.head_k],
                ef,
                1.0,
            )
            .unwrap();
            beta[t] = f32_carrier::sigmoid_f32(f32_carrier::q32_to_f32(proj[2][t][h]));
            decay[t] = f32_carrier::exp_f32(
                f32_carrier::q32_to_f32(p.a[h])
                    * f32_carrier::softplus_f32(
                        f32_carrier::q32_to_f32(proj[3][t][h]) + f32_carrier::q32_to_f32(p.dt[h]),
                    ),
            );
        }
        let mut raw = vec![0.0; n * g.head_v];
        for sl in 0..layer.slices {
            let mut v = vec![0.0; n * width];
            for t in 0..n {
                let at = t * (2 * kd + vd) + 2 * kd + h * g.head_v + sl * width;
                v[t * width..(t + 1) * width].copy_from_slice(&all[at..at + width]);
            }
            let mut c = AffineCapture {
                q: q.clone(),
                k: k.clone(),
                v,
                decay: decay.clone(),
                beta: beta.clone(),
                entry: affine_head_state(layer, h * layer.slices + sl),
                oracle: Vec::new(),
                exit: Vec::new(),
                dk: g.head_k,
                width,
            };
            (c.oracle, c.exit) = affine_replay(&c, n);
            for t in 0..n {
                raw[t * g.head_v + sl * width..t * g.head_v + (sl + 1) * width]
                    .copy_from_slice(&c.oracle[t * width..(t + 1) * width]);
            }
            captures.push(c);
        }
        if validate {
            let norm: Vec<f32> = p
                .norm
                .iter()
                .copied()
                .map(f32_carrier::q32_to_f32)
                .collect();
            // Store post-norm replay alongside head id; production executes below.
            let mut gated = vec![0i64; n * g.head_v];
            for t in 0..n {
                f32_carrier::stage2_gated_norm_f32(
                    &raw[t * g.head_v..(t + 1) * g.head_v],
                    &proj[1][t][h * g.head_v..(h + 1) * g.head_v],
                    &norm,
                    ef,
                    &mut gated[t * g.head_v..(t + 1) * g.head_v],
                )
                .unwrap();
            }
            AFFINE_GATED.with(|v| v.borrow_mut().push((h, gated)));
        }
    }
    let actual =
        delta_heads_cols_carrier(layer, g, p, &cols, eps, true, None, Carrier::F32).unwrap();
    if validate {
        AFFINE_GATED.with(|v| {
            for (h, gated) in v.borrow_mut().drain(..) {
                for t in 0..n {
                    assert_eq!(
                        &actual[t][h * g.head_v..(h + 1) * g.head_v],
                        &gated[t * g.head_v..(t + 1) * g.head_v],
                        "capture stage2 bitexact head{h} token{t}"
                    );
                }
            }
        });
        for (hi, h) in [0usize, 7, 15]
            .into_iter()
            .filter(|&h| h < g.n_v_heads)
            .enumerate()
        {
            for sl in 0..layer.slices {
                let c = &captures[hi * layer.slices + sl];
                let actual = affine_head_state(layer, h * layer.slices + sl);
                assert!(
                    actual
                        .iter()
                        .zip(&c.exit)
                        .all(|(a, b)| a.to_bits() == b.to_bits()),
                    "capture live state bitexact head{h} slice{sl}"
                );
            }
        }
        println!("AFFINE_CAPTURE_VALID tokens={n} width={width} slices={} selected_heads={} stage2_and_exit=bitexact",layer.slices,captures.len()/layer.slices);
    }
    captures
}
thread_local! {static AFFINE_GATED:std::cell::RefCell<Vec<(usize,Vec<i64>)>>=const{std::cell::RefCell::new(Vec::new())};}

fn affine_busy() -> f64 {
    fn sample() -> (u64, u64) {
        let s = std::fs::read_to_string("/proc/stat").unwrap();
        let v: Vec<u64> = s
            .lines()
            .next()
            .unwrap()
            .split_whitespace()
            .skip(1)
            .take(8)
            .map(|x| x.parse().unwrap())
            .collect();
        (v.iter().sum(), v[3] + v[4])
    }
    let (a, b) = sample();
    std::thread::sleep(std::time::Duration::from_millis(300));
    let (c, d) = sample();
    100.0 * (1.0 - (d - b) as f64 / (c - a).max(1) as f64)
}

#[test]
#[ignore = "real checkpoint experiment; root owns CPU lane and whole-invocation budget"]
fn affine_block_real_inputs() {
    use crate::engine::loader::Engine;
    let mode = std::env::var("APEIRON_AFFINE_PROBE_MODE").unwrap_or_else(|_| "check".into());
    assert!(mode == "check" || mode == "timing");
    let engine =
        Engine::open(&std::env::var("APEIRON_AFFINE_MODEL").expect("real model path required"))
            .unwrap();
    for fixture in std::env::var("APEIRON_AFFINE_IDS")
        .expect("docs/code fixture paths required")
        .split(':')
    {
        let ids: Vec<u32> = std::fs::read_to_string(fixture)
            .unwrap()
            .split_whitespace()
            .map(|x| x.parse().unwrap())
            .collect();
        assert!(ids.len() >= 128, "128 real input tokens required");
        for prefix in [0usize, 64] {
            for slices in [1usize, 4] {
                let capture_len = if prefix == 0 { 128usize } else { 64usize };
                let (layer_index, projected, eps) = engine
                    .affine_probe_inputs(&ids[..prefix + capture_len])
                    .unwrap();
                let g = engine.config.affine.unwrap();
                assert!(g.head_v == 128 && g.conv_kernel == 4);
                let p = engine.decode_vectors().affine[layer_index]
                    .as_ref()
                    .unwrap();
                let mut state = AffineState::with_slices_carrier(&g, 1, slices, Carrier::F32);
                let layer = state.layer_mut(0).unwrap();
                if prefix > 0 {
                    let pp: Vec<Vec<Vec<i64>>> =
                        projected.iter().map(|v| v[..prefix].to_vec()).collect();
                    affine_capture_pass(layer, &g, p, &pp, eps, false);
                }
                let pp: Vec<Vec<Vec<i64>>> =
                    projected.iter().map(|v| v[prefix..].to_vec()).collect();
                let captures = affine_capture_pass(layer, &g, p, &pp, eps, true);
                for (headslice, c) in captures.iter().enumerate() {
                    for n in [capture_len, capture_len - 1] {
                        let (oracle, exit) = affine_replay(c, n);
                        let (f64o, f64s) = affine_f64(c, n);
                        for chunk in [8usize, 16, 32, 64] {
                            let label=format!("fixture={fixture},prefix={prefix},headslice={headslice},width={},n={n},chunk={chunk}",c.width);
                            let (o, s) = affine_block_run(c, n, chunk);
                            affine_stats(&format!("output,{label}"), &o, &oracle);
                            affine_stats(&format!("state,{label}"), &s, &exit);
                            affine_check_f64(&o, &f64o, &format!("output,{label}"));
                            affine_check_f64(&s, &f64s, &format!("state,{label}"));
                            if n == capture_len - 1 {
                                let mut resumed = s.clone();
                                let mut readout = vec![0.0; c.width];
                                f32_carrier::delta_step_f32_avx2(
                                    &mut resumed,
                                    &mut readout,
                                    &c.q[n * c.dk..(n + 1) * c.dk],
                                    &c.k[n * c.dk..(n + 1) * c.dk],
                                    &c.v[n * c.width..(n + 1) * c.width],
                                    c.decay[n],
                                    c.beta[n],
                                );
                                affine_stats(
                                    &format!("resumed_readout,{label}"),
                                    &readout,
                                    &c.oracle[n * c.width..(n + 1) * c.width],
                                );
                                affine_stats(&format!("resumed_state,{label}"), &resumed, &c.exit);
                            }
                            if mode == "timing" && n == capture_len && headslice % slices == 0 {
                                affine_time(c, n, chunk, &label);
                            }
                        }
                    }
                }
            }
        }
    }
}

fn affine_time(c: &AffineCapture, n: usize, chunk: usize, label: &str) {
    let mut scratch = affine_block_candidate::Scratch::new(chunk, c.dk, c.width).expect("scratch");
    let mut s = c.entry.clone();
    let mut out = vec![0.0; n * c.width];
    for round in 0..5 {
        let busy = affine_busy();
        if busy >= 5.0 {
            println!("AFFINE_TIMING_BLOCKED label={label} round={round} hostbusy={busy:.3}");
            return;
        }
        for which in [round % 2, (round + 1) % 2] {
            let mut elapsed = 0u128;
            for _ in 0..4 {
                s.copy_from_slice(&c.entry);
                out.fill(0.0);
                let start = std::time::Instant::now();
                if which == 0 {
                    for t in 0..n {
                        f32_carrier::delta_step_f32_avx2(
                            &mut s,
                            &mut out[t * c.width..(t + 1) * c.width],
                            &c.q[t * c.dk..(t + 1) * c.dk],
                            &c.k[t * c.dk..(t + 1) * c.dk],
                            &c.v[t * c.width..(t + 1) * c.width],
                            c.decay[t],
                            c.beta[t],
                        );
                    }
                } else {
                    affine_block_candidate::blocked_with_scratch(
                        &mut s,
                        &mut out,
                        &c.q[..n * c.dk],
                        &c.k[..n * c.dk],
                        &c.v[..n * c.width],
                        &c.decay[..n],
                        &c.beta[..n],
                        c.dk,
                        c.width,
                        chunk,
                        &mut scratch,
                    )
                    .unwrap();
                }
                elapsed += start.elapsed().as_nanos();
                std::hint::black_box((&s, &out));
            }
            println!("TIMING label={label} round={round} variant={} repetitions=4 ns={elapsed} hostbusy={busy:.3} excludes=load_projection_capture_reset_alloc",if which==0{"oracle"}else{"blocked"});
        }
    }
}

#[test]
#[ignore = "root-controlled independent algebra mutation gate"]
fn affine_block_algebra() {
    let dk = 8usize;
    let width = 8usize;
    let n = 9usize;
    let mut c = AffineCapture {
        q: vec![0.0; n * dk],
        k: vec![0.0; n * dk],
        v: vec![0.5; n * width],
        decay: vec![0.5; n],
        beta: vec![0.5; n],
        entry: vec![0.125; dk * width],
        oracle: Vec::new(),
        exit: Vec::new(),
        dk,
        width,
    };
    for t in 0..n {
        c.q[t * dk + t % dk] = 0.5;
        c.k[t * dk + t % dk] = 1.0;
    }
    let (o, s) = affine_f64(&c, n);
    for chunk in [8usize, 16, 32, 64] {
        let (got, exit) = affine_block_run(&c, n, chunk);
        for (a, b) in got.iter().zip(&o) {
            assert_eq!(
                f64::from(*a),
                *b,
                "blocked independent f64 algebra output chunk{chunk}"
            );
        }
        for (a, b) in exit.iter().zip(&s) {
            assert_eq!(
                f64::from(*a),
                *b,
                "blocked independent f64 algebra state chunk{chunk}"
            );
        }
    }
    println!("AFFINE_ALGEBRA exact_basis_power_two=passed partial9 chunks=8,16,32,64");
}
