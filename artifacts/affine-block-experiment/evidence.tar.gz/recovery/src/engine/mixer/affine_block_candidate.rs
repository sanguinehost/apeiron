//! Experimental causal blocked gated-delta recurrence with different binary32 rounding sites.
//! State layout is dk*width, row-major. Inputs and outputs are token-major; q is already scaled.
//! Pairwise decay products avoid divisions by cumulative gates. This is not production parity,
//! a quality bound, or an extracted/source-linked proof. FMA/Horner reassociation is explicit.
//! SCOPE: this file only. REGISTER: experimental arithmetic/test. CORPUS: exact-ring
//! GatedDelta.recurrent_eq_chunked pointer; no binary32 link. REFERENCE: actual W5
//! mixer/f32_carrier.rs scaled-state recurrence. GATE: root affine capture/oracle/control,
//! initially MISSING, whole invocation540s. GRADE: untested/unmeasured at source handback.

#[derive(Default)]
pub struct Scratch {
    m: Vec<f32>,
    qproj: Vec<f32>,
    delta: Vec<f32>,
    initial: Vec<f32>,
    carry: Vec<f32>,
    kk: Vec<f32>,
    qk: Vec<f32>,
    cap: usize,
    dk: usize,
    width: usize,
}
impl Scratch {
    /// O(chunk*width+chunk²) initialized words, allocated once before a timed call.
    pub fn new(chunk: usize, dk: usize, width: usize) -> Result<Self, &'static str> {
        if chunk == 0 || dk == 0 || width == 0 {
            return Err("zero geometry");
        }
        let cw = chunk.checked_mul(width).ok_or("scratch size")?;
        let cc = chunk.checked_mul(chunk).ok_or("scratch size")?;
        Ok(Self {
            m: vec![0.0; cw],
            qproj: vec![0.0; cw],
            delta: vec![0.0; cw],
            initial: vec![0.0; chunk],
            carry: vec![0.0; cc],
            kk: vec![0.0; cc],
            qk: vec![0.0; cc],
            cap: chunk,
            dk,
            width,
        })
    }
}

/// Allocating wrapper; use blocked_with_scratch for allocation-excluded kernel timings.
/// O(tokens*dk*width + tokens*chunk*(dk+width)) operations, O(chunk*width+chunk²) scratch.
pub fn blocked(
    state: &mut [f32],
    outputs: &mut [f32],
    q: &[f32],
    k: &[f32],
    v: &[f32],
    decay: &[f32],
    beta: &[f32],
    dk: usize,
    width: usize,
    chunk: usize,
) -> Result<(), &'static str> {
    let mut scratch = Scratch::new(chunk, dk, width)?;
    blocked_with_scratch(
        state,
        outputs,
        q,
        k,
        v,
        decay,
        beta,
        dk,
        width,
        chunk,
        &mut scratch,
    )
}

/// Initial state projections, causal triangular solve, causal readouts, then one state write.
/// O(tokens*dk*width+tokens*chunk*(dk+width)) FMA/multiply operations; scratch is caller-owned.
/// No allocation in this function. Invalid lengths/inputs refuse before mutation; a nonfinite
/// arithmetic result may leave earlier completed blocks committed, so this is an experiment API.
pub fn blocked_with_scratch(
    state: &mut [f32],
    outputs: &mut [f32],
    q: &[f32],
    k: &[f32],
    v: &[f32],
    decay: &[f32],
    beta: &[f32],
    dk: usize,
    width: usize,
    chunk: usize,
    sc: &mut Scratch,
) -> Result<(), &'static str> {
    if chunk == 0 || dk == 0 || width == 0 {
        return Err("zero geometry");
    }
    let tokens = decay.len();
    if state.len() != dk.checked_mul(width).ok_or("state size")?
        || beta.len() != tokens
        || q.len() != tokens.checked_mul(dk).ok_or("query size")?
        || k.len() != q.len()
        || v.len() != tokens.checked_mul(width).ok_or("value size")?
        || outputs.len() != v.len()
        || sc.cap < chunk
        || sc.dk != dk
        || sc.width != width
    {
        return Err("shape mismatch");
    }
    if state
        .iter()
        .chain(q)
        .chain(k)
        .chain(v)
        .chain(decay)
        .chain(beta)
        .any(|x| !x.is_finite())
    {
        return Err("nonfinite input");
    }
    #[cfg(target_arch = "x86_64")]
    let avx = std::is_x86_feature_detected!("avx2")
        && std::is_x86_feature_detected!("fma")
        && width % 8 == 0;
    #[cfg(not(target_arch = "x86_64"))]
    let avx = false;
    for start in (0..tokens).step_by(chunk) {
        let c = chunk.min(tokens - start);
        let qs = &q[start * dk..(start + c) * dk];
        let ks = &k[start * dk..(start + c) * dk];
        let vs = &v[start * width..(start + c) * width];
        let mut a = 1.0f32;
        for i in 0..c {
            a *= decay[start + i];
            sc.initial[i] = a;
            sc.carry[i * c + i] = 1.0;
            let mut pair = 1.0f32;
            for j in (0..i).rev() {
                pair *= decay[start + j + 1];
                sc.carry[i * c + j] = pair;
            }
            for j in 0..=i {
                sc.qk[i * c + j] = dot(&qs[i * dk..(i + 1) * dk], &ks[j * dk..(j + 1) * dk], avx);
                if j < i {
                    sc.kk[i * c + j] =
                        dot(&ks[i * dk..(i + 1) * dk], &ks[j * dk..(j + 1) * dk], avx);
                }
            }
        }
        initial_project(
            state,
            qs,
            ks,
            c,
            dk,
            width,
            &mut sc.m[..c * width],
            &mut sc.qproj[..c * width],
            avx,
        );
        for i in 0..c {
            let (previous, rest) = sc.delta.split_at_mut(i * width);
            let di = &mut rest[..width];
            di.copy_from_slice(&vs[i * width..(i + 1) * width]);
            axpy(di, &sc.m[i * width..(i + 1) * width], -sc.initial[i], avx);
            for j in 0..i {
                let coefficient = -(sc.carry[i * c + j] * sc.kk[i * c + j]);
                axpy(di, &previous[j * width..(j + 1) * width], coefficient, avx);
            }
            for value in di.iter_mut() {
                *value *= beta[start + i];
            }
            let oi = &mut outputs[(start + i) * width..(start + i + 1) * width];
            for j in 0..width {
                oi[j] = sc.initial[i] * sc.qproj[i * width + j];
            }
            for j in 0..=i {
                let coefficient = sc.carry[i * c + j] * sc.qk[i * c + j];
                axpy(oi, &sc.delta[j * width..(j + 1) * width], coefficient, avx);
            }
        }
        final_state(
            state,
            ks,
            &sc.delta[..c * width],
            &sc.carry[(c - 1) * c..c * c],
            sc.initial[c - 1],
            c,
            dk,
            width,
            avx,
        );
        if state
            .iter()
            .chain(&outputs[start * width..(start + c) * width])
            .any(|x| !x.is_finite())
        {
            return Err("nonfinite block arithmetic");
        }
    }
    Ok(())
}

/// O(dk) eight-lane FMA accumulation and pairwise horizontal reduction; changed dot rounding.
#[inline]
fn dot(a: &[f32], b: &[f32], avx: bool) -> f32 {
    #[cfg(target_arch = "x86_64")]
    if avx {
        return unsafe { simd::dot(a, b) };
    }
    a.iter().zip(b).fold(0.0, |x, (&a, &b)| a.mul_add(b, x))
}
/// O(width) FMAs, no allocation; caller validates equal lengths and AVX eligibility.
#[inline]
fn axpy(dst: &mut [f32], src: &[f32], a: f32, avx: bool) {
    #[cfg(target_arch = "x86_64")]
    if avx {
        unsafe { simd::axpy(dst, src, a) };
        return;
    }
    for (d, &s) in dst.iter_mut().zip(src) {
        *d = a.mul_add(s, *d);
    }
}
/// O(c*dk*width) FMAs; two input projections without token-by-token state writes.
fn initial_project(
    s: &[f32],
    q: &[f32],
    k: &[f32],
    c: usize,
    dk: usize,
    w: usize,
    m: &mut [f32],
    o: &mut [f32],
    avx: bool,
) {
    #[cfg(target_arch = "x86_64")]
    if avx {
        unsafe { simd::project(s, q, k, c, dk, w, m, o) };
        return;
    }
    m.fill(0.0);
    o.fill(0.0);
    for i in 0..dk {
        for t in 0..c {
            for j in 0..w {
                m[t * w + j] = s[i * w + j].mul_add(k[t * dk + i], m[t * w + j]);
                o[t * w + j] = s[i * w + j].mul_add(q[t * dk + i], o[t * w + j]);
            }
        }
    }
}
/// O(c*dk*width) FMAs, each state entry stored once after its block correction.
fn final_state(
    s: &mut [f32],
    k: &[f32],
    d: &[f32],
    carry: &[f32],
    a: f32,
    c: usize,
    dk: usize,
    w: usize,
    avx: bool,
) {
    #[cfg(target_arch = "x86_64")]
    if avx {
        unsafe { simd::write_state(s, k, d, carry, a, c, dk, w) };
        return;
    }
    for i in 0..dk {
        for j in 0..w {
            let mut value = a * s[i * w + j];
            for t in 0..c {
                // MUTATION_ANCHOR: zero the final block outer-product coefficient.
                let coefficient = carry[t] * k[t * dk + i];
                value = coefficient.mul_add(d[t * w + j], value);
            }
            s[i * w + j] = value;
        }
    }
}

#[cfg(target_arch = "x86_64")]
mod simd {
    use std::arch::x86_64::*;
    #[target_feature(enable = "avx2,fma")]
    pub(super) unsafe fn dot(a: &[f32], b: &[f32]) -> f32 {
        let mut acc = _mm256_setzero_ps();
        let mut i = 0;
        while i + 8 <= a.len() {
            acc = _mm256_fmadd_ps(
                _mm256_loadu_ps(a.as_ptr().add(i)),
                _mm256_loadu_ps(b.as_ptr().add(i)),
                acc,
            );
            i += 8;
        }
        let half = _mm_add_ps(_mm256_castps256_ps128(acc), _mm256_extractf128_ps(acc, 1));
        let pair = _mm_hadd_ps(half, half);
        let reduced = _mm_hadd_ps(pair, pair);
        let mut sum = _mm_cvtss_f32(reduced);
        while i < a.len() {
            sum = a[i].mul_add(b[i], sum);
            i += 1;
        }
        sum
    }
    #[target_feature(enable = "avx2,fma")]
    pub(super) unsafe fn axpy(dst: &mut [f32], src: &[f32], a: f32) {
        let scale = _mm256_set1_ps(a);
        for j in (0..dst.len()).step_by(8) {
            let value = _mm256_fmadd_ps(
                scale,
                _mm256_loadu_ps(src.as_ptr().add(j)),
                _mm256_loadu_ps(dst.as_ptr().add(j)),
            );
            _mm256_storeu_ps(dst.as_mut_ptr().add(j), value);
        }
    }
    #[target_feature(enable = "avx2,fma")]
    pub(super) unsafe fn project(
        s: &[f32],
        q: &[f32],
        k: &[f32],
        c: usize,
        dk: usize,
        w: usize,
        m: &mut [f32],
        o: &mut [f32],
    ) {
        // Four token columns and one eight-value stripe stay in eight accumulators.
        for t0 in (0..c).step_by(4) {
            let active = 4.min(c - t0);
            for j in (0..w).step_by(8) {
                let mut am = [_mm256_setzero_ps(); 4];
                let mut ao = [_mm256_setzero_ps(); 4];
                for i in 0..dk {
                    let row = _mm256_loadu_ps(s.as_ptr().add(i * w + j));
                    for t in 0..active {
                        am[t] = _mm256_fmadd_ps(row, _mm256_set1_ps(k[(t0 + t) * dk + i]), am[t]);
                        ao[t] = _mm256_fmadd_ps(row, _mm256_set1_ps(q[(t0 + t) * dk + i]), ao[t]);
                    }
                }
                for t in 0..active {
                    _mm256_storeu_ps(m.as_mut_ptr().add((t0 + t) * w + j), am[t]);
                    _mm256_storeu_ps(o.as_mut_ptr().add((t0 + t) * w + j), ao[t]);
                }
            }
        }
    }
    #[target_feature(enable = "avx2,fma")]
    pub(super) unsafe fn write_state(
        s: &mut [f32],
        k: &[f32],
        d: &[f32],
        carry: &[f32],
        a: f32,
        c: usize,
        dk: usize,
        w: usize,
    ) {
        let scale = _mm256_set1_ps(a);
        for i in 0..dk {
            for j in (0..w).step_by(8) {
                let mut value = _mm256_mul_ps(scale, _mm256_loadu_ps(s.as_ptr().add(i * w + j)));
                for t in 0..c {
                    // MUTATION_ANCHOR: same final block outer product as scalar fallback.
                    let coefficient = carry[t] * k[t * dk + i];
                    value = _mm256_fmadd_ps(
                        _mm256_set1_ps(coefficient),
                        _mm256_loadu_ps(d.as_ptr().add(t * w + j)),
                        value,
                    );
                }
                _mm256_storeu_ps(s.as_mut_ptr().add(i * w + j), value);
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    /// Independent unrounded recurrence in f64; exact basis/power-of-two fixtures isolate the
    /// algebra from rounding. Nonempty initial state and repeated keys exercise triangular terms.
    #[test]
    fn affine_block_algebra_control() {
        for width in [2usize, 32] {
            for chunk in [1usize, 2, 4] {
                let dk = 2;
                let n = 4;
                let keys = [1.0f32, 0.0, 0.0, 1.0, 1.0, 0.0, 0.0, 1.0];
                let q = keys;
                let v: Vec<f32> = (0..n * width)
                    .map(|i| ((i % 7) as f32 - 3.0) * 0.125)
                    .collect();
                let decay = [0.5f32, 1.0, 0.5, 0.25];
                let beta = [0.5f32, 0.25, 1.0, 0.5];
                let initial: Vec<f32> = (0..dk * width)
                    .map(|i| ((i % 5) as f32 - 2.0) * 0.125)
                    .collect();
                let mut reference: Vec<f64> = initial.iter().map(|&v| f64::from(v)).collect();
                let mut expected = vec![0.0f64; n * width];
                for t in 0..n {
                    for x in &mut reference {
                        *x *= f64::from(decay[t]);
                    }
                    let mut delta = vec![0.0f64; width];
                    for j in 0..width {
                        let mut predicted = 0.0;
                        for i in 0..dk {
                            predicted += f64::from(keys[t * dk + i]) * reference[i * width + j];
                        }
                        delta[j] = f64::from(beta[t]) * (f64::from(v[t * width + j]) - predicted);
                    }
                    for i in 0..dk {
                        for j in 0..width {
                            reference[i * width + j] += f64::from(keys[t * dk + i]) * delta[j];
                        }
                    }
                    for j in 0..width {
                        for i in 0..dk {
                            expected[t * width + j] +=
                                reference[i * width + j] * f64::from(q[t * dk + i]);
                        }
                    }
                }
                let mut actual = initial;
                let mut outputs = vec![0.0; n * width];
                blocked(
                    &mut actual,
                    &mut outputs,
                    &q,
                    &keys,
                    &v,
                    &decay,
                    &beta,
                    dk,
                    width,
                    chunk,
                )
                .unwrap();
                assert_eq!(
                    actual.iter().map(|&v| f64::from(v)).collect::<Vec<_>>(),
                    reference,
                    "blocked independent f64 algebra state"
                );
                assert_eq!(
                    outputs.iter().map(|&v| f64::from(v)).collect::<Vec<_>>(),
                    expected,
                    "blocked independent f64 algebra outputs"
                );
            }
        }
    }
}
