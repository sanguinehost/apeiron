from pathlib import Path
import json,hashlib,tarfile,subprocess,time
start=time.monotonic();root=Path('/home/socol/Workspace/apeiron');out=root/'artifacts/affine-block-experiment';receipt=Path('/tmp/opencode/affine-block')
files={}
for p in receipt.rglob('*'):
 if p.is_file() and p.name != "archive-manifest.json":files['receipts/'+str(p.relative_to(receipt))]=p
wt=Path('/tmp/apeiron-affine-block/worktree-agent-APEIRON-STRUCTURAL-SPIKE-affine-capture')
owned=['src/engine/mixer/tests.rs','src/engine/mixer/affine_block_probe.rs','src/engine/mixer/affine_block_candidate.rs','src/engine/step/tests.rs','src/engine/step/affine_block_inputs.rs']
patch=receipt/'owned.patch';patch.write_bytes(subprocess.check_output(['git','diff','--','src/engine/mixer/tests.rs','src/engine/step/tests.rs'],cwd=wt));files['receipts/owned.patch']=patch
for rel in owned:files['recovery/'+rel]=wt/rel
files['report/README.md']=out/'README.md';files['report/plan.md']=root/'docs/epics/structural-decode-search.md'
hashes={name:hashlib.sha256(p.read_bytes()).hexdigest() for name,p in files.items()};manifest=receipt/'archive-manifest.json';manifest.write_text(json.dumps(hashes,indent=2)+'\n');files['manifest.json']=manifest
archive=out/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for name,p in files.items():tar.add(p,arcname=name,recursive=False)
with tarfile.open(archive) as tar:
 for name,h in hashes.items():assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==h,name
info={'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'verified_members':len(hashes),'recovery_files':len(owned),'elapsed_seconds':time.monotonic()-start,'gate':'timeout --kill-after=5 60 python3 /tmp/opencode/affine-block/archive.py','exit_status':0}
(out/'archive-receipt.json').write_text(json.dumps(info,indent=2)+'\n');print(json.dumps(info))
