import os, json, time, signal, subprocess, hashlib, shutil, statistics, re
from pathlib import Path
ROOT=Path('/tmp/apeiron-affine-block/worktree-agent-APEIRON-STRUCTURAL-SPIKE-affine-capture')
OUT=Path('/tmp/opencode/affine-block')
TARGET=Path('/tmp/apeiron-affine-block/target-capture')
CONTROL=Path('/tmp/apeiron-affine-block/control-'+str(os.getpid()))
START=time.monotonic()
ENV={k:v for k,v in os.environ.items() if not k.startswith('APEIRON_')}
ENV.update(CARGO_TARGET_DIR=str(TARGET),APEIRON_THREADS='8',APEIRON_ECORES='16',APEIRON_ECORE_RATIO='2.7',APEIRON_PIN='1',APEIRON_BITPLANE='1',APEIRON_EXACT_SCAN='0',APEIRON_F32_CARRIER='1',APEIRON_AFFINE_MODEL='/home/socol/models/qwen3.5-0.8b/Qwen3.5-0.8B-Q8_0.gguf',APEIRON_AFFINE_IDS='/tmp/opencode/prefill-resume/benchmarks/docs200.ids:/tmp/opencode/prefill-resume/benchmarks/code200.ids',APEIRON_AFFINE_PROBE_MODE='check')
R={'budget_seconds':540,'records':[],'status':'incomplete','numerical_contract':'experimental binary32 block rounding; no quality acceptance or source proof','metric':'isolated f32 head recurrence, loading/projection/capture/state reset/alloc excluded','source_preparation':'unaccepted: publication deadline565/540s','timing':'unrun'}
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def run(label,test,cwd=ROOT,extra=None,ignored=False):
 left=530-(time.monotonic()-START)
 if left<=0:raise TimeoutError('whole invocation budget')
 cmd=['cargo','test','--release','--locked','--lib',test,'--']
 if ignored:cmd+=['--ignored']
 cmd+=['--nocapture','--test-threads=1']
 env=ENV.copy();env.update(extra or {})
 begin=time.monotonic()
 with (OUT/(label+'.log')).open('wb') as f:
  p=subprocess.Popen(cmd,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
  try:p.wait(timeout=left)
  except BaseException:
   os.killpg(p.pid,signal.SIGKILL);p.wait();raise
 text=(OUT/(label+'.log')).read_text(errors='replace')
 row={'label':label,'command':cmd,'cwd':str(cwd),'exit_status':p.returncode,'elapsed_seconds':time.monotonic()-begin}
 R['records'].append(row);print(json.dumps(row),flush=True)
 return p.returncode,text
try:
 R['identity']={'base_revision':'3f29041c23697ab7aebab23da95fa900d3ff27b4','source_sha256':{str(p.relative_to(ROOT)):sha(p) for d in ['src','derive','fold-abi'] for p in (ROOT/d).rglob('*.rs')},'model_sha256':sha(ENV['APEIRON_AFFINE_MODEL']),'fixture_sha256':{p:sha(p) for p in ENV['APEIRON_AFFINE_IDS'].split(':')},'cpu':next(x.split(':',1)[1].strip() for x in Path('/proc/cpuinfo').read_text().splitlines() if x.startswith('model name')),'affinity':sorted(os.sched_getaffinity(0)),'rustc':subprocess.check_output(['rustc','--version','--verbose'],text=True),'environment':{k:v for k,v in ENV.items() if k.startswith('APEIRON_')}}
 code,text=run('algebra-positive','affine_block_algebra_control')
 assert code==0 and '1 passed' in text,('algebra positive',text[-4000:])
 code,text=run('real-capture-check','affine_block_real_inputs',ignored=True)
 assert code==0 and text.count('AFFINE_CAPTURE_VALID')==8,('capture',text[-6000:])
 R['capture_validation']={'passes':8,'comparison':'selected full-head post-normalization Q32 readouts and all selected exit-state f32 bits; raw scratch parity indirect'}
 R['discrepancy_lines']=[x for x in text.splitlines() if x.startswith(('AFFINE_STATS','AFFINE_F64','AFFINE_CONTINUATION'))]
 CONTROL.mkdir()
 for d in ['src','derive','fold-abi','tests']:
  if (ROOT/d).exists():shutil.copytree(ROOT/d,CONTROL/d)
 for name in ['Cargo.toml','Cargo.lock','build.rs']:
  if (ROOT/name).exists():shutil.copy2(ROOT/name,CONTROL/name)
 source=CONTROL/'src/engine/mixer/affine_block_candidate.rs';saved=source.read_bytes()
 needle='let coefficient = carry[t] * k[t * dk + i];'
 assert saved.decode().count(needle)==2,'mutation identity'
 source.write_text(saved.decode().replace(needle,'let coefficient = 0.0 * carry[t] * k[t * dk + i];'))
 code,text=run('missing-final-update-mutant','affine_block_algebra_control',cwd=CONTROL)
 assert code!=0 and 'blocked independent f64 algebra' in text and 'could not compile' not in text,('mutation survived/unrelated',text[-4000:])
 R['mutation']='actual scalar and AVX final-update coefficients zeroed in disposable copy; independent algebra state assertion rejects'
 source.write_bytes(saved)
 code,text=run('restored-algebra','affine_block_algebra_control',cwd=CONTROL)
 assert code==0 and '1 passed' in text and sha(source)==sha(ROOT/'src/engine/mixer/affine_block_candidate.rs'),('restoration',text[-4000:])
 R['correctness']='scoped capture/algebra positives, attributable source mutant rejection and restoration passed'
 code,text=run('real-head-timing','affine_block_real_inputs',extra={'APEIRON_AFFINE_PROBE_MODE':'timing'},ignored=True)
 assert code==0 and text.count('AFFINE_CAPTURE_VALID')==8,('timing run',text[-4000:])
 raw=[x for x in text.splitlines() if x.startswith(('TIMING ','AFFINE_TIMING '))]
 blocked=[x for x in text.splitlines() if x.startswith('AFFINE_TIMING_BLOCKED')]
 R['timing_raw']=raw;R['timing_blocked']=blocked
 samples={}
 for x in raw:
  m=re.search(r'label=(\S+) round=(\d+) variant=(oracle|blocked) repetitions=4 ns=(\d+) hostbusy=([\d.]+)',x)
  assert m,('timing format',x)
  label,round_id,arm,ns,busy=m.groups();assert float(busy)<5 and int(ns)>0
  samples.setdefault(label,{}).setdefault(int(round_id),{})[arm]=int(ns)
 R['kernel_ratios']={}
 for label,rounds in samples.items():
  if set(rounds)==set(range(5)) and all(set(v)=={'oracle','blocked'} for v in rounds.values()):
   ratios=[v['oracle']/v['blocked'] for v in rounds.values()]
   R['kernel_ratios'][label]={'median_recurrent_over_blocked':statistics.median(ratios),'range':[min(ratios),max(ratios)],'rounds':rounds}
 R['timing']='complete' if len(R['kernel_ratios'])==96 and not blocked else 'incomplete host quietness/population'
 R['status']='scoped correctness passed; '+R['timing']
except BaseException as e:
 R['status']='failed';R['error']=repr(e);print(R['error'],flush=True)
finally:
 R['elapsed_seconds']=time.monotonic()-START
 (OUT/'receipt.json').write_text(json.dumps(R,indent=2)+'\n')
 print('GATE',R['status'],R['elapsed_seconds'],flush=True)
 if R['status']=='failed':raise SystemExit(1)
