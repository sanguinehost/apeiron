# APEIRON-STRUCTURAL-SPIKE-affine-capture

Decision: source prepared; ownership released to root. No Cargo/model/timing execution by this worker. Gate and control are unrun. No tested/proved/measured acceptance.

SCOPE: owned `src/engine/mixer/tests.rs` and new `src/engine/mixer/affine_block_probe.rs`, task worktree `/tmp/apeiron-affine-block/worktree-agent-APEIRON-STRUCTURAL-SPIKE-affine-capture`, base3f29041. Existing tests source only gains one include. Root separately owns step test bridge, candidate agent owns experimental candidate. No runtime mixer/f32/step/pool/GEMM edits.
REGISTER: test/experimental measurement. Numerical quality, extraction, production integration and2x acceptance excluded.
CORPUS: exact-ring GatedDelta recurrence is a model pointer; no executing f32 refinement or fresh Lean run.
REFERENCE: actual task mixer.rs, mixer/f32_carrier.rs, step/cols.rs and loader.rs; root's latest structural-decode-search plan.
GATE: initially MISSING; root owns `timeout --kill-after=5 540 python3 /tmp/opencode/affine-block/gate.py`, all builds/capture/mutation/restoration/timing inside one budget. Gate-first command artifact written before owned source.
GRADE: design before execution; zero acceptance claims.

Root projection bridge API: `Engine::affine_probe_inputs(ids) -> Result<(layer, projections[conv,z,b,a], eps), StepError>`. Actual root bridge uses resident indexed projection bodies and actual embedding/norm/gain. Loading/projections are excluded from this kernel metric.

Candidate API: `blocked(state,outputs,q,k,v,decay,beta,dk,width,chunk)`; `Scratch::new(chunk,dk,width)` and matching `blocked_with_scratch(...,chunk,&mut scratch)`. State is dk×width row-major; q is already scaled by1/sqrt(dk), k unit-normalized. Raw output precedes stage2.

Ignored test commands (private Cargo target/lane/bounds supplied by root):
```
cargo test --release --locked --lib affine_block_real_inputs -- --ignored --nocapture --test-threads=1
cargo test --release --locked --lib affine_block_algebra -- --ignored --nocapture --test-threads=1
```
Required environment: `APEIRON_AFFINE_MODEL`, `APEIRON_AFFINE_IDS` colon-separated docs/code token files; `APEIRON_AFFINE_PROBE_MODE=check|timing`. Missing inputs are errors, never skips.

Population: first real affine layer, heads0/7/15 where present, constructor F32, slices1 and4 (width128 and32), initial128/tail127, real64-token prefix then suffix64/tail63. All selected slices are captured and replayed; actual source convolution range, normalization, sigmoid/softplus/exp, recurrence and gated norm execute. Capture asserts full-head stage2 readouts and every selected slice's exit state bits against actual delta_heads_cols_carrier. Production raw_f32 scratch is not exported: raw replay validity is indirect through exact gated outputs and exit state, not direct scratch observation.

Candidate chunks8/16/32/64 compare every raw output/final-state element with source recurrence: finite checks, bit mismatches, max absolute error and RMS. A source recurrence step resumes after each partial candidate block and reports next-readout/state disparity. Independent f64 recurrence smoke check declares1e-3*max(1,max oracle magnitude), not a quality threshold. Separate no-model ignored algebra test uses exact dyadic values and basis vectors at n9 with partial tails, requiring exact independent f64 agreement. Expected mutation diagnostic: `blocked independent f64 algebra`. Candidate agent's final-state coefficient zeroing anchor is root's disposable control, not a worker mutation of the task source.

Timing mode only: selected heads' first value slice for width32 and whole width128; all slices retain correctness coverage. Four repetitions per variant, five alternating-order pairs per case,300ms /proc/stat quiet check<5% per pair. Candidate scratch allocated before intervals. Reset, allocation, capture, projection/loading excluded; source recurrence and candidate execution included. ERROR and TIMING lines are parseable. Quiet failure prints AFFINE_TIMING_BLOCKED and leaves that population incomplete; no inferred ratio.

SHA256 tests.rs: `b70d8fb529a2233f59fefed1cb56d738ccfe30d472df3117d9593bb683e1066d`.
SHA256 affine_block_probe.rs: `7fc42b0886f231390c1731cda97d1ccd2de1a8e992b2b29725095ab3551b59b4`.
Probe rustfmt with skip_children passed. No foreign source edited, no commit/push, worktree intact. Root owns next bounded execution and any compile fixes after this ownership release. Explicit question: does the actual root gate validate capture and independent algebra, and what numerical/performance discrepancies does it observe?
