from pathlib import Path
import json,re,hashlib,statistics
out=Path('/tmp/opencode/affine-block')
r=json.loads((out/'receipt.json').read_text())
s=(out/'real-capture-check.log').read_text();summary={}
for line in s.splitlines():
 m=re.search(r'^ERROR label=([^,]+),.* count=(\d+) bit_mismatches=(\d+) maxabs=([\d.e+-]+) rms=([\d.e+-]+)',line)
 if m:
  kind,count,bits,error,rms=m.groups()
  row=summary.setdefault(kind,dict(cases=0,words=0,bit_mismatches=0,max_absolute=0.,max_case_rms=0.))
  row['cases']+=1;row['words']+=int(count);row['bit_mismatches']+=int(bits);row['max_absolute']=max(row['max_absolute'],float(error));row['max_case_rms']=max(row['max_case_rms'],float(rms))
assert summary['output']['cases']==480 and summary['state']['cases']==480
assert summary['resumed_readout']['cases']==240 and summary['resumed_state']['cases']==240
assert s.count('AFFINE_CAPTURE_VALID')==8
pairs={}
for line in r['timing_raw']:
 m=re.search(r'label=(\S+) round=(\d+) variant=(oracle|blocked) repetitions=4 ns=(\d+)',line)
 label,round_id,arm,ns=m.groups();pairs.setdefault((label,int(round_id)),{})[arm]=int(ns)
partial=[dict(label=label,round=round_id,recurrent_over_blocked=v['oracle']/v['blocked'],nanoseconds=v) for (label,round_id),v in pairs.items() if len(v)==2]
result={'receipt_sha256':hashlib.sha256((out/'receipt.json').read_bytes()).hexdigest(),'capture_log_sha256':hashlib.sha256((out/'real-capture-check.log').read_bytes()).hexdigest(),'discrepancy':summary,'complete_five_round_cases':len(r['kernel_ratios']),'partial_pairs_not_acceptance':partial,'head_cases_timing_blocked':len(r['timing_blocked']),'control_status':r['correctness'],'whole_invocation_elapsed':r['elapsed_seconds'],'quality':'open; scale-aware f64 smoke checks are arithmetic diagnostics, not output-quality acceptance'}
(out/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
