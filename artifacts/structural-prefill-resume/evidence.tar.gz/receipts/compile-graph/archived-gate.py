import os, pathlib, subprocess, time, json, shutil, hashlib, statistics, glob, re
ROOT=pathlib.Path('/home/socol/oc-tmp/decode-dispatch/worktree-agent-APEIRON-STRUCTURAL-SPIKE-compile-graph')
LOG=pathlib.Path('/tmp/opencode/structural-dispatch/compile-graph')
SCRATCH=pathlib.Path('/home/socol/oc-tmp/decode-dispatch')
TARGET=SCRATCH/'target-compile-graph'
OWN=['src/engine/step.rs','src/engine/step/cols.rs','src/engine/step/graph.rs']
MODEL='/home/socol/models/qwen3.5-0.8b/Qwen3.5-0.8B-Q8_0.gguf'
PROMPT='/home/socol/Workspace/apeiron/tests/fixtures/qwen35-prompt2.ids'
start=time.monotonic(); commands=[]; samples=[]
def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(1048576),b''): h.update(b)
 return h.hexdigest()
def run(label, cmd, cwd=ROOT, target=TARGET, carrier='q32', extra=None, expected=0):
 env=os.environ.copy(); env.update(APEIRON_THREADS='8',APEIRON_ECORES='16',APEIRON_PIN='1',APEIRON_ECORE_RATIO='2.7',APEIRON_BITPLANE='1',CARGO_TARGET_DIR=str(target),APEIRON_CARRIER=carrier,APEIRON_EXACT_SCAN='0',APEIRON_GEMM_SWIGLU='1',APEIRON_COMPILE_GRAPH='1',TMPDIR=str(SCRATCH))
 if extra: env.update(extra)
 remain=530-(time.monotonic()-start)
 if remain<=0: raise RuntimeError('gate budget exhausted')
 t=time.monotonic(); p=subprocess.run(cmd,cwd=cwd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=remain)
 (LOG/(label+'.log')).write_text(p.stdout)
 commands.append(dict(label=label,cmd=cmd,cwd=str(cwd),target=str(target),carrier=carrier,env={k:v for k,v in env.items() if k.startswith('APEIRON_') or k=='CARGO_TARGET_DIR'},exit=p.returncode,elapsed=time.monotonic()-t))
 print(label,p.returncode,round(commands[-1]['elapsed'],3),flush=True)
 if p.returncode!=expected: raise RuntimeError(label+' unexpected exit; '+p.stdout[-2500:])
 return p.stdout
def test(label, root=ROOT,target=TARGET,carrier='q32',expected=0):
 return run(label,['cargo','test','--release','--locked','--lib','engine::step::graph::tests::compiled_graph_model_parity','--','--ignored','--exact','--nocapture'],root,target,carrier,expected=expected)
def quiet():
 def stat():
  a=list(map(int,pathlib.Path('/proc/stat').read_text().splitlines()[0].split()[1:]));return sum(a),a[3]+a[4]
 deadline=time.monotonic()+30
 while True:
  a=stat();time.sleep(.5);b=stat();busy=1-(b[1]-a[1])/max(1,b[0]-a[0])
  if busy<.05:return busy
  if time.monotonic()>deadline:raise RuntimeError('CPU not quiet')
try:
 assert pathlib.Path(MODEL).is_file() and pathlib.Path(PROMPT).is_file()
 test('positive-q32');test('positive-f32',carrier='f32')
 control=SCRATCH/'control-compile-graph'
 if control.exists():raise RuntimeError('control path already exists')
 control.mkdir()
 for name in ['src','derive','fold-abi','examples','tests']:
  if (ROOT/name).exists():shutil.copytree(ROOT/name,control/name)
 for name in ['Cargo.toml','Cargo.lock','build.rs']:
  if (ROOT/name).exists():shutil.copy2(ROOT/name,control/name)
 p=control/OWN[2];good=p.read_text()
 needle='layers: engine.resolve_layers(),'
 assert good.count(needle)==1
 p.write_text(good.replace(needle,'layers: { let mut layers = engine.resolve_layers(); for li in &mut layers { li.idx.swap(4, 5); } layers },'))
 output=test('mutated-graph-binding',control,SCRATCH/'target-compile-graph-mutant',expected=101)
 assert 'graph prompt hidden parity' in output and 'assertion' in output
 p.write_text(good)
 test('restored-graph-binding',control,SCRATCH/'target-compile-graph-restored')
 # Drive the already-built test executable directly; no compilation or Cargo dispatch is timed.
 bins=[]
 for name in glob.glob(str(TARGET/'release/deps/apeiron-*')):
  p=pathlib.Path(name)
  if p.is_file() and os.access(p,os.X_OK) and not p.suffix: bins.append(p)
 assert len(bins)==1,bins
 exe=str(bins[0])
 ids={}
 for round in range(5):
  arms=[(carrier,cached,n) for carrier in ['q32','f32'] for n in [200,1024] for cached in [0,1]]
  arms=arms[round%len(arms):]+arms[:round%len(arms)]
  for carrier,cached,n in arms:
   busy=quiet()
   out=run(f'round-{round}-{carrier}-{cached}-{n}',[exe,'--ignored','--exact','--nocapture','engine::step::graph::tests::compiled_graph_timing'],carrier=carrier,extra={'APEIRON_COMPILE_GRAPH':str(cached),'APEIRON_GRAPH_LENGTH':str(n)})
   m=re.search(r'GRAPH_SAMPLE (true|false) ([0-9]+) ([0-9.eE+-]+) ([0-9]+)',out);assert m
   assert int(m[2])==n
   key=(carrier,n)
   token=int(m[4])
   if key in ids:assert token==ids[key],'cached-vs-original prefill ID mismatch'
   else:ids[key]=token
   samples.append(dict(round=round,carrier=carrier,cached=cached,length=n,tps=float(m[3]),busy=busy,token=token))
 stats={}
 for carrier in ['q32','f32']:
  for n in [200,1024]:
   plain=[r['tps'] for r in samples if r['carrier']==carrier and r['length']==n and not r['cached']]
   cached=[r['tps'] for r in samples if r['carrier']==carrier and r['length']==n and r['cached']]
   stats[f'{carrier}-{n}']=dict(plain_median=statistics.median(plain),cached_median=statistics.median(cached),paired_ratio=statistics.median([cached[i]/plain[i] for i in range(5)]))
 receipt=dict(exit=0,elapsed=time.monotonic()-start,commands=commands,samples=samples,stats=stats,owned={p:sha(ROOT/p) for p in OWN},source={str(p.relative_to(ROOT)):sha(p) for p in sorted((ROOT/'src').rglob('*.rs'))},binary=sha(exe),model=sha(MODEL),prompt=sha(PROMPT),machine=pathlib.Path('/proc/cpuinfo').read_text().split('model name')[1].splitlines()[0],tools=run('rust-version',['rustc','--version']))
 (LOG/'receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(stats),flush=True)
except Exception as e:
 (LOG/'failed-receipt.json').write_text(json.dumps(dict(error=str(e),elapsed=time.monotonic()-start,commands=commands,samples=samples),indent=2));raise
