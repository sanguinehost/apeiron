# Compiled graph resumed measurement handback

Decision: performance remains unmeasured. Source is unchanged and matches every incoming/archive digest. No build, test, model inference or heavy gate ran during this resumed slice.

Read-only preflight after selective-state CPU handback measured host busy6.518%,6.592%,9.040%, above the unchanged5% threshold. This repeats the original quiet blocker; no protocol, population or threshold is relaxed. The original whole gate remains historical exit1 in100.844s with positive Q32/f32 parity, intended changed-binding red and restoration green, but no performance sample.

The prepared full540s runner retains both lengths200/1024, both carriers, five quiet paired rounds, all positives/control/restoration and a unique disposable control path. The1024 fixture cycles the README200 token IDs; state allocation, plan construction and final head are included. The candidate is a metadata graph cache, not evidence of a2x gain.

Source SHA256: step.rs84e3d70e8b413fda48de191052603b6a8e2ee7c34f4906132054cc679840e874; step/cols.rs b0bf2a11378d8c0f6e1c6061925cef213b1f0c2c83f56622333d7ef84055abc0; step/graph.rs7d34ba75ce8aa86ca6314bd880720525fc6aecbb758955e4f48bef2e1382e0dc. Existing binarySHA300cce6b80751f2d3a4ca551366ec1101c303d2306527c68f5f46264c6931637. ModelSHA37ae482d336108d23516fa35e8e0c4126688d81018b87178a18d752a1357814f.

All three logical paths are released to the lead for sequenced tasks. Private worktree/branch remain for lead archive and cleanup. No other workstream or process was changed. Next bounded question: can actual pooled norm outputs retain the original per-column Vec directly, preserving fallback/refusal ownership while removing the flat output buffer and two copies? It requires its own controls and prefill measurement.
