# Direct norm diff review

Decision: permit the focused executable test; no proof, integration or performance acceptance.

Budget120seconds; observed60.278seconds, within bound. Read actual cols.rs diff and gate.py, Pool::chunks_mut/run, attn_heads and rms_with_gain_slice. Candidate SHA2560e21aa9d66d50888173ee123ba20b69a93d7ed40f8300a3cebc0d9ea2b262f88.

Actual scalar call is retained once per column in a disjoint Option<Result> slot. Pool run joins before ordered collect. The existing earliest-index error rule is preserved by index collection rather than completion order. Baseline serial/ragged/zero-width/product-overflow path remains reachable and unchanged. Zero-width panic and excessive-task panic fixtures call actual legacy and direct branches. Allocation abort/peak storage equivalence is explicitly excluded; result allocation and slot metadata differ.

Gate mutation changes actual source index c to0, with distinct successful columns and attributable comparison diagnostic. Actual error fixtures distinguish Norm(OutOfRange) from gain Overflow in both column orders. Both-carrier real-prefill successful state population follows. Restore uses original source bytes; no formula is restated as norm oracle. Runtime selection uses a once-read environment flag, requiring separate processes for A/B.

Before gate: format owned file, freeze digest and confirm source manifest except cols.rs unchanged. Gate must still execute exit0 under540seconds; build/test/control failures retain task open. Scalar apeiron_word.rms_norm_refines_proved pointer does not prove the gain/pool wrapper; no Lean run. Unsafe existing pool, allocation failure, compiler/ABI and full integration remain excluded/open.
