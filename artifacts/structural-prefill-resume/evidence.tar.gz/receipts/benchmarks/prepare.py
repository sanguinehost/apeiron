from pathlib import Path
import tarfile
root=Path('/home/socol/Workspace/apeiron');wt=Path('/home/socol/oc-tmp/decode-dispatch/worktree-agent-APEIRON-STRUCTURAL-SPIKE-benchmarks');ev=Path('/tmp/opencode/prefill-resume/benchmarks')
with tarfile.open(root/'artifacts/structural-prefill-dispatch/evidence.tar.gz') as tar:
 for m in tar.getmembers():
  if m.name.startswith('benchmarks/headers/') and m.isfile():
   dest=ev/'headers'/Path(m.name).name;dest.parent.mkdir(exist_ok=True);dest.write_bytes(tar.extractfile(m).read())
p=wt/'tools/structural_decode_bench.py';s=p.read_text()
s=s.replace('e = dict(os.environ, APEIRON_CERTHEAD_BATCH="0", APEIRON_PREFILL_COLS="64", APEIRON_THREADS="8")','e = {k: v for k, v in os.environ.items() if not k.startswith("APEIRON_")}\n        e.update(APEIRON_CERTHEAD_BATCH="0", APEIRON_PREFILL_COLS="64", APEIRON_THREADS="8", APEIRON_ECORES="16", APEIRON_ECORE_RATIO="2.7", APEIRON_PIN="1", APEIRON_BITPLANE="1", APEIRON_EXACT_SCAN="0")')
s=s.replace('"llama_revision": cfg["llama_revision"],','"llama_revision": cfg["llama_revision"],\n            "settings": {"columns":64,"threads":8,"ecores":16,"ratio":2.7,"pin":1,"bitplane":1,"exact_scan":0},\n            "headers": {str(p):digest(p) for p in Path(cfg["headers"]).glob("*.h")},')
s=s.replace('"env": env or {}','"env": {k:v for k,v in e.items() if k.startswith("APEIRON_")}')
p.write_text(s)
(ev/'code.txt').write_bytes((wt/'src/engine/step.rs').read_bytes())
(ev/'docs.txt').write_bytes((root/'docs/direction.md').read_bytes())
