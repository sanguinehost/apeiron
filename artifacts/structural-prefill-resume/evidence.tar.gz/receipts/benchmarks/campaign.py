import os,time,json,hashlib,subprocess
from pathlib import Path
wt=Path('/home/socol/oc-tmp/decode-dispatch/worktree-agent-APEIRON-STRUCTURAL-SPIKE-benchmarks')
ev=Path('/tmp/opencode/prefill-resume/benchmarks')
target=Path('/home/socol/oc-tmp/decode-dispatch/target-benchmarks')
libs=Path('/home/socol/Workspace/llama.cpp/build-cpu/bin')
model='/home/socol/models/qwen3.5-0.8b/Qwen3.5-0.8B-Q8_0.gguf'
cpp=str(ev/'llama-context')
start=time.monotonic()
record={'budget':540,'commands':[],'stage':'setup','predeclared_population':['docs200','code200','docs1024','code1024'],'rounds':5}
def remaining():
 n=530-(time.monotonic()-start)
 if n<=0:raise RuntimeError('whole invocation budget exhausted')
 return n
def run(cmd,name):
 began=time.monotonic()
 e=dict(os.environ,CARGO_TARGET_DIR=str(target))
 with (ev/(name+'.out')).open('w') as log:
  p=subprocess.run(cmd,cwd=wt,env=e,stdout=log,stderr=subprocess.STDOUT,timeout=remaining())
 record['commands'].append({'command':cmd,'exit':p.returncode,'elapsed':time.monotonic()-began,'cwd':str(wt)})
 print(name,p.returncode,round(time.monotonic()-began,3),flush=True)
 assert p.returncode==0,(name,(ev/(name+'.out')).read_text()[-2500:])
def digest(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
try:
 record['stage']='build'
 build=['c++','-O3','-std=c++17','-I'+str(ev/'headers'),str(wt/'examples/llama_context.cpp'),'-L'+str(libs),'-Wl,-rpath,'+str(libs),'-lllama','-lggml','-lggml-base','-o',cpp]
 run(build,'cpp-build')
 run(['cargo','build','--release','--locked','--example','lookup_probe'],'engine-build')
 record['stage']='fixtures'
 cases=[]
 for kind in ['docs','code']:
  run([cpp,model,'--tokenize',str(ev/(kind+'.txt')),str(ev/(kind+'-full.ids'))],'tokenize-'+kind)
  ids=(ev/(kind+'-full.ids')).read_text().split()
  assert len(ids)>=1024
  for n in [200,1024]:
   p=ev/(kind+str(n)+'.ids');p.write_text('\n'.join(ids[:n])+'\n')
   cases.append({'name':kind+str(n),'ids':str(p),'tokens':n,'sha256':digest(p),'text_source_sha256':digest(ev/(kind+'.txt'))})
 cfg={'source_root':str(wt),'rounds':5,'model':model,'engine':str(target/'release/examples/lookup_probe'),'cpp':cpp,'cpp_source':str(wt/'examples/llama_context.cpp'),'cpp_build':build,'headers':str(ev/'headers'),'llama_revision':'0324696b8','libraries':[str(libs/p) for p in ['libllama.so.0','libggml.so.0','libggml-cpu.so.0','libggml-base.so.0']],'cases':cases}
 (ev/'protocol.json').write_text(json.dumps(cfg,indent=2)+'\n')
 record['protocol_sha256']=digest(ev/'protocol.json');record['stage']='controls-and-five-rounds'
 run(['python3',str(wt/'tools/structural_decode_bench.py'),str(ev/'protocol.json'),str(ev/'campaign')],'campaign')
 record['status']=0
except BaseException as exc:
 record['status']=1;record['failure']=repr(exc);raise
finally:
 record['elapsed']=time.monotonic()-start
 (ev/'campaign-receipt.json').write_text(json.dumps(record,indent=2)+'\n')
 print('WHOLE',record.get('status'),record['stage'],record['elapsed'],flush=True)
