# Prefill live-state handback

Result: gate.py exit0,222.071057332seconds within540seconds. Both numerical carriers pass the registered successful constructor-to-prefill population. No performance or new Lean claim.

| stage | exit | elapsed seconds | result |
|---|---:|---:|---|
| Q32 baseline | 0 | 62.929544465 | all eight chunk schedules, hidden/live-state boundaries, head/continuation and refusals |
| f32 baseline | 0 | 84.009869494 | same population, persistent floats compared by bits |
| omitted final multicol token | 101 | 31.679466737 | intended live-state KV occupancy1vs2 red at first width2 boundary |
| restored disposable source | 0 | 43.438946149 | exact restored source, fresh third target, full Q32 population |

Acceptance command: timeout --kill-after=5 540 python3 /tmp/opencode/prefill-resume/prefill-state/gate.py. Each child uses cargo test --release --locked --lib prefill_live_state_chunks -- --nocapture --test-threads=1, under the runner's remaining530second descendant budget. Receipt records exact cwd, target, environment and source digests. Parent outer timeout bounds receipt overhead. No retry ran.

Source: /home/socol/oc-tmp/decode-dispatch/worktree-agent-APEIRON-STRUCTURAL-SPIKE-prefill-state. Base3f29041c23697ab7aebab23da95fa900d3ff27b4 plus archived incoming diagnostic/lookup source. Owned source changed: src/engine/step/spec.rs only, adding the test module. All other incoming Rust hashes, including attn.rs/mixer.rs, match baseline.json. restored control copy's complete Rust hashes also match the source in the receipt. owned.patch is against the recovered incoming source, not HEAD's earlier spec.rs. No commit, merge or foreign-tree edit.

Population: actual constructors with capacity208; Qwen3.5-0.8B Q8_0 and fixture200. Known prefix199 traversed under chunk-width caps1/2/4/8/32/64/128/256. Boundary counts199/100/50/25/7/4/2/1; tail sizes0/1/3/7/7/7/71/199. The width256 schedule is one199-column partial block; no full256-column witness. For each boundary, state comparison precedes every hidden-output comparison. Actual final known token/head plus3greedy continuation steps compare both output and state.

Public prefill_cols full200 matches independently constructed one-column output/state. Public prefill_state full200 matches the reference head/state and3greedy continuations. APEIRON_PREFILL_COLS=64 and APEIRON_EXACT_SCAN=0 are the actual process flags.

Refusals: empty compose_cols/empty prefill_state, out-of-vocabulary embedding and admitted mismatched-KV geometry refuse without changing the observed live state. Empty prefill_cols succeeds unchanged. Capacity1 with2known tokens refuses with CapacityExceeded; no transactional or sequential-prefix failure-state claim.

Observation set: geometry/capacity/scale/occupancy and every live KV word; affine layer/slice/head counts, complete persistent convolution, accumulator and Q32 deferred decay. F32 values compare to_bits. Unoccupied KV tail excluded because successful append overwrites the row before occupancy advances and attention reads occupied rows only. Staged/readout scratch and immutable packed-weight caches are excluded; continuation is checked. Physical allocation, spare capacity, worker scheduling, mutex/atomic representation, compiler/ABI/GPU/unsafe-container correctness and source refinement are excluded.

Control mutates the real compose_cols body only in a complete disposable source copy: tokens.len()>1 takes tokens[..len-1]. Baseline, mutant and restored builds use different Cargo targets. Failure is the intended live-state metadata diagnostic before hidden/output assertions. Source restored byte-for-byte and digest checked after the successful restoration run. control_path is retained in receipt for lead archive/prune; worktree removal remains with lead.

Grade: tested at this fixture/source scope. No theorem was changed or built. GatedDelta.recurrent_eq_chunked_recur remains a ring-model pointer and does not license reassociation of rounded arithmetic. Full Rust tests/clippy/fmt, actual source extraction/Lean refinement, longer fixtures including full256columns and integration remain open. Inherited table locator dead-code warning is retained in logs.

Read-only residual: compose_cols' error prose says state has advanced through columns before the first refusing column. Actual layer-major batching can update earlier affine layers for the whole block before a later softmax layer hits capacity. This gate asserts the refusal, not that stronger failure-state relation. A separate failure-state contract/source review is required; no definition, contract or grade was edited.

Next bounded task: retain this successful-prefix gate for any released-owner prefill state/scratch rewrite; add a separately registered longer known-token fixture for full256-column equivalence before claiming that population. Borrowed staged convolution remains blocked by foreign W6 ownership. Question to lead: retain the diagnostic test candidate and its explicit observation/refusal exclusions as the prefill integration check?
