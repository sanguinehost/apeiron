# Prefill live-state gate

Task APEIRON-STRUCTURAL-SPIKE-prefill-state; owner selective_state. Base3f29041c23697ab7aebab23da95fa900d3ff27b4 with archived incoming diagnostic/lookup source, bound by ../prefill-state-baseline.json. Owned source: src/engine/step/spec.rs only. Foreign W6 mixer/carrier, loader, GEMM and pool paths excluded.

SCOPE: src/engine/step/spec.rs; known-token prefill parity from actual empty constructors. Incoming KV/affine comparators unchanged.
REGISTER: state/test; performance, numeric changes, source refinement and foreign paths excluded.
CORPUS: GatedDelta.recurrent_eq_chunked_recur equates ring recurrence over flattened chunks with ordered chunk folds. Model pointer; no fresh proof or rounded-arithmetic reassociation.
REFERENCE: /home/socol/oc-tmp/decode-dispatch/worktree-agent-APEIRON-STRUCTURAL-SPIKE-prefill-state/src/engine/step.rs:1460 and step/cols.rs:64, read.
GATE: initially MISSING; gate.py written before source edit. timeout --kill-after=5 540 python3 /tmp/opencode/prefill-resume/prefill-state/gate.py. Exact private build lanes and source environments recorded in receipt.json. Heavy execution requires lead grant.
GRADE: untested until gate receipt; no performance or Lean claim.

Population: Qwen3.5-0.8B Q8_0 fixture200; prefix199 known tokens, then actual final token/head; widths1/2/4/8/32/64/128/256. Prefix199 gives partial tail for every width greater than1. Width1 partial tail is inapplicable. At each boundary compare all live state first, then each returned hidden word against actual ordered one-column execution. Continue3 greedy steps from the final head on both states.

Public entry points: prefill_cols full200 output/state versus independently constructed one-column reference; prefill_state full200 head/state plus3greedy continuations. Actual process override APEIRON_PREFILL_COLS=64. Exact scan off; both carrier modes in separate processes.

Refusals: compose_cols empty; prefill_state empty; out-of-vocabulary embedding; mismatched KV geometry from an admitted constructor; capacity1 with2known tokens. Empty prefill_cols succeeds with no state change. Empty/OOV/geometry refusals compare unchanged live state. Capacity refusal may leave partially advanced state; no transactional or accepted-prefix failure claim is made.

Control: complete disposable source copy, unique directory and distinct baseline/mutant/restored Cargo targets. Mutate real compose_cols to omit the last token only when input has multiple columns. The gate compares live state before output count/hidden equality, so the intended rejection is live-state KV metadata. Restore exact source bytes and rerun a fresh target.

Observation set: KV geometry/capacity/scale/occupancy and every live K/V word; affine geometry, complete convolution history, accumulator and deferred decay. F32 compares to_bits. Unoccupied KV tail excluded because append overwrites a complete row before occupancy advances and attention reads only occupied rows. Staged/readout scratch and immutable derived weight caches excluded; successful continuation validates the next executing use. No allocation identity, mutex representation, codegen/ABI/GPU/unsafe-container or source-refinement claim.

Whole gate540seconds over descendants; internal530seconds leaves bounded receipt overhead. Timeout or unrelated compile failure is not an accepted control. Full Rust test/clippy/fmt and Aeneas/Lean integration barriers remain open. No commits or merges. Root archives and removes this worktree after review.
