import pathlib, subprocess, time, os, json, hashlib, shutil, signal
root=pathlib.Path('/home/socol/oc-tmp/decode-dispatch/worktree-agent-APEIRON-STRUCTURAL-SPIKE-prefill-state')
logs=pathlib.Path('/tmp/opencode/prefill-resume/prefill-state')
control=pathlib.Path('/home/socol/oc-tmp/decode-dispatch/control-prefill-state-'+str(os.getpid()))
start=time.monotonic();records=[];status='failed';error='incomplete'
envbase=os.environ.copy();envbase.update(APEIRON_STATE_MODEL='/home/socol/models/qwen3.5-0.8b/Qwen3.5-0.8B-Q8_0.gguf',APEIRON_STATE_IDS='/home/socol/Workspace/apeiron/tests/fixtures/qwen35-prompt2.ids',APEIRON_THREADS='24',APEIRON_EXACT_SCAN='0',APEIRON_PREFILL_COLS='64')
def run(name,cwd,target,carrier):
    env=envbase.copy();env.update(CARGO_TARGET_DIR=target,APEIRON_F32_CARRIER=carrier)
    command=['cargo','test','--release','--locked','--lib','prefill_live_state_chunks','--','--nocapture','--test-threads=1']
    before=time.monotonic();remaining=530-(before-start)
    if remaining<=0:raise TimeoutError('whole invocation budget')
    p=subprocess.Popen(command,cwd=cwd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,start_new_session=True)
    try:output,_=p.communicate(timeout=remaining)
    except subprocess.TimeoutExpired:
        os.killpg(p.pid,signal.SIGKILL);output,_=p.communicate();(logs/(name+'.log')).write_bytes(output);raise
    (logs/(name+'.log')).write_bytes(output)
    records.append(dict(name=name,exit=p.returncode,elapsed=time.monotonic()-before,command=command,cwd=str(cwd),target=target,carrier=carrier));print(records[-1],flush=True)
    return p.returncode,output.decode(errors='replace')
try:
    for carrier in ['0','1']:
        code,out=run('baseline-'+carrier,root,'/home/socol/oc-tmp/decode-dispatch/target-prefill-state',carrier)
        assert code==0,out[-4000:]
        assert all('PREFILL width '+str(w)+':' in out for w in [1,2,4,8,32,64,128,256])
        assert 'PREFILL public paths and refusals passed' in out and '1 passed' in out
    control.mkdir()
    for d in ['src','derive','fold-abi','examples','tests']:
        if (root/d).exists():shutil.copytree(root/d,control/d)
    for f in ['Cargo.toml','Cargo.lock','build.rs']:
        if (root/f).exists():shutil.copy2(root/f,control/f)
    p=control/'src/engine/step/cols.rs';saved=p.read_bytes();s=saved.decode();needle='        let k = tokens.len();\n        let _pass = trace::span(Phase::Pass, k, 0, 0);'
    assert s.count(needle)==1
    s=s.replace(needle,'        let tokens = if tokens.len() > 1 { &tokens[..tokens.len() - 1] } else { tokens };\n'+needle)
    p.write_text(s)
    code,out=run('omitted-column',control,'/home/socol/oc-tmp/decode-dispatch/target-prefill-state-mutant','0')
    assert code!=0 and 'live-state KV metadata' in out,out[-4000:]
    p.write_bytes(saved)
    code,out=run('restored',control,'/home/socol/oc-tmp/decode-dispatch/target-prefill-state-restored','0')
    assert code==0 and 'PREFILL public paths and refusals passed' in out
    status='passed'
except BaseException as e:
    error=repr(e);print(error,flush=True)
finally:
    files={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for d in ['src','derive','fold-abi'] for p in (root/d).rglob('*.rs')}
    receipt=dict(status=status,error=error if status!='passed' else None,elapsed=time.monotonic()-start,budget=540,records=records,environment={k:envbase[k] for k in ['APEIRON_STATE_MODEL','APEIRON_STATE_IDS','APEIRON_THREADS','APEIRON_EXACT_SCAN','APEIRON_PREFILL_COLS']},source_sha256=files,control_path=str(control),model_sha256=hashlib.sha256(pathlib.Path(envbase['APEIRON_STATE_MODEL']).read_bytes()).hexdigest(),fixture_sha256=hashlib.sha256(pathlib.Path(envbase['APEIRON_STATE_IDS']).read_bytes()).hexdigest())
    (logs/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print('GATE',status,receipt['elapsed'],flush=True)
    if status!='passed':raise SystemExit(1)
