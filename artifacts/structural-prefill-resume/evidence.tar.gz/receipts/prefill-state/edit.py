from pathlib import Path
p=Path('/home/socol/oc-tmp/decode-dispatch/worktree-agent-APEIRON-STRUCTURAL-SPIKE-prefill-state/src/engine/step/spec.rs')
s=p.read_text();s+='''

#[cfg(test)]
mod prefill_state_tests {
    use super::*;
    use crate::engine::DecodeState;

    // Executing column primitive; time/space are compose_cols' model-dependent bounds.
    fn columns(engine: &Engine, state: &mut DecodeState, tokens: &[u32]) -> Result<Vec<Vec<i64>>, StepError> {
        engine.compose_cols(&mut state.kv, state.affine.as_mut(), tokens,
            Sched::Resident, KernelMode::Q8Act, true, None)
    }

    // Time: one comparison per hidden word. Space: O(1), with the first differing index in the diagnostic.
    fn assert_hidden(a: &[Vec<i64>], b: &[Vec<i64>], width: usize) {
        assert_eq!(a.len(), b.len(), "prefill hidden column count width {width}");
        for (column, (a,b)) in a.iter().zip(b).enumerate() {
            assert_eq!(a.len(), b.len(), "prefill hidden shape width {width} column {column}");
            let difference=a.iter().zip(b).enumerate().find(|(_, (x,y))| x!=y);
            assert!(difference.is_none(), "prefill hidden width {width} column {column}: {difference:?}");
        }
    }

    // Time: eight ordered/batched traversals of the prefix plus public-path checks;
    // each boundary compares the live state. Space: two states and O(chunk width * embedding width)
    // hidden outputs; the public full-output check holds O(prompt length * embedding width) words.
    #[test]
    fn prefill_live_state_chunks() {
        let engine=Engine::open(&std::env::var("APEIRON_STATE_MODEL").expect("real model required")).expect("open model");
        let prompt: Vec<u32>=std::fs::read_to_string(std::env::var("APEIRON_STATE_IDS").expect("fixture required"))
            .expect("read fixture").split_whitespace().map(|s| s.parse().expect("token id")).collect();
        assert_eq!(prompt.len(),200,"registered full prompt");
        let cap=prompt.len()+8;
        let (last,prefix)=prompt.split_last().expect("nonempty fixture");
        assert_eq!(prefix.len(),199,"registered partial-tail prefix");
        for width in [1,2,4,8,32,64,128,256] {
            let mut batched=engine.state(cap).expect("batched constructor");
            let mut serial=engine.state(cap).expect("serial constructor");
            assert_live_decode_eq(&batched,&serial);
            let mut boundaries=0;
            for block in prefix.chunks(width) {
                let actual=columns(&engine,&mut batched,block).expect("batched known columns");
                let mut expected=Vec::with_capacity(block.len());
                for token in block {
                    expected.extend(columns(&engine,&mut serial,std::slice::from_ref(token)).expect("one known column"));
                }
                assert_live_decode_eq(&batched,&serial);
                assert_hidden(&actual,&expected,width);
                boundaries+=1;
            }
            let mut next=engine.next_token_state(&mut batched,*last,KernelMode::Q8Act).expect("batched final head");
            assert_eq!(next,engine.next_token_state(&mut serial,*last,KernelMode::Q8Act).expect("serial final head"),"prefill head width {width}");
            assert_live_decode_eq(&batched,&serial);
            for continuation in 0..3 {
                let reference=engine.next_token_state(&mut serial,next,KernelMode::Q8Act).expect("serial continuation");
                next=engine.next_token_state(&mut batched,next,KernelMode::Q8Act).expect("batched continuation");
                assert_eq!(next,reference,"prefill continuation width {width} step {continuation}");
                assert_live_decode_eq(&batched,&serial);
            }
            println!("PREFILL width {width}: {boundaries} boundaries, tail {}, hidden/state/head/continuation passed",prefix.len()%width);
        }
        let mut serial=engine.state(cap).expect("public reference constructor");
        let mut expected=Vec::with_capacity(prompt.len());
        for token in &prompt { expected.extend(columns(&engine,&mut serial,std::slice::from_ref(token)).expect("public reference one column")); }
        let mut all=engine.state(cap).expect("prefill_cols constructor");
        let actual=engine.prefill_cols(&mut all,&prompt,KernelMode::Q8Act).expect("actual prefill_cols");
        assert_live_decode_eq(&all,&serial);
        assert_hidden(&actual,&expected,super::super::prefill_block());
        let predicted=engine.head_argmax_cols(&expected[expected.len()-1..],engine.config.vocab_size).expect("reference final head")[0];
        let mut public=engine.state(cap).expect("prefill_state constructor");
        assert_eq!(engine.prefill_state(&mut public,&prompt,KernelMode::Q8Act).expect("actual prefill_state"),predicted);
        assert_live_decode_eq(&public,&serial);
        let mut next=predicted;
        for step in 0..3 {
            let reference=engine.next_token_state(&mut serial,next,KernelMode::Q8Act).expect("public serial continuation");
            next=engine.next_token_state(&mut public,next,KernelMode::Q8Act).expect("public continuation");
            assert_eq!(next,reference,"public continuation {step}"); assert_live_decode_eq(&public,&serial);
        }
        let mut empty=engine.state(cap).expect("refusal constructor");
        let before=empty.clone();
        assert!(matches!(columns(&engine,&mut empty,&[]),Err(StepError::BadConfig("empty token block"))));
        assert_live_decode_eq(&empty,&before);
        assert!(engine.prefill_cols(&mut empty,&[],KernelMode::Q8Act).expect("empty column list").is_empty());
        assert_live_decode_eq(&empty,&before);
        assert!(matches!(engine.prefill_state(&mut empty,&[],KernelMode::Q8Act),Err(StepError::BadConfig("empty prompt"))));
        assert_live_decode_eq(&empty,&before);
        assert!(columns(&engine,&mut empty,&[engine.config.vocab_size as u32]).is_err(),"out-of-vocabulary refusal");
        assert_live_decode_eq(&empty,&before);
        let mut wrong=engine.state(cap).expect("geometry constructor");
        let cfg=&engine.config;
        wrong.kv=KvState::new(wrong.kv.n_layer(),cfg.n_head,cfg.n_head_kv,cfg.head_dim+1,cap).expect("wrong admitted KV geometry");
        let before=wrong.clone();
        assert!(matches!(columns(&engine,&mut wrong,&prompt[..2]),Err(StepError::KvGeometry {..})));
        assert_live_decode_eq(&wrong,&before);
        let mut small=engine.state(1).expect("small actual constructor");
        assert!(matches!(columns(&engine,&mut small,&prompt[..2]),Err(StepError::Kv(crate::engine::attn::AttnError::CapacityExceeded {cap:1}))),"capacity refusal");
        // Capacity failure may leave partial state; no transactional refusal claim is made.
        println!("PREFILL public paths and refusals passed; actual prefill block {}",super::super::prefill_block());
    }
}
''';p.write_text(s)
