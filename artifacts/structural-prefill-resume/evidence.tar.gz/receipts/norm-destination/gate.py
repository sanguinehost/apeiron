import pathlib, subprocess, time, os, json, hashlib, shutil, signal
root=pathlib.Path('/home/socol/oc-tmp/decode-dispatch/worktree-agent-APEIRON-STRUCTURAL-SPIKE-norm-destination')
logs=pathlib.Path('/tmp/opencode/prefill-resume/norm-destination')
control=pathlib.Path('/home/socol/oc-tmp/decode-dispatch/control-norm-destination-'+str(os.getpid()))
start=time.monotonic();records=[];status='failed';error='incomplete'
envbase=os.environ.copy();envbase.update(APEIRON_STATE_MODEL='/home/socol/models/qwen3.5-0.8b/Qwen3.5-0.8B-Q8_0.gguf',APEIRON_STATE_IDS='/home/socol/Workspace/apeiron/tests/fixtures/qwen35-prompt2.ids',APEIRON_THREADS='24',APEIRON_EXACT_SCAN='0',APEIRON_PREFILL_COLS='64',APEIRON_NORM_DIRECT='1')
def run(name,cwd,target,carrier,test):
    env=envbase.copy();env.update(CARGO_TARGET_DIR=target,APEIRON_F32_CARRIER=carrier)
    command=['cargo','test','--release','--locked','--lib',test,'--','--nocapture','--test-threads=1']
    before=time.monotonic();remaining=530-(before-start)
    if remaining<=0:raise TimeoutError('whole invocation budget')
    p=subprocess.Popen(command,cwd=cwd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,start_new_session=True)
    try:output,_=p.communicate(timeout=remaining)
    except subprocess.TimeoutExpired:
        os.killpg(p.pid,signal.SIGKILL);output,_=p.communicate();(logs/(name+'.log')).write_bytes(output);raise
    (logs/(name+'.log')).write_bytes(output)
    records.append(dict(name=name,exit=p.returncode,elapsed=time.monotonic()-before,command=command,cwd=str(cwd),target=target,carrier=carrier));print(records[-1],flush=True)
    return p.returncode,output.decode(errors='replace')
try:
    code,out=run('norm-fixtures',root,'/home/socol/oc-tmp/decode-dispatch/target-norm-destination','0','norm_destination_fixtures')
    assert code==0 and 'NORM fixtures and error order passed' in out,out[-4000:]
    for carrier in ['0','1']:
        code,out=run('prefill-'+carrier,root,'/home/socol/oc-tmp/decode-dispatch/target-norm-destination',carrier,'prefill_live_state_chunks')
        assert code==0 and 'PREFILL public paths and refusals passed' in out,out[-4000:]
        assert all('PREFILL width '+str(w)+':' in out for w in [1,2,4,8,32,64,128,256])
    control.mkdir()
    for d in ['src','derive','fold-abi','examples','tests']:
        if (root/d).exists():shutil.copytree(root/d,control/d)
    for f in ['Cargo.toml','Cargo.lock','build.rs']:
        if (root/f).exists():shutil.copy2(root/f,control/f)
    p=control/'src/engine/step/cols.rs';saved=p.read_bytes();s=saved.decode();needle='slot[0] = Some(rms_with_gain_slice(gain, &xs[c], eps));'
    assert s.count(needle)==1
    p.write_text(s.replace(needle,'slot[0] = Some(rms_with_gain_slice(gain, &xs[0], eps));'))
    code,out=run('duplicated-column',control,'/home/socol/oc-tmp/decode-dispatch/target-norm-destination-mutant','0','norm_destination_fixtures')
    assert code!=0 and 'norm direct/legacy column order' in out,out[-4000:]
    p.write_bytes(saved)
    code,out=run('restored',control,'/home/socol/oc-tmp/decode-dispatch/target-norm-destination-restored','0','norm_destination_fixtures')
    assert code==0 and 'NORM fixtures and error order passed' in out,out[-4000:]
    status='passed'
except BaseException as e:
    error=repr(e);print(error,flush=True)
finally:
    files={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for d in ['src','derive','fold-abi'] for p in (root/d).rglob('*.rs')}
    modelhash=hashlib.sha256(pathlib.Path(envbase['APEIRON_STATE_MODEL']).read_bytes()).hexdigest();inputhash=hashlib.sha256(pathlib.Path(envbase['APEIRON_STATE_IDS']).read_bytes()).hexdigest()
    receipt=dict(status=status,error=error if status!='passed' else None,elapsed=time.monotonic()-start,budget=540,records=records,environment={k:envbase[k] for k in ['APEIRON_STATE_MODEL','APEIRON_STATE_IDS','APEIRON_THREADS','APEIRON_EXACT_SCAN','APEIRON_PREFILL_COLS','APEIRON_NORM_DIRECT']},source_sha256=files,control_path=str(control),model_sha256=modelhash,fixture_sha256=inputhash,measurement='not run; lead owns separate full prefill A/B population')
    (logs/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print('GATE',status,receipt['elapsed'],flush=True)
    if status!='passed':raise SystemExit(1)
