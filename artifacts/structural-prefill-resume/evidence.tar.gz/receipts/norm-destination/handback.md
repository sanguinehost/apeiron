# APEIRON-STRUCTURAL-SPIKE-norm-destination

Decision: focused correctness gate passed, exit 0, 138.261306421 seconds of the 540-second whole-invocation budget. CPU lane released. Candidate remains for lead review; no integration, proof or performance acceptance.

Owned source: `/home/socol/oc-tmp/decode-dispatch/worktree-agent-APEIRON-STRUCTURAL-SPIKE-norm-destination/src/engine/step/cols.rs` only. Base `3f29041c23697ab7aebab23da95fa900d3ff27b4`, branch `codex/structural-norm-destination`, incoming overlay bound by `baseline.json`. All other incoming Rust source digests unchanged; root-owned `examples/prefill_norm_probe.rs` excluded from this source ownership check.

Change: rectangular nonzero-width norm tasks retain each actual scalar RMS/gain result Vec in disjoint generic pool slots, removing the flat k*n norm temporary and two result copies. Index-ordered collection preserves the lowest-column error. `APEIRON_NORM_DIRECT=0/1` selects reachable original/candidate implementations, read once; default candidate on for the spike. Scalar, ragged, zero-width and checked-product-overflow paths delegate to the original implementation. Pool bounds and arithmetic are unchanged. Equality scope assumes successful allocation; allocator failure and peak-memory behavior are excluded.

Gate command, cwd the task worktree:
```
timeout --kill-after=5 540 python3 /tmp/opencode/prefill-resume/norm-destination/gate.py
```

| stage | exit | seconds |
|---|---:|---:|
| direct/actual-legacy norm fixtures | 0 | 12.805253877 |
| Q32 actual prefill live-state chunks | 0 | 58.757808696 |
| f32 actual prefill live-state chunks | 0 | 41.325116945 |
| duplicate-column source mutation | 101 | 12.451422502 |
| exact-byte restoration | 0 | 12.470001944 |

The total includes all positives, control/restoration, source/model/input hashing and receipt generation. Fixture coverage includes distinct columns, nominal/extreme values, scalar/ragged cases, eps/gain errors, distinguishable earliest Norm versus Overflow errors, empty/zero-width legacy panic and excessive-task legacy panic. Expected panics are caught and compared, not gate failures.

Mutation in complete disposable copy changes the real pooled scalar input `&xs[c]` to `&xs[0]`; the expected attributable red is `assertion left == right failed: norm direct/legacy column order`. Restored owned-source SHA equals candidate SHA. Distinct private targets were used for candidate, mutant and restoration. Control copy remains `/home/socol/oc-tmp/decode-dispatch/control-norm-destination-544305` for lead cleanup.

Actual prefill scope: Qwen3.5-0.8B Q8_0, existing 200-token fixture, independent empty constructors; 199 known tokens in widths 1/2/4/8/32/64/128/256, including partial tails. At every chunk boundary, compare all hidden values and live KV/recurrent state against ordered one-column execution. Public prefill/head and three continuation tokens, empty/OOV/geometry refusals and capacity refusal execute. Width 256 is a 199-column partial block; a full 256-column block is untested. Capacity refusal establishes the error only, not partial-state prefix equivalence.

Live observation set: KV geometry/capacity/scaling/occupied rows and live K/V values; affine layer/slice/head shape, convolution history, recurrent accumulators and Q32 deferred decay; f32 values compare to_bits. Unoccupied KV tail is excluded because append overwrites complete rows before advancing occupancy and attention reads occupied rows only. Scratch/readout buffers and immutable packed-weight caches are excluded; continuation is checked.

Source SHA256: `3c406d4e08fd6ad4015c9473ab2e4023ea7c50a8de3034d9b107a40c9d5d3bf2`.
Owned patch SHA256: `42c273b17a4591e7a7a46c40429e89649c72b7801f1d144d023928fbc4e1f292`.
Model SHA256: `37ae482d336108d23516fa35e8e0c4126688d81018b87178a18d752a1357814f`.
Fixture SHA256: `894a166ae31393f33425ed7d1fd0b3eed0801c26a3c7095d90825d66fb240443`.

Artifacts: `receipt.json`, `candidate.json`, `owned.patch`, `gate.py`, `norm-fixtures.log`, `prefill-0.log`, `prefill-1.log`, `duplicated-column.log`, `restored.log` in this directory. Toolchain: rustc 1.97.0-nightly (17584a181 2026-04-13). Environment: 24 workers, exact scan 0, prefill cols 64, norm direct 1; separate carrier 0/1 processes. Commands are release/locked lib tests with one test thread and private Cargo targets.

Grade: tested at this focused population only. No Lean/Kani run, no new proof theorem or attribution, no arithmetic change, no measurement or 2x claim. Full workspace test/clippy/fmt and extraction/bridge integration barrier remain unrun. No codegen/ABI/GPU/unsafe-container proof, resource-failure equivalence or generalized model claim follows.

Next bounded task: lead-owned matched full-prefill norm A/B campaign, then integration review. Explicit question: does that campaign establish enough measured benefit to retain this tested candidate? Keep this worktree intact until lead archives or integrates it.
