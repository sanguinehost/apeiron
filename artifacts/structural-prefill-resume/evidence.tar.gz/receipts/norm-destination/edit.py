from pathlib import Path
root=Path('/home/socol/oc-tmp/decode-dispatch/worktree-agent-APEIRON-STRUCTURAL-SPIKE-norm-destination');p=root/'src/engine/step/cols.rs';s=p.read_text();start=s.index('/// Each column\'s `RMSNorm` with gain:');stop=s.index('/// The pooled int8 quantization',start)
old=s[start:stop];legacy=old.replace('fn norm_cols(', 'fn norm_cols_legacy(')
new='''/// Each column's actual scalar norm result, retained in one disjoint destination slot.
/// Time: O(k*n) scalar work and O(k) slot scheduling; space: O(k*n) result words
/// plus O(k) slots. The legacy flat k*n temporary and its two value copies are absent.
/// Equality covers successful allocation; allocator abort/peak-memory behavior is not preserved.
fn norm_cols_direct(gain: &[i64], xs: &[Vec<i64>], eps: i64) -> Result<Vec<Vec<i64>>, StepError> {
    let (k, n) = (xs.len(), xs.first().map_or(0, Vec::len));
    if k < 2 || n == 0 || k.checked_mul(n).is_none() || xs.iter().any(|x| x.len() != n) {
        return norm_cols_legacy(gain, xs, eps);
    }
    let mut out: Vec<Option<Result<Vec<i64>, StepError>>> = (0..k).map(|_| None).collect();
    crate::engine::chart::pool::Pool::global().chunks_mut(&mut out, 1, &|c, _start, slot| {
        slot[0] = Some(rms_with_gain_slice(gain, &xs[c], eps));
    });
    // Joining precedes index-order collection, so the first refusing column stays the first error.
    out.into_iter().map(|slot| slot.expect("norm destination slot not written")).collect()
}

/// Spike selection read once: APEIRON_NORM_DIRECT=0 runs the reachable legacy path.
/// Time: O(1) after initial environment read; space: O(1).
fn norm_direct_enabled() -> bool {
    static DIRECT: OnceLock<bool> = OnceLock::new();
    *DIRECT.get_or_init(|| std::env::var("APEIRON_NORM_DIRECT").map_or(true, |v| v != "0"))
}

/// Norm implementation selected once; both branches call the actual scalar norm/gain body.
/// Time/space: the selected implementation's O(k*n) bounds.
fn norm_cols(gain: &[i64], xs: &[Vec<i64>], eps: i64) -> Result<Vec<Vec<i64>>, StepError> {
    if norm_direct_enabled() { norm_cols_direct(gain, xs, eps) }
    else { norm_cols_legacy(gain, xs, eps) }
}

'''
s=s[:start]+legacy+new+s[stop:];s+='''

#[cfg(test)]
mod norm_destination_tests {
    use super::*;
    use crate::engine::NormError;
    const ONE: i64 = 1 << 32;

    // Time: the two norm executions plus O(k*n) comparisons; space: two result populations.
    fn compare(gain: &[i64], xs: &[Vec<i64>], eps: i64) {
        assert_eq!(norm_cols_direct(gain,xs,eps),norm_cols_legacy(gain,xs,eps),"norm direct/legacy column order");
        let chosen=if norm_direct_enabled() {norm_cols_direct(gain,xs,eps)} else {norm_cols_legacy(gain,xs,eps)};
        assert_eq!(norm_cols(gain,xs,eps),chosen,"norm selected path");
    }

    // Time: one catch around an executing path; space: its allocation bounds and panic message.
    fn panic_message(f: impl FnOnce() + std::panic::UnwindSafe) -> String {
        let panic=std::panic::catch_unwind(f).expect_err("legacy panic must stay reachable");
        if let Some(message)=panic.downcast_ref::<String>() { message.clone() }
        else if let Some(message)=panic.downcast_ref::<&str>() { (*message).to_string() }
        else { panic!("unexpected non-text panic") }
    }

    // Time: finite scalar/pooled fixture executions and panic controls; space: largest fixture/results.
    #[test]
    fn norm_destination_fixtures() {
        compare(&[ONE;4], &[vec![ONE,2*ONE,-ONE,0],vec![3*ONE,0,ONE,-ONE],vec![0,ONE,-2*ONE,ONE]],ONE/1024);
        for k in [0,1,2,3,8,17,64] {
            for n in [1,2,4,32,128,1024] {
                let gain:Vec<i64>=(0..n).map(|j| ONE+((j%3) as i64)*(ONE/8)).collect();
                let xs:Vec<Vec<i64>>=(0..k).map(|c| (0..n).map(|j| (((c*7+j*11)%29) as i64-14)*(ONE/8)).collect()).collect();
                compare(&gain,&xs,ONE/1024);
            }
        }
        compare(&[],&[],i64::MIN);
        compare(&[],&[vec![]],ONE);
        compare(&[ONE],&[vec![]],ONE);
        compare(&[ONE;2],&[vec![ONE],vec![ONE,0]],ONE);
        compare(&[ONE;2],&[vec![ONE,0],vec![ONE]],ONE);
        for eps in [i64::MIN,-ONE,-1,0,1,ONE,i64::MAX] {
            compare(&[ONE;2],&[vec![0,0],vec![ONE,0]],eps);
            compare(&[i64::MIN,i64::MAX],&[vec![ONE,0],vec![0,ONE]],eps);
        }
        compare(&[ONE;2],&[vec![i64::MAX,i64::MAX],vec![i64::MIN,0]],ONE);
        let gain=[i64::MAX;2];
        let norm_error=vec![0,0];let gain_error=vec![ONE,0];
        assert_eq!(rms_with_gain_slice(&gain,&norm_error,0),Err(StepError::Norm(NormError::OutOfRange)),"norm refusal witness");
        assert_eq!(rms_with_gain_slice(&gain,&gain_error,0),Err(StepError::Overflow),"gain refusal witness");
        for _ in 0..32 {
            let xs=[norm_error.clone(),gain_error.clone()];
            compare(&gain,&xs,0);assert_eq!(norm_cols_direct(&gain,&xs,0),Err(StepError::Norm(NormError::OutOfRange)),"lowest norm error");
            let xs=[gain_error.clone(),norm_error.clone()];
            compare(&gain,&xs,0);assert_eq!(norm_cols_direct(&gain,&xs,0),Err(StepError::Overflow),"lowest gain error");
        }
        for gain in [vec![],vec![ONE]] {
            let xs=[vec![],vec![]];
            let a=panic_message(|| {let _=norm_cols_direct(&gain,&xs,0);});
            let b=panic_message(|| {let _=norm_cols_legacy(&gain,&xs,0);});
            assert_eq!(a,b,"zero-width legacy panic");assert!(a.contains("chunk size must be non-zero"));
        }
        let excessive:Vec<Vec<i64>>=(0..crate::engine::chart::pool::MAX_TASKS+1).map(|_|vec![ONE]).collect();
        let a=panic_message(|| {let _=norm_cols_direct(&[ONE],&excessive,ONE);});
        let b=panic_message(|| {let _=norm_cols_legacy(&[ONE],&excessive,ONE);});
        assert_eq!(a,b,"excessive task legacy panic");assert!(a.contains("pool dispatch"));
        println!("NORM fixtures and error order passed");
    }
}
''';p.write_text(s)
