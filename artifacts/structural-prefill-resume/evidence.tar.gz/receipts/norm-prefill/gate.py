import os,signal,time,json,hashlib,subprocess,shutil,re,statistics
from pathlib import Path
ROOT=Path('/home/socol/oc-tmp/decode-dispatch/worktree-agent-APEIRON-STRUCTURAL-SPIKE-norm-destination')
OUT=Path('/tmp/opencode/prefill-resume/norm-prefill')
TARGET=ROOT.parent/'target-norm-prefill'
CONTROL=ROOT.parent/('control-norm-prefill-'+str(os.getpid()))
START=time.monotonic()
CFG=json.loads(Path('/tmp/opencode/prefill-resume/benchmarks/protocol.json').read_text())
ENV={k:v for k,v in os.environ.items() if not k.startswith('APEIRON_')}
ENV.update(APEIRON_CERTHEAD_BATCH='0',APEIRON_PREFILL_COLS='64',APEIRON_THREADS='8',APEIRON_ECORES='16',APEIRON_ECORE_RATIO='2.7',APEIRON_PIN='1',APEIRON_BITPLANE='1',APEIRON_EXACT_SCAN='0')
RECEIPT={'budget':540,'commands':[],'rounds':[],'protocol':{'cases':CFG['cases'],'rounds':5,'arms':['legacy','direct'],'carriers':['q32','f32'],'metric':'full prompt execution including final greedy head, fresh state allocation and model loading excluded','settings':{k:v for k,v in ENV.items() if k.startswith('APEIRON_')},'host_busy_limit':.05}}

def digest(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
def sources():return {str(p.relative_to(ROOT)):digest(p) for folder in ['src','derive','fold-abi'] for p in (ROOT/folder).rglob('*.rs')}
def remaining():
 left=530-(time.monotonic()-START)
 if left<=0:raise TimeoutError('whole invocation budget')
 return left
def run(label,cmd,cwd=ROOT,extra=None,expected=0):
 env=ENV.copy();env.update(extra or {})
 begin=time.monotonic()
 with (OUT/(label+'.log')).open('wb') as f:
  p=subprocess.Popen(cmd,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
  try:p.wait(timeout=remaining())
  except BaseException:
   os.killpg(p.pid,signal.SIGKILL);p.wait();raise
 text=(OUT/(label+'.log')).read_text(errors='replace')
 RECEIPT['commands'].append({'label':label,'cmd':cmd,'cwd':str(cwd),'exit':p.returncode,'elapsed':time.monotonic()-begin,'env':{k:v for k,v in env.items() if k.startswith('APEIRON_') or k=='CARGO_TARGET_DIR'}})
 print(label,p.returncode,round(time.monotonic()-begin,3),flush=True)
 assert p.returncode==expected,(label,text[-3000:])
 return text
def parse(text,count):
 lines=[s for s in text.splitlines() if s.startswith('PREFILL ')]
 assert len(lines)==1,'sample count'
 m=re.fullmatch(r'PREFILL ([0-9]+) ([0-9]+) ([0-9]+)',lines[0]);assert m,'sample format'
 n,ns,token=map(int,m.groups());assert n==count,'prompt count';assert ns>0,'elapsed time'
 return {'tokens':n,'nanoseconds':ns,'tps':n*1e9/ns,'first_id':token}
def stat():
 s=list(map(int,Path('/proc/stat').read_text().splitlines()[0].split()[1:]));return sum(s[:8]),s[3]+s[4]
def quiet():
 deadline=time.monotonic()+min(30,remaining()-1)
 attempts=[]
 while True:
  a=stat();time.sleep(.5);b=stat();busy=1-(b[1]-a[1])/max(1,b[0]-a[0]);attempts.append(busy)
  if busy<.05:return busy
  if time.monotonic()>=deadline:
   RECEIPT['quiet_blocked_busy']=attempts;raise RuntimeError('host quiet gate blocked')
try:
 # Semantic acceptance precedes the measurement task; do not run against an ungated candidate.
 acceptance=json.loads(Path('/tmp/opencode/prefill-resume/norm-destination/receipt.json').read_text())
 assert acceptance['status']=='passed','norm correctness acceptance'
 current=sources()
 for rel,h in acceptance['source_sha256'].items():assert current.get(rel)==h,('correctness source drift',rel)
 RECEIPT['identity']={'source_sha256':current,'probe_sha256':digest(ROOT/'examples/prefill_norm_probe.rs'),'model_sha256':digest(CFG['model']),'cpu':next(s.split(':',1)[1].strip() for s in Path('/proc/cpuinfo').read_text().splitlines() if s.startswith('model name')),'affinity':sorted(os.sched_getaffinity(0)),'rustc':run('rustc',['rustc','--version','--verbose'])}
 for case in CFG['cases']:
  assert len(Path(case['ids']).read_text().split())==case['tokens']
  assert digest(case['ids'])==case['sha256']
 # Output parser checks are necessary to reject incomplete or mislabelled samples.
 for bad,diagnostic in [('PREFILL 201 1 2','prompt count'),('PREFILL 200 0 2','elapsed time'),('PREFILL 200 1 2\nPREFILL 200 1 2','sample count')]:
  try:parse(bad,200)
  except AssertionError as e:assert str(e)==diagnostic
  else:raise AssertionError('parser control survived')
 run('build',['cargo','build','--release','--locked','--example','prefill_norm_probe'],extra={'CARGO_TARGET_DIR':str(TARGET)})
 binary=str(TARGET/'release/examples/prefill_norm_probe');RECEIPT['identity']['binary_sha256']=digest(binary)
 # Seed wrong prompt count in an actual disposable probe, then restore its exact source.
 CONTROL.mkdir()
 for d in ['src','derive','fold-abi','examples','tests']:
  if (ROOT/d).exists():shutil.copytree(ROOT/d,CONTROL/d)
 for f in ['Cargo.toml','Cargo.lock','build.rs']:
  if (ROOT/f).exists():shutil.copy2(ROOT/f,CONTROL/f)
 probe=CONTROL/'examples/prefill_norm_probe.rs';saved=probe.read_bytes();s=saved.decode();needle='prompt.len(), measured.1, measured.0';assert s.count(needle)==1;probe.write_text(s.replace(needle,'prompt.len() + 1, measured.1, measured.0'))
 ct=ROOT.parent/'target-norm-prefill-control';extra={'CARGO_TARGET_DIR':str(ct),'APEIRON_F32_CARRIER':'0','APEIRON_NORM_DIRECT':'1'}
 run('count-mutant-build',['cargo','build','--release','--locked','--example','prefill_norm_probe'],cwd=CONTROL,extra=extra)
 first=CFG['cases'][0];cb=str(ct/'release/examples/prefill_norm_probe')
 bad=run('count-mutant',[cb,CFG['model'],first['ids']],cwd=CONTROL,extra=extra)
 try:parse(bad,first['tokens'])
 except AssertionError as e:assert str(e)=='prompt count';RECEIPT['instrument_control']='actual wrong-count probe rejected'
 else:raise AssertionError('actual count mutation survived')
 probe.write_bytes(saved)
 run('count-restored-build',['cargo','build','--release','--locked','--example','prefill_norm_probe'],cwd=CONTROL,extra=extra)
 restored=parse(run('count-restored',[cb,CFG['model'],first['ids']],cwd=CONTROL,extra=extra),first['tokens'])
 assert digest(probe)==digest(ROOT/'examples/prefill_norm_probe.rs')
 RECEIPT['instrument_restored']=restored
 invalid=OUT/'invalid.ids';invalid.write_text('999999999\n')
 refusal=run('invalid-token',[binary,CFG['model'],str(invalid)],extra={'APEIRON_F32_CARRIER':'0','APEIRON_NORM_DIRECT':'1'},expected=1)
 assert 'TokenOutOfRange' in refusal and 'PREFILL ' not in refusal,'invalid prompt refusal'
 RECEIPT['refusal_control']='actual invalid token refused without sample'
 for round_id in range(5):
  row={'round':round_id,'cases':{}}
  cases=CFG['cases'][round_id%4:]+CFG['cases'][:round_id%4]
  for case in cases:
   row['cases'][case['name']]={}
   carriers=['q32','f32'] if round_id%2==0 else ['f32','q32']
   for carrier in carriers:
    samples={}
    order=['legacy','direct'] if round_id%2==0 else ['direct','legacy']
    for arm in order:
     busy=quiet()
     e={'APEIRON_F32_CARRIER':'1' if carrier=='f32' else '0','APEIRON_NORM_DIRECT':'1' if arm=='direct' else '0'}
     value=parse(run(f'r{round_id}-{case["name"]}-{carrier}-{arm}',[binary,CFG['model'],case['ids']],extra=e),case['tokens']);value['busy_before']=busy;samples[arm]=value
    assert samples['legacy']['first_id']==samples['direct']['first_id'],('first ID mismatch',case['name'],carrier)
    row['cases'][case['name']][carrier]=samples
  RECEIPT['rounds'].append(row);(OUT/'receipt.json').write_text(json.dumps(RECEIPT,indent=2)+'\n')
 summary={}
 for case in CFG['cases']:
  name=case['name'];summary[name]={}
  for carrier in ['q32','f32']:
   values=[r['cases'][name][carrier] for r in RECEIPT['rounds']]
   assert len({v['legacy']['first_id'] for v in values})==1,'repeat first ID drift'
   summary[name][carrier]={'legacy_median_tps':statistics.median(v['legacy']['tps'] for v in values),'direct_median_tps':statistics.median(v['direct']['tps'] for v in values),'paired_direct_over_legacy':statistics.median(v['direct']['tps']/v['legacy']['tps'] for v in values),'paired_ratios':[v['direct']['tps']/v['legacy']['tps'] for v in values]}
 RECEIPT['summary']=summary;RECEIPT['status']='passed'
except BaseException as e:
 RECEIPT['status']='blocked' if 'quiet gate' in str(e) else 'failed';RECEIPT['error']=repr(e);print('FAILURE',repr(e),flush=True)
finally:
 RECEIPT['elapsed']=time.monotonic()-START;RECEIPT['control_path']=str(CONTROL)
 RECEIPT['source_end']=sources()
 if RECEIPT.get('identity',{}).get('source_sha256')!=RECEIPT['source_end']:RECEIPT['status']='failed';RECEIPT['error']='source drift during measurement'
 (OUT/'receipt.json').write_text(json.dumps(RECEIPT,indent=2)+'\n');print('GATE',RECEIPT['status'],RECEIPT['elapsed'],flush=True)
 if RECEIPT['status']!='passed':raise SystemExit(1)
