# Prefill destination buffers and activation lifetimes

Decision: expose reusable output destinations and exact packed-activation lifetimes before attempting a streaming FFN. Largest immediate structural candidate is to keep all full-value arithmetic but stop materialising the full FFN hidden matrix: produce each32-row SwiGLU tile, apply the existing quantiser to that tile, and retain only its codes/scales for the down projection. This is design, not a speedup prediction or proof receipt. The prior coarse certificate found no skipping opportunity; this proposal computes every required value.

SCOPE: this artifact only; no source/model/build/gate runs. REGISTER: planning; implementation, measured throughput and formal refinement excluded. CORPUS: ColumnCover.column_cover_round and split_ffn_exact, generic integer models; quant_locality is tied to ChartDot's different scale. REFERENCE: exact3f29041c23697ab7aebab23da95fa900d3ff27b4 source under /home/socol/oc-tmp/wt/w5-integ, plus live main proof/corpus modules named below. GATE: design read-only slice, budget120s; implementation gate MISSING until separately written. GRADE: anchor/source-derived storage accounting; no new proved/tested/measured claim.

## Actual source and recoverable storage

`src/engine/step/cols.rs:compose_cols` allocates embedding columns, normed columns, mixer outputs, second normed columns and FFN outputs within its layer loop. FfnScratch exists once per pass but batched ffn_cols does not use it for its main fused branch. `norm_cols` allocates a flat k*n vector, calls RMS into another per-column vector and copies it, then constructs k new vectors from the flat slices.

`src/engine/kern/gemm.rs:pack` already shares one input pack across grouped projections. gemm_q8_0_group already removes repeated Q/K/V packing; gemm_q8_0_swiglu already packs gate/up input once and writes hidden columns directly. These savings must not be claimed again. Its result still owns k full n_ff-wide i64 vectors; down then constructs a fresh QuantAct and another packed activation.

Source-derived sizes, excluding Vec headers/capacity slack, for k64, n_embd1024, n_ff3584:

| object | live bytes/formula | recoverable mechanism |
|---|---:|---|
| full FFN hidden | 8*k*n_ff =1,835,008 | replace global matrix with32-row tile and retain identical QuantAct |
| hidden codes/scales | k*n_ff +8*k*(n_ff/32) =286,720 | required observation; retain until down joins |
| norm_cols flat temporary | 8*k*n_embd =524,288 | direct writes into reused column destinations; remove flat-to-column copy |
| one residual-width column batch | 8*k*n_embd =524,288 | reuse capacity after last reader joins; retain residual separately until add |
| hidden GEMM pack | 4*g*(n_ff/32)*8*8 +8*g*(n_ff/32)*8 +4*k +4*g =287,008, g=ceil(k/8)=8 | reusable pack storage; lifetime ends after down dispatch |

Replacing the hidden matrix with a k*32-word local tile plus required QuantAct would eliminate1,818,624 bytes of full-hidden live storage at this shape; this is a storage identity, not measured traffic saved. Existing pack/code memory remains necessary unless a separately checked direct-pack emitter replaces it. A task may pool tiles rather than use one giant tile: per-worker scratch then costs workers*32*k*8 bytes. Check resident capacity before claiming an allocation reduction.

## Destination and lifetime interface

Use a reusable ColumnBatch { rows: Vec<Vec<i64>>, width, active_columns } initially, retaining the current disjoint per-column layout. Constructor/reserve validates every size product and reserves before dispatch. Methods expose one active column or disjoint row-range destinations; buffers are not resized while any worker pointer or borrow is live. A logical ready length is published only after every range is written and joined. Failed fast attempts leave scratch unpublished; fallback overwrites its destination and owns the original error.

`project_into(parts, packed_input, destinations)` keeps existing scalar/i128 overflow checks and row epilogues. PackedInput is an immutable borrow of the exact QuantAct plus reused pack storage, valid only until its last consumer joins. It is shareable by Q/K/V or gate/up because those read the same activation; it is not shareable across attention norm and FFN norm, different layers, or columns with different scales. Scratch must not cache by pointer equality or by contextual-activation hash.

`norm_into(gain, residual, norm_destination)` computes each complete column's sum/inverse RMS before overwriting any input. Preserve gain/product rounding order. The residual lives across mixer projection and the first add; normalized input lives until every mixer reader joins; mixer output dies after its residual add. Reuse the same normalized/output storage for FFN only after this barrier. The FFN quantised hidden remains immutable until the down projection joins. Reuse destinations across layers and across prefill groups; state and snapshot storage remain separate.

A wrapper keeps existing compose_cols signature and creates scratch for legacy callers. A new compose_cols_with_scratch takes reusable destinations. prefill_cols creates one scratch per full prompt and passes it through every group, so allocation amortisation does not require changing the state or speculative callers in the first task. Persistent scratch across requests is a later constructor/retained-capacity task.

## Tile epilogue and arithmetic boundary

Current GEMM task width is16 rows. A quantising SwiGLU epilogue needs complete32-row quantiser blocks. Compute two16-row pieces with the identical gate/up row accumulation and final rounding, preserve the executing Q32 or f32 SiLU/product body, then call the real block quantiser. Repack only after the scale and all32 codes exist. Never quantise either16-row half separately. Ragged shapes and non-Q8_0/Hadamard/unsupported-host paths retain the existing fallback.

Aggregate projection failure before SwiGLU failure, and SwiGLU failure before hidden quantisation refusal; preserve the minimal (column,index) SwiGLU failure. A projection failure discovered in a later tile must still select fallback before reporting an earlier tile's quantiser refusal. No worker may publish a downstream-readable partial result. This producer is pure with respect to KV/affine state; token updates stay in the original causal order and snapshot-after-first-column remains at the same transition.

ColumnCover.column_cover_round permits partitioning an exact sum with one final rounding, but does not permit narrowing/rounding per slice. split_ffn_exact accepts an arbitrary block map phi and elementwise sigma; it is a useful model for locality once the executing quantiser is related to that map. ChartDot.scale is ceil(absmax/127), while actual quant_act calls act_scale for the least covering power of two. Therefore split_ffn_exact_dequant/quant_locality cannot be cited as the current power-of-two source bridge. Pow2Refinement explicitly excludes act_scale, finish and ChartDot; current f16 splitter refinement does not close those gaps. Define a separately gated power-of-two block map and its actual-body relation before upgrading this design's grade. No theorem premise is changed here.

## Exact three-file tasks and controls

| next task | three owned paths | focused gate and control | blockers |
|---|---|---|---|
| Reusable batch destinations | src/engine/step.rs; src/engine/step/cols.rs; src/engine/step/buffers.rs (new, tests embedded) | unchanged output/live-state bits across k1/2/7/64/ragged groups, both carriers, success and malformed dimensions; prefill-reset/reuse across two prompts; mutate last column destination index, require attributable parity failure/restoration | sequence after compile_graph cols ownership; no shared build lane |
| Quantised FFN tile producer | src/engine/kern/gemm.rs; src/engine/kern/ffn_tile.rs (new); src/engine/step/cols.rs | full hidden quantiser code/scale equality against existing fused and fallback routes, both carriers; all-zero/extreme/refusing rows and late failures; mutate shared32-block scale or add per-slice rounding, red/restoration | W6-T01 owns GEMM/module boundary; requires owner handback before dispatch |
| Packed destination reuse | src/engine/kern/gemm.rs; src/engine/kern/pack_buffer.rs (new); src/engine/step/cols.rs | existing pack bytes/exponents and GEMM outputs identical, zero blocks/ragged column groups/reused larger-to-smaller capacity; corrupt padding bias, red/restoration | W6-T01 and cols ownership; serialize after tile task |

Each implementation gate needs a fresh <=540s whole-invocation budget, private Cargo target, mutation copy and source digests. Full Rust/proof integration barriers remain separate and open. No allocation/byte count above establishes performance: next measurement must count allocations/retained capacity and named write/read traffic on actual prefill, including code/scale and pack construction.

## Attention seam and exclusions

attn_head allocates scores and exponent vectors over the causal prefix; attn_head_fused retains scores but accumulates fixed-shift den/num. Allocation accounting alone does not authorise selecting another attention implementation; exact equality and refusal-order gates must bind the selected route. A safe first change is destination-owned score/exp/head scratch per live pool task, with scratch bounded by concurrency. Streaming without those vectors requires exact max pass, exact total pass, then the same rounded per-key weights/value sum; scores may be recomputed only over immutable KV with the original first-refusal order retained. Online max rescaling or generic floating FlashAttention reassociation would be a numeric change. No attention task is dispatched by this artifact.

W6-T04 owns loader; W6-T05 owns pool; W6-T06 owns mixer/f32_carrier. No buffer task changes them. GEMM/cols adaptations await owner release; allocation measurement and any required allocation-failure policy require their own design if current signatures cannot express the retained resource contract. Trust excludes codegen, unsafe pointer validity and source-refinement until their named gates exist.

Source identities (SHA256):

- cols.rs e8d3c6b5204c08dde2efa36a20d4e6f6f91711c54e04987c3821b06fd5a65000
- gemm.rs c34dc61d8d02100474ff7f6b84808760803c7eed258d69103d58764cd3aa6bd1
- chart/mod.rs ae4a4a247f01b8435cb93860554d4b7d795b4c41d804b1d27abe614f23ad68c0
- attn.rs fa036f760ec06b0059f7464f5f278c82b83c41e90e8a6effd0fd28ac73ad637f

Next bounded task: reusable batch destinations after cols ownership is released. Larger tile epilogue remains blocked on W6-T01 and the explicit quantiser/source relation. No source edits, builds, measurements or proof gates run in this design slice.

Design slice elapsed230s against120s requested limit, based on start/end UTC epoch1790767367/1790767597. Budget exceeded; this artifact is an unaccepted design handback, not task closure. No source/build/model/gate invocation occurred.
