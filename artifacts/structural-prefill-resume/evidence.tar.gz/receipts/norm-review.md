# Norm destination review

Task: APEIRON-STRUCTURAL-SPIKE-norm-review. Owner: compile_graph. Budget: 180 seconds, whole read-only design slice. Start: 11:55:23 UTC. Initial artifact: 11:57:20 UTC (117 seconds elapsed). Status: initial source review complete; writer diff absent at three inspections. Grade: design/source reading only; no tests, build, Lean run or performance measurement.

SCOPE: /tmp/opencode/prefill-resume/norm-review.md only; inspect existing norm/pool/scalar theorem and writer diff; no source edits.
REGISTER: semantics/refusal/resource review; proof and integration acceptance excluded.
CORPUS: proof/corpus/Numeric/EngineNormRefinement.lean:726, `apeiron_word.rms_norm_refines_proved : rms_norm_refines`; exact domain at70, statement172. No fresh kernel check.
REFERENCE: actual source paths listed below, read in main and writer worktree.
GATE: bounded source review, 180s; no executable correctness gate allocated to this reviewer.
GRADE: anchor/design; safe-to-focused-test verdict conditional on actual diff; untested/unmeasured.

## Decision

Retaining each actual `rms_with_gain_slice` return vector in a disjoint `Option<Result<Vec<i64>,StepError>>` slot is safe to focused testing for rectangular nonzero-width inputs, provided every slot is populated exactly once, the pool joins before collection, and collection consumes slots in increasing column order. This is a source-level argument, not a new proved claim. No actual candidate diff existed at inspection time.

## Exact boundaries

- Writer baseline `/home/socol/oc-tmp/decode-dispatch/worktree-agent-APEIRON-STRUCTURAL-SPIKE-norm-destination/src/engine/step/cols.rs:843`: k<2 and ragged rows use serial iterator collect and stop on the first error. Preserve this path unchanged.
- Baseline rectangular k>=2,n=0: flat output is empty; `chunks_mut` dispatches zero tasks; `out.chunks(0)` panics. This occurs even when nonempty gain would cause scalar BadConfig. A new serial zero-width fallback changes behavior; an exact legacy fallback preserves it. k=0 returns an empty successful output, k=1 empty with empty gain returns Norm(EmptyRow), and k=1 empty with nonempty gain returns BadConfig("norm gain width").
- `/home/socol/Workspace/apeiron/src/engine/step.rs:235`: gain width check occurs first, then actual scalar RMSNorm, then gain multiply and Q32 rounding/narrowing. The wrapper can return BadConfig, Norm(EmptyRow/OutOfRange), or Overflow. Do not hoist checks or change ordering.
- `/home/socol/Workspace/apeiron/src/engine/chart/ffn.rs:856`: pooled baseline runs all columns, records the smallest failing column index under a Mutex, then returns that error. Ordered slot collect preserves this; first-completed error or reverse collection does not.
- `/home/socol/Workspace/apeiron/src/engine/chart/pool.rs:556`: chunk=1 over k result slots gives exactly k disjoint one-element task slices. T:Send suffices; closure shared reads are immutable. No caller-created raw pointer or new unsafe code is needed.
- Pool::run at456 asserts tasks<=MAX_TASKS (2^20-1), serializes dispatch, publishes borrowed job, waits for every published worker completion, clears job, then rethrows task panic. Retaining results until after return preserves the existing join guarantee. A task must not recursively dispatch on the same pool (Pool field comment310); scalar norm/gain body does not do so.

## Resources and admitted exclusions

Existing successful rectangular path creates flat k*n i64 storage, copies each scalar result into it, then copies every flat column into final vectors. Direct slots retain scalar vectors and remove that flat storage and both full-column copies; arithmetic remains the same. This is a source mechanism observation, not an allocation or speed measurement. Results metadata is O(k), scalar and final data O(k*n), concurrent RMS base scratch O(p*n), p<=pool participants; each scalar routine has its own base plus gain output.

For nonzero rectangular inputs the original flat `k*n` multiplication may overflow usize (debug panic or release wrapping before downstream failure), and flat allocation may fail before any norm is evaluated. A direct slot path can survive where that allocation fails, or allocate different metadata first. Do not claim equivalence for arbitrary k/n or allocator failure. Preserve product-overflow behavior with a checked-product legacy fallback if desired; do not invent a new StepError. Name allocation success and representable k*n as comparison premises. MAX_TASKS refusal remains a panic for nonzero rectangular k>MAX_TASKS; pooling direct k slots must not silently serialize that case. An OOM/panic is not the contract's typed arithmetic refusal.

## Scalar proof boundary

`proof/extract/lib.rs:52` imports actual norm.rs by #[path]; wrapper `word_rms_norm_fixed` at726 calls the body. `proof/regen.sh:189` selects that wrapper. `AxiomAudit/Remaining.lean:265` registers `apeiron_word.rms_norm_refines_proved`.

`rms_norm_domain` requires jointly: nonempty row; actual argument a=rmsMean(row)+eps; rsqrt_window(a); every rounded output fits i64; arithmetic window sum(x_i²)+n*2^31 <=2^127-1; accumulated sum fits i128. Headline726 concludes successful extracted scalar output of the same length and an error bound against `rmsReal(a,x)=toReal(x)/sqrt(toReal(a))`. `RmsNormIdeal.lean:256` adds a mean-rounding term for the ideal reference under the same domain. Empty/refusing equalities also exist at89/109/186/202/219/238. None proves the gain wrapper, pool lifetime/scheduling, column constructor reachability, allocation failure, or this candidate. Norm scalar argument window is [2^-20,2^20] in real Q32 denotation. There is no changed arithmetic to extract in this proposed destination change.

## Meaningful controls

1. Required duplicated-column source mutation: replace scalar source index c with0 in the actual direct worker closure; use at least two distinct successful nonzero columns and exact output comparison to the actual serial scalar call. Identical columns would make this control vacuous. Capture intended mismatch, restore, pass again.
2. Error ordering: rectangular rows [0,0] then [2^32,0], eps0, gains[i]=i64::MAX. First row gives Norm(OutOfRange); second is a gain Overflow candidate because its first normalized coordinate exceeds1. Verify actual error fixtures before relying on them. Reverse rows should return Overflow. Reversing collection or returning last error must fail such a fixture. No scalar formula is restated in the oracle.
3. Fallback population: k=0, k=1; ragged row widths; mismatching gain width; rectangular zero-width columns with empty and nonempty gain. Catch the existing panic explicitly for k>=2,n=0 rather than marking it EmptyRow.
4. Slot completion: distinct columns at counts around pool participant count and non-divisible task counts, plus all-success and multiple-refusal fixtures. Missing slot must fail loudly, never substitute zero or skip a column. Existing Pool join is read, not newly proved here.
5. Real q32/f32 same-prompt prefill equality remains the writer gate, including final head and constructor/state checks. Any performance requires the unchanged five quiet paired rounds and source identity; no speedup inferred from copy count.

## Source identity at initial review

Writer cols.rs baseline SHA256 e8d3c6b5204c08dde2efa36a20d4e6f6f91711c54e04987c3821b06fd5a65000.
Writer step.rs ff24474ef0844ff96a0040aed935c79e513edeca73d7a5439a756b6a84b6cffb.
Pool98e5ce505930ac73793ed479f76b02229160dd00a10506ddbfd0c4a2aab9fa93.
FFN d60f3da889f79d4a23ce18484d52572c90ba35175bb39b92750828028dd2f724.
Norm ea38507913a97fd1c4488a390298bc7708971c4c86253eacea0d6a340d4c1cf5.
Scalar theorem c9616c65a1ba731d7259ead517a5bd803fdd4771e6908f3b0ee5c454b5fbeb4b.
Extraction wrapper2abdc6e4f749fcff2f664f670d0d152a61e30f118f009d9558d6d0f509549d16.

Next bounded question: does the actual one-file candidate preserve zero-width/serial/ragged fallback and lowest-index error while removing only flat storage/copies? Rereview that diff when available; this slice does not wait out the budget.

Slice end: 11:59:34 UTC; observed elapsed 251.993s/180s. Status: BUDGET FAILED (251.993s exceeds180s), actual candidate diff not yet available; no executable gate ran. This review does not close the task. Findings are source-reading notes only. Writer confirms exact legacy fallback also for checked-product failure and ordered result collection. Separate bounded diff rereview remains required.
