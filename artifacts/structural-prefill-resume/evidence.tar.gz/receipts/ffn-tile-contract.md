# FFN tile contract: budget blocker

Decision: design acceptance remains blocked. The180s slice exceeded its budget before artifact publication; the publication guard rejected it at254s. No source writes, builds, model runs or gates occurred.

SCOPE: this artifact only. REGISTER: planning. CORPUS: ColumnCover generic model; ChartDot's ceil scale does not match the executing power-of-two quantiser. REFERENCE: W6-T01 current gemm.rs/mod.rs diff and actual3f29041 cols/quant_act/FFN bodies read. GATE: MISSING implementation gate; design budget180s failed. GRADE: anchor, no new proved/tested/measured claim.

Minimum source findings:16 rows is scheduling, not an algebraic obstruction; two pieces can form one32-row quantiser block. Existing grouped projection shares one pack and existing row primitives write destination pointers; no public quantising32-row producer exists. rows_swiglu can report a SwiGLU error while returning true, leaving its failed lane unwritten: a tile emitter must inspect local errors before reading its tile. Current quantisation refusal maps through StepError::Matvec; SwiGLU maps through StepError::Ffn. Preserve that distinction.

Smallest next task: independently review the tile outcome/error contract before source implementation. Ownership remains W6-T01 GEMM, W6-T04loader, W6-T05pool, W6-T06mixer; none modified. No implementation dispatch-ready claim.
