#!/usr/bin/env python3
"""Five paired rounds of execution-only CPU prefill; every registered case is retained.

Time: 5 * cases * six fresh-process samples, each with one warm execution.
Space: one executing model/context plus O(cases * arms * rounds) receipts.
The outer invocation budget includes all commands and quiet waits.
"""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import re
import statistics
import subprocess
import time


def digest(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def parse(text, count):
    lines = [line for line in text.splitlines() if line.startswith("PREFILL ")]
    assert len(lines) == 1, "sample count"
    m = re.fullmatch(r"PREFILL ([0-9]+) ([0-9]+) ([0-9]+)", lines[0])
    assert m, "sample format"
    n, ns, token = map(int, m.groups())
    assert n == count, "prompt count"
    assert ns > 0, "elapsed time"
    tps = n * 1e9 / ns
    assert math.isfinite(tps), "finite rate"
    return {"prompt_tokens": n, "nanoseconds": ns, "tps": tps, "first_id": token}


def stat():
    v = list(map(int, Path("/proc/stat").read_text().splitlines()[0].split()[1:]))
    return sum(v[:8]), v[3] + v[4]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("protocol")
    ap.add_argument("output")
    args = ap.parse_args()
    protocol_path = Path(args.protocol).resolve()
    cfg = json.loads(protocol_path.read_text())
    out = Path(args.output).resolve()
    out.mkdir(parents=True, exist_ok=False)
    start = time.monotonic()
    receipt = {"protocol": cfg, "protocol_sha256": digest(protocol_path), "commands": [], "rounds": []}

    def remaining():
        budget = 530 - (time.monotonic() - start)
        if budget <= 0:
            raise RuntimeError("whole invocation budget exhausted")
        return budget

    def run(cmd, label, env=None, expected=0):
        began = time.monotonic()
        e = {k: v for k, v in os.environ.items() if not k.startswith("APEIRON_")}
        e.update(APEIRON_CERTHEAD_BATCH="0", APEIRON_PREFILL_COLS="64", APEIRON_THREADS="8", APEIRON_ECORES="16", APEIRON_ECORE_RATIO="2.7", APEIRON_PIN="1", APEIRON_BITPLANE="1", APEIRON_EXACT_SCAN="0")
        e.update(env or {})
        with (out / (label + ".out")).open("w") as log:
            p = subprocess.run(cmd, cwd=cfg["source_root"], env=e, stdout=log,
                               stderr=subprocess.STDOUT, timeout=remaining())
        text = (out / (label + ".out")).read_text()
        receipt["commands"].append({"cmd": cmd, "exit": p.returncode, "elapsed": time.monotonic() - began, "env": {k:v for k,v in e.items() if k.startswith("APEIRON_")}})
        print(label, p.returncode, round(time.monotonic() - began, 3), flush=True)
        assert p.returncode == expected, (label, text[-2000:])
        return text

    def quiet():
        deadline = time.monotonic() + min(30, remaining() - 1)
        while True:
            a = stat()
            time.sleep(.5)
            b = stat()
            busy = 1 - (b[1] - a[1]) / max(1, b[0] - a[0])
            if busy < .05:
                return busy
            if time.monotonic() >= deadline:
                raise RuntimeError("host quiet gate blocked")

    try:
        cases = cfg["cases"]
        assert len(cases) == 4 and cfg["rounds"] == 5
        for case in cases:
            ids = list(map(int, Path(case["ids"]).read_text().split()))
            assert len(ids) == case["tokens"] and ids, "fixture length"
            assert digest(case["ids"]) == case["sha256"], "fixture identity"
        receipt["identity"] = {
            "cpu": next(x.split(":", 1)[1].strip() for x in Path("/proc/cpuinfo").read_text().splitlines() if x.startswith("model name")),
            "model_sha256": digest(cfg["model"]),
            "engine_binary_sha256": digest(cfg["engine"]),
            "cpp_binary_sha256": digest(cfg["cpp"]),
            "sources": {str(p.relative_to(Path(cfg["source_root"]))): digest(p) for p in Path(cfg["source_root"]).glob("src/engine/**/*.rs")},
            "libs": {path: digest(path) for path in cfg["libraries"]},
            "llama_revision": cfg["llama_revision"],
            "settings": {"columns":64,"threads":8,"ecores":16,"ratio":2.7,"pin":1,"bitplane":1,"exact_scan":0},
            "headers": {str(p):digest(p) for p in Path(cfg["headers"]).glob("*.h")},
            "metric": "full prompt execution including final greedy head; state allocation/reset and loading excluded",
        }
        # Instrument control: a changed count emitted by the real comparator must be rejected.
        source = Path(cfg["cpp_source"]).read_text()
        needle = '<<prompt.size()<<" "'
        assert source.count(needle) == 1
        mutant = out / "count-mutant.cpp"
        mutant.write_text(source.replace(needle, '<<(prompt.size()+1)<<" "'))
        compile_cmd = cfg["cpp_build"][:]
        compile_cmd[compile_cmd.index(cfg["cpp_source"])] = str(mutant)
        compile_cmd[-1] = str(out / "count-mutant")
        run(compile_cmd, "control-build")
        first = cases[0]
        text = run([str(out / "count-mutant"), cfg["model"], first["ids"], "8", "1", "pp"], "count-control")
        try:
            parse(text, first["tokens"])
        except AssertionError as exc:
            assert str(exc) == "prompt count", str(exc)
            receipt["mutation_rejection"] = str(exc)
        else:
            raise AssertionError("count mutation survived")
        parse(run([cfg["cpp"], cfg["model"], first["ids"], "8", "1", "pp"], "restored"), first["tokens"])
        invalid = out / "invalid.ids"
        invalid.write_text("999999999\n")
        text = run([cfg["cpp"], cfg["model"], str(invalid), "8", "1", "pp"], "invalid", expected=1)
        assert "invalid prompt ID" in text
        arms = [("cpp", str(t)) for t in [8, 16, 24, 32]] + [(c, "8P+E") for c in ["q32", "f32"]]
        for round_id in range(5):
            row = {"round": round_id, "cases": {}}
            order = cases[round_id % len(cases):] + cases[:round_id % len(cases)]
            for case in order:
                samples = {}
                rotated = arms[round_id % len(arms):] + arms[:round_id % len(arms)]
                for carrier, setting in rotated:
                    busy = quiet()
                    if carrier == "cpp":
                        cmd = [cfg["cpp"], cfg["model"], case["ids"], setting, "1", "pp"]
                        env = {}
                    else:
                        cmd = [cfg["engine"], cfg["model"], case["ids"], "pp"]
                        env = {"APEIRON_F32_CARRIER": "1" if carrier == "f32" else "0"}
                    value = parse(run(cmd, f"r{round_id}-{case['name']}-{carrier}-{setting}", env), case["tokens"])
                    value["busy_before"] = busy
                    samples[f"{carrier}:{setting}"] = value
                assert len({samples[f"cpp:{t}"]["first_id"] for t in [8, 16, 24, 32]}) == 1, "comparator thread ID drift"
                row["cases"][case["name"]] = samples
            receipt["rounds"].append(row)
            (out / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
        summary = {}
        for case in cases:
            name = case["name"]
            values = [r["cases"][name] for r in receipt["rounds"]]
            medians = {str(t): statistics.median(v[f"cpp:{t}"]["tps"] for v in values) for t in [8, 16, 24, 32]}
            best = max(medians, key=medians.get)
            entry = {"cpp_medians": medians, "cpp_fastest_setting": best}
            for c in ["q32", "f32"]:
                key = f"{c}:8P+E"
                assert len({v[key]["first_id"] for v in values}) == 1, "engine repeat ID drift"
                entry[c] = {
                    "median_tps": statistics.median(v[key]["tps"] for v in values),
                    "paired_ratio": statistics.median(v[key]["tps"] / v[f"cpp:{best}"]["tps"] for v in values),
                    "paired_fastest_each_round": statistics.median(v[key]["tps"] / max(v[f"cpp:{t}"]["tps"] for t in [8,16,24,32]) for v in values),
                    "cross_engine_first_id_equal": all(v[key]["first_id"] == v[f"cpp:{best}"]["first_id"] for v in values),
                }
            summary[name] = entry
        receipt["summary"] = summary
        receipt["exit"] = 0
    except BaseException as exc:
        receipt["exit"] = 1
        receipt["failure"] = repr(exc)
        raise
    finally:
        receipt["elapsed_seconds"] = time.monotonic() - start
        (out / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
        print("RECEIPT", json.dumps(receipt.get("summary", receipt.get("failure"))), receipt["elapsed_seconds"], flush=True)


if __name__ == "__main__":
    main()
