#include "llama.h"
#include <algorithm>
#include <chrono>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <vector>
static void quiet_log(enum ggml_log_level, const char *, void *) {}
// Each argmax scans vocabulary once, with lowest-index tie selection.
static llama_token argmax(llama_context *ctx, int nv) {
    float *p = llama_get_logits_ith(ctx, -1);
    if (!p) throw std::runtime_error("missing logits");
    return static_cast<llama_token>(std::max_element(p, p+nv)-p);
}
// Time: prompt prefill plus n-1 decode steps and n vocabulary scans. Space: decode context and n IDs.
static std::pair<std::vector<llama_token>,double> sample(llama_context *ctx, std::vector<llama_token> prompt, int nv, int n, bool pp) {
    llama_memory_clear(llama_get_memory(ctx), true);
    auto prefill_start=std::chrono::steady_clock::now();
    for(size_t offset=0;offset<prompt.size();offset+=512) {
        int count=std::min<size_t>(512,prompt.size()-offset);
        if(llama_decode(ctx,llama_batch_get_one(prompt.data()+offset,count))) throw std::runtime_error("prefill refused");
    }
    llama_synchronize(ctx);
    auto x=argmax(ctx,nv);
    std::vector<llama_token> ids{x};ids.reserve(n);
    if(pp) {
        double ns=std::chrono::duration<double,std::nano>(std::chrono::steady_clock::now()-prefill_start).count();
        return {ids,ns};
    }
    auto start=std::chrono::steady_clock::now();
    for(int i=1;i<n;++i) {
        if(llama_decode(ctx,llama_batch_get_one(&x,1))) throw std::runtime_error("decode refused");
        x=argmax(ctx,nv);ids.push_back(x);
    }
    llama_synchronize(ctx);
    double secs=std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count();
    return {ids,(n-1.0)/secs};
}
int main(int argc,char **argv) {
 try {
    if(argc!=5 && argc!=6)throw std::runtime_error("model ids threads n required, or model --tokenize text output");
    llama_log_set(quiet_log,nullptr);ggml_backend_load_all();llama_backend_init();
    auto mp=llama_model_default_params();mp.n_gpu_layers=0;
    bool tokenize=std::string(argv[2])=="--tokenize";mp.vocab_only=tokenize;
    auto model=llama_model_load_from_file(argv[1],mp);if(!model)throw std::runtime_error("model load refused");
    auto vocab=llama_model_get_vocab(model);int nv=llama_vocab_n_tokens(vocab);
    if(tokenize) {
        std::ifstream input(argv[3]);if(!input)throw std::runtime_error("text unreadable");
        std::string text((std::istreambuf_iterator<char>(input)),std::istreambuf_iterator<char>());
        int need=llama_tokenize(vocab,text.data(),text.size(),nullptr,0,false,true);
        if(need>=0)throw std::runtime_error("unexpected tokenizer capacity");
        std::vector<llama_token> ids(-need);
        int count=llama_tokenize(vocab,text.data(),text.size(),ids.data(),ids.size(),false,true);
        if(count<0)throw std::runtime_error("tokenize refused");std::ofstream output(argv[4]);
        if(!output)throw std::runtime_error("output unreadable");
        for(int i=0;i<count;++i)output<<ids[i]<<"\n";
        llama_model_free(model);llama_backend_free();return 0;
    }
    bool pp=argc==6 && std::string(argv[5])=="pp";
    int n=std::stoi(argv[4]);if(n<(pp?1:2))throw std::runtime_error("invalid generation count");
    std::ifstream f(argv[2]);if(!f)throw std::runtime_error("IDs unreadable");
    std::vector<llama_token> prompt;long long t;
    while(f>>t){if(t<0||t>=nv)throw std::runtime_error("invalid prompt ID");prompt.push_back(t);}
    if(prompt.empty()||!f.eof())throw std::runtime_error("invalid prompt file");
    auto cp=llama_context_default_params();cp.n_ctx=prompt.size()+n+4;
    cp.n_batch=512;cp.n_ubatch=512;cp.n_threads=std::stoi(argv[3]);cp.n_threads_batch=cp.n_threads;
    cp.type_k=GGML_TYPE_F16;cp.type_v=GGML_TYPE_F16;cp.flash_attn_type=LLAMA_FLASH_ATTN_TYPE_AUTO;
    cp.offload_kqv=false;cp.op_offload=false;
    auto ctx=llama_init_from_model(model,cp);if(!ctx)throw std::runtime_error("context refused");
    auto warm=sample(ctx,prompt,nv,n,pp);auto measured=sample(ctx,prompt,nv,n,pp);
    if(warm.first!=measured.first)throw std::runtime_error("warm/fresh IDs differ");
    if(pp) {
        std::cout<<"PREFILL "<<prompt.size()<<" "<<static_cast<long long>(measured.second)<<" "<<measured.first[0]<<"\n";
        llama_free(ctx);llama_model_free(model);llama_backend_free();return 0;
    }
    std::cout<<"SAMPLE "<<measured.second<<" [";
    for(size_t i=0;i<measured.first.size();++i){if(i)std::cout<<", ";std::cout<<measured.first[i];}
    std::cout<<"]\n";
    llama_free(ctx);llama_model_free(model);llama_backend_free();return 0;
 }catch(const std::exception&e){std::cerr<<e.what()<<"\n";return 1;}
}
