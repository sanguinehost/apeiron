use apeiron::engine::{loader::Engine, KernelMode};
use std::{error::Error, time::Instant};

// Time: n full decode steps after prefill. Space: actual decode state and O(n) IDs.
fn greedy(engine: &Engine, prompt: &[u32], n: usize) -> Result<(Vec<u32>, u128), Box<dyn Error>> {
    let mut state = engine.state(prompt.len() + n + 4)?;
    let mut token = engine.prefill_state(&mut state, prompt, KernelMode::Q8Act)?;
    let mut ids = vec![token];
    let started = Instant::now();
    for _ in 1..n {
        token = engine.next_token_state(&mut state, token, KernelMode::Q8Act)?;
        ids.push(token);
    }
    Ok((ids, started.elapsed().as_nanos()))
}

// Time: one full prompt execution; state allocation and model loading are excluded.
// Space: the executing KV/recurrent state and projection buffers.
fn prefill(engine: &Engine, prompt: &[u32]) -> Result<(u32, u128), Box<dyn Error>> {
    let mut state = engine.state(prompt.len() + 5)?;
    let started = Instant::now();
    let token = engine.prefill_state(&mut state, prompt, KernelMode::Q8Act)?;
    Ok((token, started.elapsed().as_nanos()))
}

// Check mode runs actual greedy and both admitted/miss-only lookup modes. Timing
// mode excludes prefill and measures 63 steps after the first predicted token. Complexity is the sum of those executions.
fn main() -> Result<(), Box<dyn Error>> {
    let args: Vec<String> = std::env::args().collect();
    let engine = Engine::open(&args[1])?;
    let prompt: Vec<u32> = std::fs::read_to_string(&args[2])?
        .split_whitespace()
        .map(str::parse)
        .collect::<Result<_, _>>()?;
    if args[3] == "pp" {
        let warm = prefill(&engine, &prompt)?;
        let measured = prefill(&engine, &prompt)?;
        assert_eq!(warm.0, measured.0, "fresh prefill token");
        println!("PREFILL {} {} {}", prompt.len(), measured.1, measured.0);
    } else if args[3] == "check" {
        let mut verified = 0;
        let mut replays = 0;
        for p in [vec![760u32, 6511, 314, 9338, 369], prompt] {
            let (reference, _) = greedy(&engine, &p, 64)?;
            for min_suffix in [2, 4] {
                for width in [2, 4] {
                    for n in [2, 15, 64] {
                        let (ids, stats, _) =
                            engine.probe_lookup_decode(&p, n, min_suffix, width)?;
                        assert_eq!(
                            ids,
                            reference[..n],
                            "window greedy: suffix {min_suffix}, width {width}, n {n}"
                        );
                        verified += stats[0];
                    }
                }
            }
            let (ids, stats, _) = engine.probe_lookup_decode(&p, 64, 1024, 4)?;
            assert_eq!(ids, reference, "miss-only greedy");
            assert_eq!(stats[0], 0);
            for index in [1, 2] {
                std::env::set_var("APEIRON_LOOKUP_CORRUPT", index.to_string());
                let (ids, stats, _) = engine.probe_lookup_decode(&p, 64, 2, 4)?;
                assert_eq!(ids, reference, "corrupted-window greedy");
                replays += stats[3];
            }
            std::env::remove_var("APEIRON_LOOKUP_CORRUPT");
        }
        assert!(verified > 0, "no speculative rounds exercised");
        assert!(replays > 0, "no partial prefix replay exercised");
        println!("CHECK actual greedy parity; verification rounds {verified}, forced prefix replays {replays}");
    } else {
        let width: usize = args[3].parse()?;
        let n: usize = args.get(4).map(|x| x.parse()).transpose()?.unwrap_or(64);
        if n < 2 {
            return Err("timed generation requires n >= 2".into());
        }
        if width == 0 {
            let _ = greedy(&engine, &prompt, n)?;
        } else {
            let _ = engine.probe_lookup_decode(&prompt, n, 4, width)?;
        }
        let (ids, stats, ns) = if width == 0 {
            let (ids, ns) = greedy(&engine, &prompt, n)?;
            (ids, [0; 4], ns)
        } else {
            engine.probe_lookup_decode(&prompt, n, 4, width)?
        };
        println!(
            "SAMPLE {} {:?} {:?}",
            (n - 1) as f64 * 1e9 / ns as f64,
            stats,
            ids
        );
    }
    Ok(())
}
