use apeiron::engine::{loader::Engine, KernelMode};
use std::{error::Error, time::Instant};

// Time: one prompt execution including the final head. Space: actual decode state and
// projection buffers. Loading and fresh state allocation are outside the measured interval.
fn prefill(engine: &Engine, prompt: &[u32]) -> Result<(u32, u128), Box<dyn Error>> {
    let mut state = engine.state(prompt.len() + 5)?;
    let start = Instant::now();
    let token = engine.prefill_state(&mut state, prompt, KernelMode::Q8Act)?;
    Ok((token, start.elapsed().as_nanos()))
}

fn main() -> Result<(), Box<dyn Error>> {
    let args: Vec<String> = std::env::args().collect();
    let engine = Engine::open(&args[1])?;
    let prompt: Vec<u32> = std::fs::read_to_string(&args[2])?
        .split_whitespace()
        .map(str::parse)
        .collect::<Result<_, _>>()?;
    let warm = prefill(&engine, &prompt)?;
    let measured = prefill(&engine, &prompt)?;
    assert_eq!(warm.0, measured.0, "fresh prefill token");
    println!("PREFILL {} {} {}", prompt.len(), measured.1, measured.0);
    Ok(())
}
