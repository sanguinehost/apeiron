//! Immutable directory bindings and mixer slots for the existing column executor.
use super::{
    affine_slots, softmax_slots, DecodeState, Engine, KernelMode, LayerIndex, Sched, StepError,
};
use crate::engine::loader::EngineConfig;
use crate::engine::{MixerKind, TensorEntry};

/// Process policy for the candidate plan. Disabled execution uses the original resolver.
pub(super) fn enabled() -> bool {
    static ON: std::sync::OnceLock<bool> = std::sync::OnceLock::new();
    *ON.get_or_init(|| std::env::var("APEIRON_COMPILE_GRAPH").map_or(true, |v| v != "0"))
}

#[derive(Debug)]
pub(super) struct DecodeGraph {
    config: EngineConfig,
    directory: Vec<TensorEntry>,
    pub(super) layers: Vec<LayerIndex>,
    pub(super) softmax: Vec<Option<usize>>,
    pub(super) affine: Vec<Option<usize>>,
    pub(super) n_softmax: usize,
}

impl DecodeGraph {
    /// O(directory bytes + layers) time and owned bytes: copy the immutable descriptors once,
    /// parse each directory name once, and assign both mixer-slot sequences once.
    pub(super) fn compile(engine: &Engine) -> Option<Self> {
        // Public config edits can describe an unexecutable schedule. Do not move its later
        // refusal/panic or request unbounded plan storage from the state constructor.
        let n = engine.config.n_layer.checked_add(engine.config.n_nextn)?;
        if n > engine.table().entries().len() || engine.config.n_layer > engine.config.mixers.len()
        {
            return None;
        }
        Some(Self {
            config: engine.config.clone(),
            directory: engine.table().entries().to_vec(),
            layers: engine.resolve_layers(),
            softmax: softmax_slots(&engine.config.mixers),
            affine: affine_slots(&engine.config.mixers),
            n_softmax: engine
                .config
                .mixers
                .iter()
                .filter(|m| **m == MixerKind::Softmax)
                .count(),
        })
    }

    /// O(directory bytes + config bytes) comparisons. The directory has no persistent identity
    /// handle, so full equality prevents stale bindings after engine replacement or config edits.
    pub(super) fn matches(&self, engine: &Engine) -> bool {
        self.config == engine.config && self.directory == engine.table().entries()
    }
}

impl Engine {
    /// Execute one column with the decode state's plan, using the original numeric kernels.
    /// Time/space are compose_cols' one-column bounds plus DecodeGraph::matches comparisons.
    pub(super) fn compose_state_final(
        &self,
        st: &mut DecodeState,
        token: u32,
        mode: KernelMode,
    ) -> Result<Vec<i64>, StepError> {
        let mut out = self.compose_cols_planned(
            &mut st.kv,
            st.affine.as_mut(),
            &[token],
            Sched::Resident,
            mode,
            mode == KernelMode::Q8Act,
            None,
            st.graph.as_deref(),
        )?;
        out.pop().ok_or(StepError::BadConfig("empty column block"))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    const MODEL: &str = "/home/socol/models/qwen3.5-0.8b/Qwen3.5-0.8B-Q8_0.gguf";

    #[test]
    #[ignore = "strict local real-model graph gate; both carriers run in separate processes"]
    fn compiled_graph_model_parity() {
        let mut engine = Engine::open(MODEL).expect("real graph model required");
        let prompt: Vec<u32> = std::fs::read_to_string(
            "/home/socol/Workspace/apeiron/tests/fixtures/qwen35-prompt2.ids",
        )
        .expect("real graph prompt required")
        .split_whitespace()
        .map(|s| s.parse().unwrap())
        .collect();
        let mut planned = engine.state(prompt.len() + 64).unwrap();
        let mut original = planned.clone();
        original.graph = None;
        assert!(planned.graph.as_ref().unwrap().matches(&engine));
        assert!(matches!(
            engine.state(0),
            Err(StepError::BadConfig("kv capacity"))
        ));
        let invalid = engine.config.vocab_size as u32;
        let a = engine.compose_state_final(&mut planned, invalid, KernelMode::Q8Act);
        let b = engine.compose_state_final(&mut original, invalid, KernelMode::Q8Act);
        assert_eq!(a, b, "graph embedding refusal");
        for block in prompt.chunks(64) {
            let a = engine
                .compose_cols_planned(
                    &mut planned.kv,
                    planned.affine.as_mut(),
                    block,
                    Sched::Resident,
                    KernelMode::Q8Act,
                    true,
                    None,
                    planned.graph.as_deref(),
                )
                .unwrap();
            let b = engine
                .compose_cols(
                    &mut original.kv,
                    original.affine.as_mut(),
                    block,
                    Sched::Resident,
                    KernelMode::Q8Act,
                    true,
                    None,
                )
                .unwrap();
            assert_eq!(a, b, "graph prompt hidden parity");
        }
        let mut token = prompt[0];
        for at in 0..16 {
            let a = engine
                .compose_state_final(&mut planned, token, KernelMode::Q8Act)
                .unwrap();
            let b = engine
                .compose_state_final(&mut original, token, KernelMode::Q8Act)
                .unwrap();
            assert_eq!(a, b, "graph continuation hidden parity at {at}");
            let logits = engine
                .lm_head_fixed_sched(&a, Sched::Resident, KernelMode::Q8Act)
                .unwrap();
            token = crate::engine::argmax_fixed(&logits).unwrap();
        }
        // A state can be used with a different Engine. Equal immutable descriptors are portable;
        // changed descriptors/configurations take the original resolver.
        let mut other = Engine::open(MODEL).expect("cross-engine graph fixture");
        assert!(planned.graph.as_ref().unwrap().matches(&other));
        other.config.rms_eps = -1.0;
        assert!(!planned.graph.as_ref().unwrap().matches(&other));
        assert_eq!(
            other.compose_state_final(&mut planned, token, KernelMode::Q8Act),
            other.compose_state_final(&mut original, token, KernelMode::Q8Act),
            "graph cross-engine refusal"
        );
        drop(other);
        let saved_nextn = engine.config.n_nextn;
        engine.config.n_nextn = usize::MAX;
        assert!(
            engine.state(1).unwrap().graph.is_none(),
            "oversized config plan fallback"
        );
        engine.config.n_nextn = saved_nextn;
        engine.config.rms_eps = -1.0;
        assert!(!planned.graph.as_ref().unwrap().matches(&engine));
        assert_eq!(
            engine.compose_state_final(&mut planned, token, KernelMode::Q8Act),
            engine.compose_state_final(&mut original, token, KernelMode::Q8Act),
            "graph changed config refusal"
        );
        println!(
            "GRAPH_PARITY prompt={} continuation=16 carrier={:?}",
            prompt.len(),
            planned.kv.carrier()
        );
    }

    #[test]
    #[ignore = "five quiet paired prefill rounds are driven by the bounded external runner"]
    fn compiled_graph_timing() {
        let engine = Engine::open(MODEL).expect("real graph model required");
        let n: usize = std::env::var("APEIRON_GRAPH_LENGTH")
            .unwrap()
            .parse()
            .unwrap();
        let source: Vec<u32> = std::fs::read_to_string(
            "/home/socol/Workspace/apeiron/tests/fixtures/qwen35-prompt2.ids",
        )
        .unwrap()
        .split_whitespace()
        .map(|s| s.parse().unwrap())
        .collect();
        let prompt: Vec<u32> = source.iter().copied().cycle().take(n).collect();
        let mut warm = engine.state(n).unwrap();
        let expected = engine
            .prefill_state(&mut warm, &prompt, KernelMode::Q8Act)
            .unwrap();
        drop(warm);
        // The fixed model/head is warm. Fresh state allocation, plan construction and final head
        // are included, while file loading and prompt allocation are excluded.
        let start = std::time::Instant::now();
        let mut st = engine.state(n).unwrap();
        let token = engine
            .prefill_state(&mut st, &prompt, KernelMode::Q8Act)
            .unwrap();
        let elapsed = start.elapsed().as_secs_f64();
        assert_eq!(token, expected, "graph warmed/fresh prefill token parity");
        println!(
            "GRAPH_SAMPLE {} {} {} {}",
            enabled(),
            n,
            n as f64 / elapsed,
            token
        );
    }
}
