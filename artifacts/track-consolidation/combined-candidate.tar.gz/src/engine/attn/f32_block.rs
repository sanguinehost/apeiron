//! Batched binary32 attention core: a block of query positions times the query heads of one GQA
//! group against one KV head.
//!
//! # Contract
//!
//! [`KvState::attn_block_f32`] equals the loop of [`KvState::attn_head_f32`] over
//! `(position, group head)` in that order, word for word. Each query keeps its own online-softmax
//! state `(m, den, acc)` and runs the same operation sequence as the per-query kernel: the
//! tile-of-8 recurrence of [`attn_tile8_avx2`] over key positions `1, 9, 17, …` while
//! `s + 8 <= count`, then [`attn_singles_avx2`] for the remainder, where `count = position + 1`
//! is the causal prefix of that query. Only the loop order changes: for one key tile the queries
//! of the block run back to back, so the tile's K and V rows stay in L1 across them instead of
//! being re-read from L2 for every query.
//!
//! # Refusals
//!
//! The guard chain of `attn_head_f32` (layer, head, query length, output length, position), then
//! per query the core's refusals. The result is the first refusal of the per-query loop in
//! `(position, group head)` order and the output words written are those the loop writes before
//! that refusal; a query whose position is at or past the occupied length refuses
//! [`AttnError::PositionOutOfRange`] only after every earlier query has been computed.
//!
//! # Trust Boundary
//!
//! Not Aeneas-extracted. Equality with the per-query path is by differential test
//! (`block_equals_per_query_loop`), not proof.

#[cfg(target_arch = "x86_64")]
use std::arch::x86_64::{
    _mm256_loadu_ps, _mm256_mul_ps, _mm256_set1_ps, _mm256_setzero_ps, _mm256_storeu_ps,
};
use std::ops::Range;

use super::f32_core::{attn_core_f32_strided, f32_to_q32_checked};
#[cfg(target_arch = "x86_64")]
use super::f32_core::{
    attn_singles_avx2, dot_f32_avx2, tile_accumulate_avx2, tile_scores_avx2, tile_weights_avx2,
    TILE,
};
use super::{AttnError, KvState, KvStorage};
use crate::engine::mixer::f32_carrier::q32_to_f32;

/// `f32` words of query and accumulator state per sub-block of queries (16 KiB each on the stack).
const BLOCK_WORDS: usize = 4096;
/// Queries per sub-block at most; `BLOCK_WORDS / head_dim` below that for wide heads.
const MAX_SUB: usize = 64;

/// One query row to binary32; a non-finite result refuses like `attn_head_f32`.
fn convert_query(src: &[i64], dst: &mut [f32]) -> Result<(), AttnError> {
    for (d, &w) in dst.iter_mut().zip(src) {
        let f = q32_to_f32(w);
        if !f.is_finite() {
            return Err(AttnError::Overflow);
        }
        *d = f;
    }
    Ok(())
}

/// Readout of one finished query, in index order, stopping at the first refusal.
fn write_out(res: &[f32], out: &mut [i64]) -> Result<(), AttnError> {
    for (o, &r) in out.iter_mut().zip(res) {
        *o = f32_to_q32_checked(r)?;
    }
    Ok(())
}

impl KvState {
    /// Attention of the query positions `pos_range` and the `n_head / n_head_kv` query heads of
    /// KV head `kv_head`, against that KV head's rows `0..=position`, in binary32.
    ///
    /// Query `(i, g)` (position `pos_range.start + i`, head `kv_head · group + g`) is the
    /// `head_dim` words at `q[i · q_stride + g · head_dim ..]`, so `q` starts at the group's first
    /// head in the first position's row and `q_stride` is the distance between positions (at
    /// least `group · head_dim`). Its output is the `head_dim` words at
    /// `out[(i · group + g) · head_dim ..]`; `out` is dense.
    ///
    /// Equal to [`KvState::attn_head_f32`] called for every `(i, g)` in that order (see the module
    /// contract). An empty range is `Ok` after the layer and head checks.
    ///
    /// # Errors
    ///
    /// [`AttnError::LayerOutOfRange`], [`AttnError::HeadOutOfRange`] (`kv_head >= n_head_kv`),
    /// [`AttnError::BadGeometry`] (`q_stride < group · head_dim`, or a non-binary32 cache),
    /// [`AttnError::RowLength`] for a `q` shorter than the last query's row or an `out` not
    /// `nq · group · head_dim` long, [`AttnError::PositionOutOfRange`] for the first position at
    /// or past the occupied length, then the per-query core refusals ([`AttnError::Overflow`],
    /// [`AttnError::ZeroSum`]).
    ///
    /// # Complexity
    ///
    /// Time `O(nq · group · (p₁ + 1) · head_dim)` in FMAs for the last position `p₁`, the same
    /// count as the per-query loop; K/V row loads drop by the number of queries that share a tile.
    /// Space `O(1)`: stack state of at most `BLOCK_WORDS` accumulator words and as many query
    /// words per sub-block for `head_dim <= 256`; no heap allocation for `head_dim <= 256`.
    pub fn attn_block_f32(
        &self,
        layer: usize,
        kv_head: usize,
        q: &[i64],
        q_stride: usize,
        pos_range: Range<usize>,
        out: &mut [i64],
    ) -> Result<(), AttnError> {
        let hd = self.head_dim;
        if layer >= self.n_layer {
            return Err(AttnError::LayerOutOfRange {
                layer,
                n_layer: self.n_layer,
            });
        }
        if kv_head >= self.n_head_kv {
            return Err(AttnError::HeadOutOfRange {
                head: kv_head,
                n_head: self.n_head_kv,
            });
        }
        let group = self.n_head / self.n_head_kv;
        let p0 = pos_range.start;
        let nq = pos_range.end.saturating_sub(p0);
        let width = group.checked_mul(hd).ok_or(AttnError::Overflow)?;
        if q_stride < width {
            return Err(AttnError::BadGeometry);
        }
        let need_q = match nq {
            0 => 0,
            n => (n - 1)
                .checked_mul(q_stride)
                .and_then(|x| x.checked_add(width))
                .ok_or(AttnError::Overflow)?,
        };
        if q.len() < need_q {
            return Err(AttnError::RowLength {
                expected: need_q,
                got: q.len(),
            });
        }
        let need_out = nq.checked_mul(width).ok_or(AttnError::Overflow)?;
        if out.len() != need_out {
            return Err(AttnError::RowLength {
                expected: need_out,
                got: out.len(),
            });
        }
        let len = self.occupied[layer];
        let valid = if p0 >= len { 0 } else { nq.min(len - p0) };
        if nq > 0 && valid == 0 {
            return Err(AttnError::PositionOutOfRange { pos: p0, len });
        }
        if nq > 0 {
            let (kplane, vplane) = match &self.storage {
                KvStorage::F32 { k, v } => (&k[layer], &v[layer]),
                KvStorage::Q32 { .. } => return Err(AttnError::BadGeometry),
            };
            let stride = self.n_head_kv.checked_mul(hd).ok_or(AttnError::Overflow)?;
            let first = kv_head.checked_mul(hd).ok_or(AttnError::Overflow)?;
            let last_base = first + (p0 + valid - 1) * stride;
            if last_base > kplane.len().saturating_sub(hd)
                || last_base > vplane.len().saturating_sub(hd)
            {
                return Err(AttnError::Overflow);
            }
            #[allow(
                clippy::cast_precision_loss,
                reason = "head_dim is far below 2^24, exact in f32"
            )]
            let scale = 1.0f32 / (hd as f32).sqrt();
            block_f32(
                &kplane[first..],
                &vplane[first..],
                hd,
                stride,
                p0,
                valid,
                group,
                &q[..need_q.min(q.len())],
                q_stride,
                scale,
                &mut out[..valid * width],
            )?;
            if valid < nq {
                return Err(AttnError::PositionOutOfRange {
                    pos: p0 + valid,
                    len,
                });
            }
        }
        Ok(())
    }
}

/// Dispatch: the AVX2 block kernel for `head_dim % 8 == 0, <= 256`, else the per-query core.
#[allow(
    clippy::too_many_arguments,
    clippy::many_single_char_names,
    reason = "explicit strided K/V and query geometry"
)]
fn block_f32(
    k: &[f32],
    v: &[f32],
    hd: usize,
    stride: usize,
    p0: usize,
    nq: usize,
    group: usize,
    q: &[i64],
    q_stride: usize,
    scale: f32,
    out: &mut [i64],
) -> Result<(), AttnError> {
    #[cfg(target_arch = "x86_64")]
    if hd.is_multiple_of(8)
        && hd <= 256
        && std::is_x86_feature_detected!("avx2")
        && std::is_x86_feature_detected!("fma")
    {
        return unsafe { block_avx2(k, v, hd, stride, p0, nq, group, q, q_stride, scale, out) };
    }
    let mut q_stack = [0.0f32; 256];
    let mut o_stack = [0.0f32; 256];
    let (mut q_heap, mut o_heap);
    let (qf, of): (&mut [f32], &mut [f32]) = if hd <= 256 {
        (&mut q_stack[..hd], &mut o_stack[..hd])
    } else {
        q_heap = vec![0.0f32; hd];
        o_heap = vec![0.0f32; hd];
        (&mut q_heap[..], &mut o_heap[..])
    };
    for t in 0..nq * group {
        let (i, j) = (t / group, t % group);
        let src = &q[i * q_stride + j * hd..i * q_stride + (j + 1) * hd];
        convert_query(src, qf)?;
        attn_core_f32_strided(qf, k, v, hd, stride, p0 + i, scale, of)?;
        write_out(of, &mut out[t * hd..(t + 1) * hd])?;
    }
    Ok(())
}

/// The AVX2+FMA block kernel, in sub-blocks of queries (see the module contract).
///
/// # Complexity
///
/// Per sub-block of `n` queries: `O(Σ count · head_dim)` FMAs; K/V rows of each tile are read
/// once from L2 and `n` times from L1. Stack only.
///
/// # Safety
///
/// Requires AVX2 and FMA; `k` and `v` hold rows `0..p0 + nq` at `stride`, each `hd` wide,
/// `hd % 8 == 0`, `hd <= 256`; `q` and `out` are sized as in [`KvState::attn_block_f32`].
#[cfg(target_arch = "x86_64")]
#[target_feature(enable = "avx2,fma")]
#[allow(
    clippy::too_many_arguments,
    clippy::needless_range_loop,
    clippy::many_single_char_names,
    clippy::similar_names,
    clippy::too_many_lines,
    reason = "explicit strided geometry and the recurrence symbols of the per-query kernel; the \
              sub-block phases read in order"
)]
unsafe fn block_avx2(
    k: &[f32],
    v: &[f32],
    hd: usize,
    stride: usize,
    p0: usize,
    nq: usize,
    group: usize,
    q: &[i64],
    q_stride: usize,
    scale: f32,
    out: &mut [i64],
) -> Result<(), AttnError> {
    let chunks = hd / 8;
    let sub = (BLOCK_WORDS / hd).min(MAX_SUB);
    let total = nq * group;
    let mut acc = [_mm256_setzero_ps(); BLOCK_WORDS / 8];
    let mut qf = [0.0f32; BLOCK_WORDS];
    let mut m = [0.0f32; MAX_SUB];
    let mut den = [0.0f32; MAX_SUB];
    let mut count = [0usize; MAX_SUB];
    let mut err = [None::<AttnError>; MAX_SUB];
    let mut score = [[0.0f32; TILE]; MAX_SUB];
    let mut alpha = [[0.0f32; TILE]; MAX_SUB];
    let mut w = [[0.0f32; TILE]; MAX_SUB];
    let mut t0 = 0usize;
    while t0 < total {
        let n = sub.min(total - t0);
        for l in 0..n {
            let t = t0 + l;
            let (i, j) = (t / group, t % group);
            count[l] = p0 + i + 1;
            err[l] = None;
            let src = &q[i * q_stride + j * hd..i * q_stride + (j + 1) * hd];
            if let Err(e) = convert_query(src, &mut qf[l * hd..(l + 1) * hd]) {
                err[l] = Some(e);
                continue;
            }
            let score0 = dot_f32_avx2(&qf[l * hd..(l + 1) * hd], &k[..hd], scale);
            if !score0.is_finite() {
                err[l] = Some(AttnError::Overflow);
                continue;
            }
            m[l] = score0;
            den[l] = 1.0;
            for c in 0..chunks {
                acc[l * chunks + c] = _mm256_loadu_ps(v.as_ptr().add(c * 8));
            }
        }
        // One tile step at a time, phase by phase over the queries that take it: the three phases
        // of one query form a dependent chain (scores, running maximum and exponentials, then the
        // accumulator), and the queries are independent, so the loop over queries hands the core
        // independent work. A query's own operations are the ones `attn_tile8_avx2` runs, in the
        // same order. Counts are non-decreasing in `l`, so a tile that no live query takes at `s` is
        // taken by none at `s + TILE`.
        let mut s = 1usize;
        loop {
            let mut any = false;
            for l in 0..n {
                if err[l].is_none() && s + TILE <= count[l] {
                    any = true;
                    if let Err(e) = tile_scores_avx2(
                        &qf[l * hd..(l + 1) * hd],
                        k.as_ptr().add(s * stride),
                        hd,
                        stride,
                        scale,
                        &mut score[l],
                    ) {
                        err[l] = Some(e);
                    }
                }
            }
            if !any {
                break;
            }
            for l in 0..n {
                if err[l].is_none() && s + TILE <= count[l] {
                    tile_weights_avx2(&score[l], &mut m[l], &mut alpha[l], &mut w[l]);
                }
            }
            for l in 0..n {
                if err[l].is_none() && s + TILE <= count[l] {
                    tile_accumulate_avx2(
                        v.as_ptr().add(s * stride),
                        hd,
                        stride,
                        &alpha[l],
                        &w[l],
                        &mut den[l],
                        &mut acc[l * chunks..(l + 1) * chunks],
                    );
                }
            }
            s += TILE;
        }
        for l in 0..n {
            if err[l].is_some() {
                continue;
            }
            let s0 = 1 + TILE * ((count[l] - 1) / TILE);
            if let Err(e) = attn_singles_avx2(
                &qf[l * hd..(l + 1) * hd],
                k,
                v,
                hd,
                stride,
                s0,
                count[l],
                scale,
                &mut m[l],
                &mut den[l],
                &mut acc[l * chunks..(l + 1) * chunks],
            ) {
                err[l] = Some(e);
            }
        }
        for l in 0..n {
            if let Some(e) = err[l] {
                return Err(e);
            }
            if den[l] <= 0.0 || !den[l].is_finite() {
                return Err(AttnError::ZeroSum);
            }
            let inv = _mm256_set1_ps(1.0f32 / den[l]);
            let mut res = [0.0f32; 256];
            for c in 0..chunks {
                let r = _mm256_mul_ps(acc[l * chunks + c], inv);
                _mm256_storeu_ps(res.as_mut_ptr().add(c * 8), r);
            }
            if res[..hd].iter().any(|x| !x.is_finite()) {
                return Err(AttnError::Overflow);
            }
            write_out(&res[..hd], &mut out[(t0 + l) * hd..(t0 + l + 1) * hd])?;
        }
        t0 += n;
    }
    Ok(())
}

#[cfg(test)]
#[allow(
    clippy::similar_names,
    clippy::too_many_lines,
    clippy::too_many_arguments,
    clippy::cast_possible_truncation,
    clippy::cast_precision_loss,
    clippy::cast_possible_wrap,
    clippy::needless_range_loop,
    clippy::many_single_char_names,
    clippy::uninlined_format_args,
    reason = "test harness, random generator and timing loops"
)]
mod tests {
    use super::*;
    use crate::engine::mixer::Carrier;

    fn lcg(state: &mut u64) -> u64 {
        *state = state
            .wrapping_mul(6_364_136_223_846_793_005)
            .wrapping_add(1_442_695_040_888_963_407);
        *state >> 11
    }

    /// A Q32.32 word uniform in `[-amp, amp)` (`amp` in whole units).
    fn word(state: &mut u64, amp: i64) -> i64 {
        let r = (lcg(state) % (1 << 40)) as i64;
        (r % ((2 * amp) << 32)) - (amp << 32)
    }

    fn filled(
        nh: usize,
        nkv: usize,
        hd: usize,
        cap: usize,
        len: usize,
        amp: i64,
        seed: u64,
    ) -> KvState {
        let mut kv = KvState::with_carrier(1, nh, nkv, hd, cap, Carrier::F32).expect("geometry");
        let mut st = seed;
        for _ in 0..len {
            let k: Vec<i64> = (0..nkv * hd).map(|_| word(&mut st, amp)).collect();
            let v: Vec<i64> = (0..nkv * hd).map(|_| word(&mut st, amp)).collect();
            kv.append(0, &k, &v).expect("append");
        }
        kv
    }

    /// The per-query loop the block must equal: `attn_head_f32` over `(i, g)`, stopping at the
    /// first refusal.
    fn reference(
        kv: &KvState,
        kvh: usize,
        q: &[i64],
        q_stride: usize,
        pos: Range<usize>,
        out: &mut [i64],
    ) -> Result<(), AttnError> {
        let hd = kv.head_dim;
        let group = kv.n_head / kv.n_head_kv;
        for i in 0..pos.len() {
            for g in 0..group {
                let row = &q[i * q_stride + g * hd..i * q_stride + (g + 1) * hd];
                let o = &mut out[(i * group + g) * hd..(i * group + g + 1) * hd];
                kv.attn_head_f32(0, kvh * group + g, row, pos.start + i, o)?;
            }
        }
        Ok(())
    }

    fn equal_case(
        nh: usize,
        nkv: usize,
        hd: usize,
        len: usize,
        p0: usize,
        nq: usize,
        amp: i64,
        seed: u64,
    ) {
        let kv = filled(nh, nkv, hd, len, len, amp, seed);
        let group = nh / nkv;
        let q_stride = group * hd + 3;
        let mut st = seed ^ 0xABCD;
        let q: Vec<i64> = (0..nq * q_stride).map(|_| word(&mut st, amp)).collect();
        for kvh in 0..nkv {
            let mut got = vec![0i64; nq * group * hd];
            let mut want = vec![0i64; nq * group * hd];
            let r = kv.attn_block_f32(0, kvh, &q, q_stride, p0..p0 + nq, &mut got);
            let e = reference(&kv, kvh, &q, q_stride, p0..p0 + nq, &mut want);
            assert_eq!(
                r, e,
                "result nh {nh} nkv {nkv} hd {hd} len {len} p0 {p0} nq {nq} kvh {kvh}"
            );
            if let Some(i) = (0..got.len()).find(|&i| got[i] != want[i]) {
                panic!(
                    "word differs at {i} (query {} comp {}): block {} loop {} \
                     (nh {nh} nkv {nkv} hd {hd} len {len} p0 {p0} nq {nq} kvh {kvh} amp {amp})",
                    i / hd,
                    i % hd,
                    got[i],
                    want[i]
                );
            }
        }
    }

    #[test]
    fn block_equals_per_query_loop() {
        let spans: [(usize, usize); 10] = [
            (0, 1),
            (0, 9),
            (7, 2),
            (8, 8),
            (9, 16),
            (15, 3),
            (16, 17),
            (23, 1),
            (31, 33),
            (40, 5),
        ];
        let mut seed = 1u64;
        for &(nh, nkv) in &[(2usize, 2usize), (4, 2), (14, 2), (7, 1), (12, 2)] {
            for &hd in &[64usize, 128, 256] {
                for &(p0, nq) in &spans {
                    for extra in [0usize, 5] {
                        seed += 1;
                        let amp = [1i64, 4][(seed % 2) as usize];
                        equal_case(nh, nkv, hd, p0 + nq + extra, p0, nq, amp, seed);
                    }
                }
            }
        }
    }

    #[test]
    fn block_equals_per_query_loop_on_fallback_widths() {
        let mut seed = 77u64;
        for &(hd, nh, nkv) in &[(12usize, 4usize, 2usize), (20, 2, 1), (264, 2, 1)] {
            for &(p0, nq) in &[(0usize, 3usize), (9, 4), (17, 2)] {
                seed += 1;
                equal_case(nh, nkv, hd, p0 + nq, p0, nq, 2, seed);
            }
        }
    }

    #[test]
    fn block_refusals_match_the_per_query_loop() {
        let (nh, nkv, hd) = (4usize, 2usize, 64usize);
        let group = nh / nkv;
        let kv = filled(nh, nkv, hd, 32, 20, 2, 5);
        let q_stride = group * hd;
        let q = vec![1i64 << 32; 8 * q_stride];
        let mut out = vec![0i64; 8 * group * hd];
        assert_eq!(
            kv.attn_block_f32(1, 0, &q, q_stride, 0..1, &mut out[..group * hd]),
            Err(AttnError::LayerOutOfRange {
                layer: 1,
                n_layer: 1
            })
        );
        assert_eq!(
            kv.attn_block_f32(0, nkv, &q, q_stride, 0..1, &mut out[..group * hd]),
            Err(AttnError::HeadOutOfRange {
                head: nkv,
                n_head: nkv
            })
        );
        assert_eq!(
            kv.attn_block_f32(0, 0, &q, q_stride - 1, 0..1, &mut out[..group * hd]),
            Err(AttnError::BadGeometry)
        );
        assert_eq!(
            kv.attn_block_f32(
                0,
                0,
                &q[..q_stride + group * hd - 1],
                q_stride,
                0..2,
                &mut out[..2 * group * hd]
            ),
            Err(AttnError::RowLength {
                expected: q_stride + group * hd,
                got: q_stride + group * hd - 1
            })
        );
        assert_eq!(
            kv.attn_block_f32(0, 0, &q, q_stride, 0..2, &mut out[..group * hd]),
            Err(AttnError::RowLength {
                expected: 2 * group * hd,
                got: group * hd
            })
        );
        assert_eq!(
            kv.attn_block_f32(0, 0, &q, q_stride, 5..5, &mut out[..0]),
            Ok(())
        );
        // Positions 18, 19 are occupied; 20 and 21 are not. The two valid queries are computed
        // (and written) before the refusal, as in the loop.
        let mut got = vec![0i64; 4 * group * hd];
        let mut want = vec![0i64; 4 * group * hd];
        let r = kv.attn_block_f32(0, 1, &q, q_stride, 18..22, &mut got);
        let e = reference(&kv, 1, &q, q_stride, 18..22, &mut want);
        assert_eq!(r, Err(AttnError::PositionOutOfRange { pos: 20, len: 20 }));
        assert_eq!(r, e);
        assert_eq!(got, want);
        assert!(got[..2 * group * hd].iter().any(|&w| w != 0));
        assert_eq!(
            kv.attn_block_f32(0, 0, &q, q_stride, 20..21, &mut out[..group * hd]),
            Err(AttnError::PositionOutOfRange { pos: 20, len: 20 })
        );
        let q32 = KvState::with_carrier(1, nh, nkv, hd, 4, Carrier::Q32).expect("geometry");
        let mut q32 = q32;
        q32.append(0, &vec![0; nkv * hd], &vec![0; nkv * hd])
            .unwrap();
        assert_eq!(
            q32.attn_block_f32(0, 0, &q, q_stride, 0..1, &mut out[..group * hd]),
            Err(AttnError::BadGeometry)
        );
    }

    /// A non-finite key at position 12: queries at positions below 12 succeed, the first at or
    /// past it refuses `Overflow`, and the output words written equal the loop's.
    #[test]
    fn block_overflow_refusal_and_partial_output_match_the_loop() {
        for &(hd, nh, nkv) in &[(64usize, 4usize, 2usize), (256, 7, 1)] {
            let group = nh / nkv;
            for poison_at in [0usize, 1, 12, 13, 20] {
                let mut kv = filled(nh, nkv, hd, 24, 24, 2, 9);
                if let KvStorage::F32 { k, .. } = &mut kv.storage {
                    k[0][poison_at * nkv * hd + hd] = f32::INFINITY;
                }
                let q_stride = group * hd;
                let mut st = 3;
                let q: Vec<i64> = (0..10 * q_stride).map(|_| word(&mut st, 2)).collect();
                for kvh in 0..nkv {
                    let mut got = vec![0i64; 10 * group * hd];
                    let mut want = vec![0i64; 10 * group * hd];
                    let r = kv.attn_block_f32(
                        0,
                        kvh,
                        &q,
                        q_stride,
                        10..20,
                        &mut got[..10 * group * hd],
                    );
                    let e = reference(&kv, kvh, &q, q_stride, 10..20, &mut want);
                    assert_eq!(r, e, "hd {hd} poison {poison_at} kvh {kvh}");
                    assert_eq!(got, want, "hd {hd} poison {poison_at} kvh {kvh}");
                    if kvh == 1 && poison_at < 20 {
                        assert_eq!(r, Err(AttnError::Overflow));
                    }
                }
            }
        }
    }

    /// Timing harness (`--ignored`, release, exclusive lock): one layer's attention core over a
    /// whole prompt in the column blocks the prefill uses, before (one task per `(column, head)`,
    /// `attn_head`) and after (one task per `(column block, KV head)`, `attn_block_f32`).
    #[test]
    #[ignore = "timing harness"]
    fn attn_block_timing() {
        use crate::engine::chart::pool::Pool;
        use std::time::Instant;

        fn fold_col(n: usize, k: usize) -> usize {
            if n.is_multiple_of(2) {
                n / 2
            } else {
                k - 1 - n / 2
            }
        }
        fn med(v: &mut [f64]) -> f64 {
            v.sort_by(|a, b| a.partial_cmp(b).unwrap());
            v[v.len() / 2]
        }
        let pool = Pool::global();
        let reps = 41usize;
        let shapes: [(&str, usize, usize, usize, usize); 3] = [
            ("Qwen2.5-0.5B 14/2/64 x24", 14, 2, 64, 24),
            ("Qwen2.5-1.5B 12/2/128 x28", 12, 2, 128, 28),
            ("Qwen3.5-0.8B 8/2/256 x6", 8, 2, 256, 6),
        ];
        let qbs = [1usize, 2, 4, 8, 16];
        println!("--- attn core per layer over the whole prompt, median of {reps}, ms/layer ---");
        for &(name, nh, nkv, hd, layers) in &shapes {
            let group = nh / nkv;
            let q_out = nh * hd;
            let stride = q_out + 2 * nkv * hd;
            for &p in &[200usize, 512] {
                // The engine's column blocks: 64 wide, 200 = 64, 64, 64, 7, 1.
                let blocks: Vec<(usize, usize)> = if p == 200 {
                    vec![(0, 64), (64, 64), (128, 64), (192, 7), (199, 1)]
                } else {
                    (0..p / 64).map(|b| (b * 64, 64)).collect()
                };
                let kv = filled(nh, nkv, hd, p, p, 2, 11);
                let mut st = 5u64;
                let prep: Vec<i64> = (0..p * stride).map(|_| word(&mut st, 2)).collect();
                let before = |att: &mut Vec<i64>, serial: bool| {
                    for &(pos0, k) in &blocks {
                        let run = |t: usize, dst: &mut [i64]| {
                            let (n, h) = (t / nh, t % nh);
                            let c = fold_col(n, k);
                            let base = (pos0 + c) * stride;
                            kv.attn_head(
                                0,
                                h,
                                &prep[base + h * hd..base + (h + 1) * hd],
                                pos0 + c,
                                dst,
                            )
                            .unwrap();
                        };
                        let a = &mut att[pos0 * q_out..(pos0 + k) * q_out];
                        if serial {
                            for t in 0..k * nh {
                                run(t, &mut a[t * hd..(t + 1) * hd]);
                            }
                        } else {
                            pool.chunks_mut(a, hd, &|t, _s, dst| run(t, dst));
                        }
                    }
                };
                // `qb` columns per task; the output is per (fold position, KV head) chunks,
                // padded to whole blocks, scattered back into `att` by the caller.
                let after = |att: &mut Vec<i64>,
                             buf: &mut Vec<i64>,
                             qb: usize,
                             serial: bool,
                             scatter: bool| {
                    let chunk = qb * group * hd;
                    for &(pos0, k) in &blocks {
                        let nb = k.div_ceil(qb);
                        let buf = &mut buf[..nb * nkv * chunk];
                        let run = |t: usize, dst: &mut [i64]| {
                            let (n, kvh) = (t / nkv, t % nkv);
                            let b = fold_col(n, nb);
                            let c0 = b * qb;
                            let nq = qb.min(k - c0);
                            let base = (pos0 + c0) * stride + kvh * group * hd;
                            kv.attn_block_f32(
                                0,
                                kvh,
                                &prep[base..],
                                stride,
                                pos0 + c0..pos0 + c0 + nq,
                                &mut dst[..nq * group * hd],
                            )
                            .unwrap();
                        };
                        if serial {
                            for t in 0..nb * nkv {
                                run(t, &mut buf[t * chunk..(t + 1) * chunk]);
                            }
                        } else {
                            pool.chunks_mut(buf, chunk, &|t, _s, dst| run(t, dst));
                        }
                        for t in 0..if scatter { nb * nkv } else { 0 } {
                            let (n, kvh) = (t / nkv, t % nkv);
                            let b = fold_col(n, nb);
                            let c0 = b * qb;
                            let nq = qb.min(k - c0);
                            for i in 0..nq {
                                let d = (pos0 + c0 + i) * q_out + kvh * group * hd;
                                att[d..d + group * hd].copy_from_slice(
                                    &buf[t * chunk + i * group * hd
                                        ..t * chunk + (i + 1) * group * hd],
                                );
                            }
                        }
                    }
                };
                // Column-ordered oracle: `attn_head` per (column, head), no pool, no fold.
                let mut want = vec![0i64; p * q_out];
                for c in 0..p {
                    for h in 0..nh {
                        let base = c * stride + h * hd;
                        kv.attn_head(
                            0,
                            h,
                            &prep[base..base + hd],
                            c,
                            &mut want[c * q_out + h * hd..c * q_out + (h + 1) * hd],
                        )
                        .unwrap();
                    }
                }
                let time = |f: &mut dyn FnMut()| {
                    let mut ts = Vec::new();
                    for r in 0..reps + 3 {
                        let t0 = Instant::now();
                        f();
                        if r >= 3 {
                            ts.push(t0.elapsed().as_secs_f64() * 1e3);
                        }
                    }
                    med(&mut ts)
                };
                let mut scratch = vec![0i64; p * q_out];
                let t_before = time(&mut || before(&mut scratch, false));
                let t_before_1 = time(&mut || before(&mut scratch, true));
                let pairs: f64 = (0..p).map(|c| (c + 1) as f64).sum::<f64>() * nh as f64;
                println!(
                    "{name} P={p}: before pool {t_before:.3} ms/layer ({:.4} ms/token x{layers}), \
                     serial {t_before_1:.3} ms ({:.2} ns per (query,key) pair, {:.2} GB/s of K+V rows)",
                    t_before * layers as f64 / p as f64,
                    t_before_1 * 1e6 / pairs,
                    pairs * (2 * hd * 4) as f64 / (t_before_1 * 1e-3) / 1e9
                );
                for &qb in &qbs {
                    let mut got = vec![0i64; p * q_out];
                    let mut buf = vec![0i64; 2 * p.min(64) * q_out];
                    after(&mut got, &mut buf, qb, false, true);
                    assert!(got == want, "after(qb={qb}) differs from before");
                    let t_after = time(&mut || after(&mut scratch, &mut buf, qb, false, false));
                    let t_after_1 = time(&mut || after(&mut scratch, &mut buf, qb, true, false));
                    println!(
                        "    qb={qb:2}: pool {t_after:.3} ms/layer ({:.2}x, {:.4} ms/token x{layers}), \
                         serial {t_after_1:.3} ms ({:.2}x, {:.2} ns/pair)",
                        t_before / t_after,
                        t_after * layers as f64 / p as f64,
                        t_before_1 / t_after_1,
                        t_after_1 * 1e6 / pairs,
                    );
                }
            }
        }
    }

    /// Segment harness (`--ignored`, release, exclusive lock, pin with `taskset -c 0`): one KV
    /// head's queries over a prompt, serial, phase by phase, with the tile's rows either streamed
    /// (`s` advances through the cache) or fixed (the same 8 rows, L1-resident). Equal streamed and
    /// fixed times mean the phase is bound by instruction issue and dependence chains, not by
    /// loads from L2.
    #[cfg(target_arch = "x86_64")]
    #[test]
    #[ignore = "timing harness"]
    fn attn_block_segments() {
        use std::time::Instant;
        let reps = 15usize;
        let med = |v: &mut Vec<f64>| {
            v.sort_by(|a, b| a.partial_cmp(b).unwrap());
            v[v.len() / 2]
        };
        for &(name, nh, nkv, hd) in &[
            ("0.5B 14/2/64", 14usize, 2usize, 64usize),
            ("1.5B 12/2/128", 12, 2, 128),
        ] {
            let p = 512usize;
            let group = nh / nkv;
            let kv = filled(nh, nkv, hd, p, p, 2, 11);
            let KvStorage::F32 { k: kp, v: vp } = &kv.storage else {
                unreachable!()
            };
            let (kp, vp) = (&kp[0][..], &vp[0][..]);
            let stride = nkv * hd;
            let mut st = 5u64;
            let qw: Vec<i64> = (0..p * group * hd).map(|_| word(&mut st, 2)).collect();
            let mut qf = vec![0.0f32; qw.len()];
            for (d, &w) in qf.iter_mut().zip(&qw) {
                *d = q32_to_f32(w);
            }
            let scale = 1.0f32 / (hd as f32).sqrt();
            let chunks = hd / 8;
            // mode: 1 = scores, 2 = scores + weights, 3 = all three phases; fixed = same tile.
            let run = |mode: u8, fixed: bool| -> (f64, f64) {
                let mut ts = Vec::new();
                let mut tiles_total = 0usize;
                for r in 0..reps + 2 {
                    tiles_total = 0;
                    let t0 = Instant::now();
                    let mut sink = 0.0f32;
                    for c in 0..p {
                        for g in 0..group {
                            let q = &qf[(c * group + g) * hd..(c * group + g + 1) * hd];
                            let tiles = c / TILE;
                            let mut acc = [unsafe { _mm256_setzero_ps() }; 32];
                            let (mut m, mut den) = (0.0f32, 1.0f32);
                            let (mut sc, mut al, mut w) =
                                ([0.0f32; TILE], [0.0f32; TILE], [0.0f32; TILE]);
                            for ti in 0..tiles {
                                let s = if fixed { 1 } else { 1 + TILE * ti };
                                unsafe {
                                    tile_scores_avx2(
                                        q,
                                        kp.as_ptr().add(s * stride),
                                        hd,
                                        stride,
                                        scale,
                                        &mut sc,
                                    )
                                    .unwrap();
                                    if mode >= 2 {
                                        tile_weights_avx2(&sc, &mut m, &mut al, &mut w);
                                    }
                                    if mode >= 3 {
                                        tile_accumulate_avx2(
                                            vp.as_ptr().add(s * stride),
                                            hd,
                                            stride,
                                            &al,
                                            &w,
                                            &mut den,
                                            &mut acc[..chunks],
                                        );
                                    }
                                }
                                sink += sc[0];
                            }
                            tiles_total += tiles;
                            sink += den + m;
                        }
                    }
                    std::hint::black_box(sink);
                    if r >= 2 {
                        ts.push(t0.elapsed().as_secs_f64() * 1e3);
                    }
                }
                (med(&mut ts), tiles_total as f64 * TILE as f64)
            };
            // Conversions: `convert_query` and `write_out` per query, every (position, head).
            let mut ts = Vec::new();
            let mut out = vec![0i64; hd];
            let mut qrow = vec![0.0f32; hd];
            let resf: Vec<f32> = (0..hd).map(|i| i as f32 * 0.01 - 0.3).collect();
            for r in 0..reps + 2 {
                let t0 = Instant::now();
                for c in 0..p {
                    for g in 0..group {
                        convert_query(
                            &qw[(c * group + g) * hd..(c * group + g + 1) * hd],
                            &mut qrow,
                        )
                        .unwrap();
                        write_out(&resf, &mut out).unwrap();
                    }
                }
                std::hint::black_box((&qrow, &out));
                if r >= 2 {
                    ts.push(t0.elapsed().as_secs_f64() * 1e3);
                }
            }
            let conv = med(&mut ts);
            // Blocked production path for the same queries (qb = 2 columns x group), serial.
            let mut ts = Vec::new();
            let mut o = vec![0i64; 2 * group * hd];
            for r in 0..reps + 2 {
                let t0 = Instant::now();
                for c0 in (0..p).step_by(2) {
                    let base = c0 * group * hd;
                    // Query rows are dense here: stride = group * hd.
                    kv.attn_block_f32(0, 0, &qw[base..], group * hd, c0..c0 + 2, &mut o)
                        .unwrap();
                }
                if r >= 2 {
                    ts.push(t0.elapsed().as_secs_f64() * 1e3);
                }
            }
            let block_total = med(&mut ts);
            let (t1s, pairs) = run(1, false);
            let (t1f, _) = run(1, true);
            let (t2s, _) = run(2, false);
            let (t2f, _) = run(2, true);
            let (t3s, _) = run(3, false);
            let (t3f, _) = run(3, true);
            let cyc = |ms: f64| ms * 1e6 / pairs;
            println!("--- {name}, P={p}, one KV head, serial, tiles only ({pairs} pairs), ms and ns/pair ---");
            println!(
                "scores      stream {t1s:7.3} ms {:5.2} ns/pair | fixed {t1f:7.3} ms {:5.2}",
                cyc(t1s),
                cyc(t1f)
            );
            println!(
                "scores+wts  stream {t2s:7.3} ms {:5.2} ns/pair | fixed {t2f:7.3} ms {:5.2}",
                cyc(t2s),
                cyc(t2f)
            );
            println!(
                "all 3 phases stream {t3s:6.3} ms {:5.2} ns/pair | fixed {t3f:7.3} ms {:5.2}",
                cyc(t3s),
                cyc(t3f)
            );
            println!(
                "phase shares (stream): scores {:.0}%, weights {:.0}%, accumulate {:.0}%",
                100.0 * t1s / t3s,
                100.0 * (t2s - t1s) / t3s,
                100.0 * (t3s - t2s) / t3s
            );
            println!("conversions (q cvt + readout) {conv:.3} ms; blocked attn_block_f32 qb=2 total {block_total:.3} ms for {} queries", p * group);
        }
        // Empty dispatch: `Pool::chunks_mut` over 64 x 14 and 32 x 2 trivial tasks.
        let pool = crate::engine::chart::pool::Pool::global();
        for &(tasks, label) in &[
            (
                64 * 14usize,
                "896 tasks (per-head dispatch, k=64, 14 heads)",
            ),
            (64usize, "64 tasks (qb=2 blocks, 2 KV heads)"),
        ] {
            let mut buf = vec![0i64; tasks];
            let mut ts = Vec::new();
            for r in 0..200 {
                let t0 = Instant::now();
                pool.chunks_mut(&mut buf, 1, &|t, _s, d| d[0] = t as i64);
                if r >= 20 {
                    ts.push(t0.elapsed().as_secs_f64() * 1e3);
                }
            }
            println!("empty dispatch {label}: {:.4} ms", med(&mut ts));
        }
    }
}
