#![allow(
    clippy::many_single_char_names,
    clippy::similar_names,
    clippy::cast_possible_wrap,
    clippy::cast_sign_loss,
    clippy::cast_precision_loss,
    reason = "test vectors: short math names, bounded integer words, exact-range f32 conversion"
)]

use super::*;
use crate::engine::rope::RopeTable;

fn lcg(state: &mut u64) -> u64 {
    *state = state
        .wrapping_mul(6_364_136_223_846_793_005)
        .wrapping_add(1_442_695_040_888_963_407);
    *state >> 11
}

fn word(state: &mut u64, bits: u32) -> i64 {
    let span = 1i64 << bits;
    (lcg(state) % (2 * span as u64)) as i64 - span
}

/// Reference `NORM` rotation of every head of `x`: pair `(2i, 2i+1)` turns by `turns[i]`, each
/// pair rotated by a one-pair `RopeTable` so the trig and rounding are the engine's own.
fn norm_rotate(turns: &[u64], x: &mut [i64], hd: usize, pos: u32) {
    for head in x.chunks_mut(hd) {
        for i in 0..hd / 2 {
            let one = RopeTable::from_turns(2, vec![turns[i]]).unwrap();
            let mut p = [head[2 * i], head[2 * i + 1]];
            one.rotate_one(&mut p, pos).unwrap();
            head[2 * i] = p[0];
            head[2 * i + 1] = p[1];
        }
    }
}

/// `P^-1` per head: position `j` of `y` returns to `norm_source(j)`.
fn unpermute(y: &[i64], hd: usize) -> Vec<i64> {
    let mut out = vec![0i64; y.len()];
    for (h, head) in y.chunks(hd).enumerate() {
        for (j, v) in head.iter().enumerate() {
            out[h * hd + norm_source(j, hd)] = *v;
        }
    }
    out
}

const POSITIONS: [u32; 6] = [0, 1, 7, 100, 4095, 100_000];

#[test]
fn norm_rotation_equals_inverse_permuted_neox_of_the_permuted_vector() {
    let mut s = 7u64;
    for hd in [64usize, 128] {
        let table = RopeTable::new(10_000.0, hd).unwrap();
        for pos in POSITIONS {
            let x: Vec<i64> = (0..3 * hd).map(|_| word(&mut s, 36)).collect();
            let mut want = x.clone();
            norm_rotate(table.turns(), &mut want, hd, pos);
            let mut y = x.clone();
            permute_heads(&mut y, 1, 3, hd, &mut Vec::new()).unwrap();
            table.rotate_one(&mut y, pos).unwrap();
            assert_eq!(unpermute(&y, hd), want, "hd {hd} pos {pos}");
        }
    }
}

#[test]
fn permuted_rows_plus_neox_give_the_same_scores_as_in_place_norm() {
    let (n_head, n_kv, hd, cols) = (4usize, 2usize, 64usize, 5usize);
    let table = RopeTable::new(100_000.0, hd).unwrap();
    let mut s = 99u64;
    let wq: Vec<i64> = (0..n_head * hd * cols).map(|_| word(&mut s, 8)).collect();
    let wk: Vec<i64> = (0..n_kv * hd * cols).map(|_| word(&mut s, 8)).collect();
    let act: Vec<i64> = (0..cols).map(|_| word(&mut s, 30)).collect();
    let matvec = |w: &[i64]| -> Vec<i64> {
        w.chunks(cols)
            .map(|r| r.iter().zip(&act).map(|(a, b)| a * b).sum())
            .collect()
    };
    let (mut wq_p, mut wk_p) = (wq.clone(), wk.clone());
    let mut scratch = Vec::new();
    permute_qk(0, &mut wq_p, cols, [n_head, n_kv, hd], &mut scratch).unwrap();
    permute_qk(1, &mut wk_p, cols, [n_head, n_kv, hd], &mut scratch).unwrap();
    for pos in POSITIONS {
        let (mut q, mut k) = (matvec(&wq), matvec(&wk));
        norm_rotate(table.turns(), &mut q, hd, pos);
        norm_rotate(table.turns(), &mut k, hd, pos);
        let (mut qp, mut kp) = (matvec(&wq_p), matvec(&wk_p));
        table.rotate_one(&mut qp, pos).unwrap();
        table.rotate_one(&mut kp, pos).unwrap();
        // k-only skip must change a score, so the comparison below can fail.
        let mut q_only = matvec(&wq_p);
        table.rotate_one(&mut q_only, pos).unwrap();
        let mut k_raw = matvec(&wk);
        table.rotate_one(&mut k_raw, pos).unwrap();
        let mut any_q_only_differs = false;
        for h in 0..n_head {
            let g = h / (n_head / n_kv);
            let dot = |a: &[i64], b: &[i64]| -> i128 {
                a.iter()
                    .zip(b)
                    .map(|(x, y)| i128::from(*x) * i128::from(*y))
                    .sum()
            };
            let want = dot(&q[h * hd..(h + 1) * hd], &k[g * hd..(g + 1) * hd]);
            let got = dot(&qp[h * hd..(h + 1) * hd], &kp[g * hd..(g + 1) * hd]);
            assert_eq!(got, want, "Q32 exact, head {h} pos {pos}");
            let skipped = dot(&q_only[h * hd..(h + 1) * hd], &k_raw[g * hd..(g + 1) * hd]);
            any_q_only_differs |= skipped != want;
            // f32 carrier: the same values summed in the permuted order.
            let f = |v: i64| v as f32 / 4_294_967_296.0;
            let (mut a, mut b, mut mag) = (0f32, 0f32, 0f32);
            for i in 0..hd {
                let t = f(q[h * hd + i]) * f(k[g * hd + i]);
                a += t;
                mag += t.abs();
            }
            for j in 0..hd {
                b += f(qp[h * hd + j]) * f(kp[g * hd + j]);
            }
            assert!(
                (a - b).abs() <= hd as f32 * f32::EPSILON * mag.max(f32::MIN_POSITIVE),
                "f32 order difference {a} vs {b}, head {h} pos {pos}"
            );
        }
        assert!(
            any_q_only_differs,
            "skipping the k permutation changes a score"
        );
    }
}

#[test]
fn permute_heads_moves_whole_units_and_refuses_bad_geometry() {
    let mut b: Vec<u8> = (0..2 * 4 * 3).collect();
    permute_heads(&mut b, 3, 2, 4, &mut Vec::new()).unwrap();
    // hd 4: sources [0, 2, 1, 3]; unit 3 bytes.
    assert_eq!(&b[..12], &[0, 1, 2, 6, 7, 8, 3, 4, 5, 9, 10, 11]);
    assert_eq!(&b[12..15], &[12, 13, 14]);
    let mut v = vec![0u8; 24];
    assert!(permute_heads(&mut v, 3, 2, 3, &mut Vec::new()).is_err());
    assert!(permute_heads(&mut v, 3, 3, 4, &mut Vec::new()).is_err());
    assert!(permute_heads(&mut v, 0, 2, 4, &mut Vec::new()).is_err());
}

fn entry(ggml_type: u32, dims: Vec<u64>, n_bytes: Option<u64>) -> TensorEntry {
    TensorEntry {
        name: "blk.0.attn_q.weight".to_string(),
        ggml_type,
        quant: QuantKind::from_ggml(ggml_type),
        n_elements: dims.iter().product(),
        dims,
        n_bytes,
        byte_range: 0..n_bytes.unwrap_or(0),
    }
}

#[test]
fn row_bytes_refuses_non_row_contiguous_tensors() {
    let q8 = quant::GGML_TYPE_Q8_0;
    assert_eq!(
        row_bytes_of(&entry(q8, vec![64, 8], Some(544)), 8).unwrap(),
        68
    );
    assert!(row_bytes_of(&entry(q8, vec![64, 8], Some(543)), 8).is_err());
    assert!(row_bytes_of(&entry(q8, vec![64, 8], Some(544)), 7).is_err());
    assert!(row_bytes_of(&entry(q8, vec![64], Some(68)), 1).is_err());
    assert!(row_bytes_of(&entry(quant::GGML_TYPE_PQ2_0, vec![64, 8], Some(544)), 8).is_err());
    assert!(row_bytes_of(&entry(q8, vec![64, 8], None), 8).is_err());
}
