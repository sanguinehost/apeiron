//! Load-time row permutation that lets the `NEOX` `RoPE` serve `NORM` architectures.
//!
//! `NORM` `RoPE` (llama.cpp `LLAMA_ROPE_TYPE_NORM`, `ggml-cpu/ops.cpp` `rotate_pairs(n, 1, ..)`)
//! rotates the consecutive pairs `(2i, 2i + 1)` of a head with frequency index `i`; `NEOX`, the
//! pairing [`crate::engine::rope`] implements, rotates `(i, i + n/2)` with the same index. Let `P`
//! send position `2i` to `i` and `2i + 1` to `i + n/2`, so `(P x)[j] = x[norm_source(j)]`. Then
//! `NORM(x) = P^-1 NEOX(P x)` and `(P q) . (P k) = q . k`, so permuting the output rows of `attn_q`
//! and `attn_k` by `P` per head (and every per-output-feature vector on the q/k path) once at load,
//! then running `NEOX`, gives `NORM`'s scores. llama.cpp's `conversion/llama.py`
//! `LlamaModel.permute` (`:174-179`, applied at `:258-262`) is `P^-1` (HF `NEOX` order to `NORM`
//! order); this is its inverse. The value path (`attn_v`, `attn_output`) is untouched.

use super::{Engine, EngineError, QuantKind, TensorEntry};
use crate::format::quant;

/// The source index that lands at position `j` of a permuted head of width `hd` (even):
/// `2j` for `j < hd/2`, `2(j - hd/2) + 1` otherwise.
#[must_use]
pub(crate) fn norm_source(j: usize, hd: usize) -> usize {
    let half = hd / 2;
    if j < half {
        2 * j
    } else {
        2 * (j - half) + 1
    }
}

/// Permute, in place, the `heads` consecutive groups of `hd` units in `buf` (each unit is `unit`
/// elements) so that unit `j` of each group becomes the old unit `norm_source(j, hd)`.
///
/// Complexity: time `O(buf.len())` element copies (each head is copied out once and written back
/// once); space `O(hd * unit)` scratch, one head, reused across heads.
///
/// # Errors
///
/// [`EngineError::ConfigMismatch`] when `hd` is zero or odd or `buf.len() != heads * hd * unit`.
pub(crate) fn permute_heads<T: Copy>(
    buf: &mut [T],
    unit: usize,
    heads: usize,
    hd: usize,
    scratch: &mut Vec<T>,
) -> Result<(), EngineError> {
    let head_len = hd.checked_mul(unit).ok_or(EngineError::LengthOverflow)?;
    let total = head_len
        .checked_mul(heads)
        .ok_or(EngineError::LengthOverflow)?;
    if hd == 0 || !hd.is_multiple_of(2) || unit == 0 || buf.len() != total {
        return Err(EngineError::ConfigMismatch(format!(
            "qk permutation geometry: len {} != {heads} heads x {hd} x {unit}",
            buf.len()
        )));
    }
    for h in 0..heads {
        let base = h * head_len;
        scratch.clear();
        scratch.extend_from_slice(&buf[base..base + head_len]);
        for j in 0..hd {
            let src = norm_source(j, hd) * unit;
            buf[base + j * unit..base + (j + 1) * unit].copy_from_slice(&scratch[src..src + unit]);
        }
    }
    Ok(())
}

/// Permute the output features of `attn_q` (`which == 0`, `n_head` heads) or `attn_k` (`which ==
/// 1`, `n_kv` heads) by `P`: the one site every q/k weight and bias goes through.
///
/// Complexity: as [`permute_heads`].
///
/// # Errors
///
/// As [`permute_heads`].
pub(crate) fn permute_qk<T: Copy>(
    which: usize,
    buf: &mut [T],
    unit: usize,
    geom: [usize; 3],
    scratch: &mut Vec<T>,
) -> Result<(), EngineError> {
    let [n_head, n_kv, hd] = geom;
    let heads = if which == 0 { n_head } else { n_kv };
    permute_heads(buf, unit, heads, hd, scratch)
}

/// The byte length of one row (one output feature) of the 2-D weight `t`, refusing a tensor whose
/// rows are not contiguous blocks of `required_bytes(type, dims[0])`: a quant family without
/// geometry, a rank other than 2, or a stored size that is not `rows * row_bytes`.
pub(crate) fn row_bytes_of(t: &TensorEntry, rows: usize) -> Result<usize, EngineError> {
    let bad = |reason: &'static str| EngineError::BadVector {
        name: t.name.clone(),
        reason,
    };
    if matches!(t.quant, QuantKind::Other(_)) || t.dims.len() != 2 {
        return Err(bad("rows not contiguous"));
    }
    if t.dims[1] != rows as u64 {
        return Err(bad("dims"));
    }
    let row = quant::required_bytes(t.ggml_type, t.dims[0]).map_err(|_| bad("geometry"))?;
    let total = row
        .checked_mul(rows as u64)
        .ok_or(EngineError::LengthOverflow)?;
    if t.n_bytes != Some(total) {
        return Err(bad("rows not contiguous"));
    }
    usize::try_from(row).map_err(|_| EngineError::LengthOverflow)
}

impl Engine {
    /// Permute every trunk and MTP block's `attn_q`/`attn_k` rows, `attn_{q,k}.bias` and
    /// `attn_{q,k}_norm.weight` per head by `P` (see the module comment), once, in the engine's
    /// owned byte buffer and resolved vectors.
    ///
    /// Complexity: time `O(bytes of the q/k weights)` byte copies plus `O(q/k bias and gain
    /// words)`; space `O(one head's rows)` scratch (`head_dim * row_bytes` bytes).
    ///
    /// # Errors
    ///
    /// [`EngineError::ConfigMismatch`] for partial rotary (`rot_dims != head_dim`), an odd head
    /// width or an attention output gate; [`EngineError::BadVector`] for a q/k tensor whose rows
    /// are not contiguous ([`row_bytes_of`]); [`EngineError::RowOutOfBounds`] past the buffer.
    pub(super) fn permute_qk_rows(&mut self) -> Result<(), EngineError> {
        let hd = self.config.head_dim;
        if self.config.rot_dims != hd || !hd.is_multiple_of(2) || self.config.attn_gate {
            return Err(EngineError::ConfigMismatch(format!(
                "qk permutation needs full rotary, even head_dim, no gate: rot {} head {hd} gate {}",
                self.config.rot_dims, self.config.attn_gate
            )));
        }
        let heads = [self.config.n_head, self.config.n_head_kv];
        let geom = [heads[0], heads[1], hd];
        let mut scratch_b: Vec<u8> = Vec::new();
        let mut scratch_w: Vec<i64> = Vec::new();
        for layer in 0..self.config.n_layer + self.config.n_nextn {
            for (which, (kind, n)) in ["q", "k"].into_iter().zip(heads).enumerate() {
                let name = format!("blk.{layer}.attn_{kind}.weight");
                if let Some(t) = self.table.get(&name) {
                    let row = row_bytes_of(t, n * hd)?;
                    let start = usize::try_from(t.byte_range.start)
                        .map_err(|_| EngineError::LengthOverflow)?;
                    let len = row * n * hd;
                    let end = start.checked_add(len).ok_or(EngineError::LengthOverflow)?;
                    let slice =
                        self.data
                            .get_mut(start..end)
                            .ok_or(EngineError::RowOutOfBounds {
                                at: start as u64,
                                n: len as u64,
                                end: self.file_len,
                            })?;
                    permute_qk(which, slice, row, geom, &mut scratch_b)?;
                }
                if let Some(b) = self.vectors.biases[layer][which].as_mut() {
                    permute_qk(which, b, 1, geom, &mut scratch_w)?;
                }
                if let Some(g) = self.vectors.qk_norms[layer][which].as_mut() {
                    permute_heads(g, 1, 1, hd, &mut scratch_w)?;
                }
            }
        }
        Ok(())
    }
}

#[cfg(test)]
mod tests;
