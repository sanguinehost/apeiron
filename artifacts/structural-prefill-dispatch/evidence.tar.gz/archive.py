import hashlib,json,subprocess,tarfile,time
from pathlib import Path
root=Path('/home/socol/Workspace/apeiron')
parent=Path('/home/socol/oc-tmp/decode-dispatch')
evidence=Path('/tmp/opencode/structural-dispatch')
owners={
 'compile-graph':['src/engine/step.rs','src/engine/step/cols.rs','src/engine/step/graph.rs'],
 'selective-state':['src/engine/step/spec.rs','src/engine/mixer.rs','src/engine/attn.rs'],
 'quant-certificate':['src/engine/kern/gemm.rs','src/engine/kern/certificate_probe.rs','examples/quant_certificate.rs'],
 'benchmarks':['examples/lookup_probe.rs','examples/llama_context.cpp','tools/structural_decode_bench.py'],
}
start=time.monotonic()
allpaths=[p for paths in owners.values() for p in paths]
assert len(allpaths)==len(set(allpaths)) and all(len(paths)<=3 for paths in owners.values())
base='3f29041c23697ab7aebab23da95fa900d3ff27b4'
manifest={'base':base,'main_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'owners':owners,'sources':{},'status':'stopped after current handbacks by user; no integration; no general2x receipt'}
for task,paths in owners.items():
 wt=parent/('worktree-agent-APEIRON-STRUCTURAL-SPIKE-'+task)
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=wt,text=True).strip()==base
 target=evidence/task/'recovery'
 target.mkdir(exist_ok=True)
 patch=subprocess.check_output(['git','diff','--binary','HEAD'],cwd=wt)
 # Preserve incoming overlays and every untracked owned source in the recovery patch.
 untracked=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=wt,text=True).splitlines()
 for path in paths:
  p=wt/path
  assert p.is_file(),path
  if path in untracked:
   proc=subprocess.run(['git','diff','--no-index','--binary','/dev/null',path],cwd=wt,stdout=subprocess.PIPE)
   assert proc.returncode in (0,1)
   patch+=proc.stdout
  dest=target/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(p.read_bytes())
  manifest['sources'][task+':'+path]=hashlib.sha256(p.read_bytes()).hexdigest()
 (target/'complete.patch').write_bytes(patch)
 # Capture the staged benchmark/spec helper overlay that is part of its source identity.
 if task=='benchmarks':
  p=wt/'src/engine/step/spec.rs';dest=target/'src/engine/step/spec.rs';dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(p.read_bytes())
  manifest['sources'][task+':src/engine/step/spec.rs']=hashlib.sha256(p.read_bytes()).hexdigest()
 manifest.setdefault('worktrees',{})[task]={'path':str(wt),'branch':'codex/structural-'+task,'status':subprocess.check_output(['git','status','--short'],cwd=wt,text=True)}
manifest['rustc']=subprocess.check_output(['rustc','--version'],cwd=root,text=True).strip()
manifest['planning_gate']={'exit':0,'budget':60,'elapsed':time.monotonic()-start,'checks':'four disjoint ownership sets <=3 paths; source presence; exact task base; recoverable patches and hashes'}
(evidence/'dispatch-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
artifact=root/'artifacts/structural-prefill-dispatch';artifact.mkdir(parents=True,exist_ok=True)
archive=artifact/'evidence.tar.gz'
assert not archive.exists(),'archive already exists'
with tarfile.open(archive,'w:gz') as tar:
 for p in sorted(evidence.rglob('*')):
  if p.is_file() and '__pycache__' not in p.parts:
   tar.add(p,arcname=str(p.relative_to(evidence)))
with tarfile.open(archive) as tar:
 for key,digest in manifest['sources'].items():
  task,path=key.split(':',1)
  data=tar.extractfile(task+'/recovery/'+path).read()
  assert hashlib.sha256(data).hexdigest()==digest,key
assert time.monotonic()-start<60
sha=hashlib.sha256(archive.read_bytes()).hexdigest()
(artifact/'sha256.txt').write_text(sha+'  evidence.tar.gz\n')
print(json.dumps({'archive':str(archive),'sha256':sha,'elapsed':time.monotonic()-start,'recovery_sources':len(manifest['sources'])},indent=2))
