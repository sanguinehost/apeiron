# Batched-prefill quantisation certificate handback

Decision: reject this conservative independent-weight-residual interval certificate as a skipping mechanism on the sampled README200 population. No impossibility claim about tighter observation-directed bounds.

Task: APEIRON-STRUCTURAL-SPIKE-quant-certificate. Owner: quant_certificate. Base: 3f29041c23697ab7aebab23da95fa900d3ff27b4. Owned source: src/engine/kern/gemm.rs, src/engine/kern/certificate_probe.rs, examples/quant_certificate.rs. Main and all other workstreams untouched; abandoned chart/ffn.rs edit restored from exact base bytes.

Focused gate: `timeout --kill-after=5 540 python3 /tmp/opencode/structural-dispatch/quant-certificate/gate.py`, cwd `/home/socol/oc-tmp/decode-dispatch/worktree-agent-APEIRON-STRUCTURAL-SPIKE-quant-certificate`, exit0, elapsed47.390656s; budget540s across descendants.

| accepted stage | exit | elapsed seconds |
|---|---:|---:|
| positive | 0 | 13.772316 |
| build | 0 | 3.686069 |
| probe-off | 0 | 1.383539 |
| probe-on | 0 | 4.951332 |
| corrupted-scale | 101 | 12.859089 |
| restored | 0 | 10.730590 |

The corrupted-scale source changed the candidate common scale from S to S+1. It produced the intended `certificate fixture scale` mismatch. Restoring source passed in a distinct Cargo target. This control tests the diagnostic certificate checker on a positive fixed fixture; no actual-model certified block exists in this sample.

Model/prompt/binary/owned SHA256 identities are in receipt.json and source-identity.json. CPU: Intel Core i9-14900KF; Qwen3.5-0.8B Q8_0, Q32 carrier. Ordinary batched prefill processes199 tokens in64/64/64/7-column groups, then executes the final prompt token. The probe samples one actual fused FFN column from each of24 layer slots, spread across those4 groups. Every sample metadata line identifies group, layer and column; all24 layers occur once. It evaluates3584 hidden rows per sample:86,016 rows and2,688 width32 blocks per omitted-bit count. This is one README200 fixture, not a benchmark-wide sample.

| omitted low weight bits | valid hidden row intervals | stable shared scales | stable lane codes at stable scales | certified32-blocks |
|---|---:|---:|---:|---:|
| 1 | 86016 | 327 | 19 | 0/2688 |
| 2 | 86016 | 2 | 0 | 0/2688 |
| 3 | 86016 | 0 | 0 | 0/2688 |
| 4 | 86016 | 0 | 0 | 0/2688 |

Ideal fine-plane opportunity at this certificate scope:0 for all omitted-bit counts. Diagnostic interval/oracle overhead:3.616706s summed over24 sampled calls; probe-off process1.383539s versus probe-on4.951332s, one diagnostic run each, not a performance acceptance A/B. The full gate/up oracle work occurs before each overhead timer, and these full-value reads never count as saved work. Existing Q8_0 bytes also need a separately gated bit-plane layout before logical omitted bits become reduced DRAM traffic. Any batched skipping additionally needs every consuming column certified; this probe certifies no sampled column block.

Numeric premises and derivation:

- Q8_0 signed byte w is `(w >> bits) << bits` plus an unknown residual in `[0,2^bits-1]`. Finite f16 scale splits through the real `kern/pow2::f16_split`; checked i128 signed interval products/sums include the actual QuantAct codes/scales. All terms accumulate before the executing ties-up32-bit row shift.
- `fixed_exp` quotient bins use exact inverse endpoints of `floor((x*6196328019+2^63)/2^64)`, intersect with the incoming interval. Each of seven real Horner coefficients is applied with the executing signed ties-away rounding, then the exact integer scale branch. There is no empirical Lipschitz constant or assumed monotonicity of the polynomial/exponential implementation.
- SiLU sign and saturation pieces use actual boundaries -21*ONE and16*ONE. In-window interval quotients use positive denominator bounds; overflow/range/denominator ambiguity returns uncertified. The hidden product follows the actual ties-up Q32 shift.
- Minimum and maximum possible block magnitudes must select the same real `act_scale`. Every lane's endpoint codes must agree at that common scale and dequantisation must fit i64. Only then is a block certified.

Evidence grades:

- Tested: boundary fixture for integer interval nonlinear operations and nonempty certificate; corrupted-scale red/restoration green; actual-model gate/up/SiLU/hidden interval containment on all sampled rows; probe-on/off16 greedy IDs identical.
- Measured: coverage, diagnostic overhead and source/tool identity at this fixture scope. No throughput or2x claim.
- Open: universal soundness/refinement of this mirrored interval evaluator, actual source extraction/Lean audit, f32 certificate, direct all-column coverage, broader prompt population and all Rust/Lean integration barriers. The real fused hidden values are interval oracles. This gate does not separately assert exact fused hidden equality against scalar SwiGLU of the recomputed full gate/up rows; the pre-existing kernel equality gate is unrun here. Actual-model certificate code/scale equality has no nonempty witness because coverage is zero.

Trust excludes rustc/LLVM codegen, GPU/SPIR-V, kernel ABI and unsafe-container correctness. No production value is substituted and no skip is enabled.

Smallest next bounded question, not dispatched: can a tighter residual representation certify any real quantised FFN block while costing less than computing its full fine dot products? Current user stop applies; no follow-up, retry, new wave, commit, merge or push is started. Lead owns archive and worktree cleanup.
