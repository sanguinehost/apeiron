//! Actual-model opt-in certificate coverage and token identity fixture.
use apeiron::engine::loader::Engine;
use apeiron::engine::KernelMode;
fn main() -> Result<(), Box<dyn std::error::Error>> {
    let args: Vec<String> = std::env::args().collect();
    let engine = Engine::open(&args[1])?;
    let ids: Vec<u32> = std::fs::read_to_string(&args[2])?
        .split_whitespace()
        .map(str::parse)
        .collect::<Result<_, _>>()?;
    assert_eq!(ids.len(), 200, "registered actual README prompt length");
    let mut st = engine.state(256)?;
    let mut token = engine.prefill_state(&mut st, &ids, KernelMode::Q8Act)?;
    let mut out = vec![token];
    for _ in 0..15 {
        token = engine.next_token_state(&mut st, token, KernelMode::Q8Act)?;
        out.push(token);
    }
    println!("TOKENS {out:?}");
    Ok(())
}
