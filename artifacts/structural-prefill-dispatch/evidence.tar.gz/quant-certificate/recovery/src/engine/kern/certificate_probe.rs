//! Diagnostic integer interval execution; it never substitutes a computed activation.
//! Universal soundness and extraction remain open. Every recorded interval is checked against
//! the actual executing oracle, including every certified block's shared scale and codes.
use crate::engine::chart::{matvec_q8act, quant_act, QuantAct};
use crate::engine::kern::pow2::{act_scale, f16_split};
use crate::engine::{silu_fixed, ONE};
use std::sync::atomic::{AtomicUsize, Ordering};

#[derive(Clone, Copy, Debug)]
struct Iv {
    lo: i128,
    hi: i128,
}
impl Iv {
    fn point(x: i128) -> Self {
        Self { lo: x, hi: x }
    }
    fn add(self, x: i128) -> Option<Self> {
        Some(Self {
            lo: self.lo.checked_add(x)?,
            hi: self.hi.checked_add(x)?,
        })
    }
    fn mul(self, b: Self) -> Option<Self> {
        let p = [
            self.lo.checked_mul(b.lo)?,
            self.lo.checked_mul(b.hi)?,
            self.hi.checked_mul(b.lo)?,
            self.hi.checked_mul(b.hi)?,
        ];
        Some(Self {
            lo: *p.iter().min()?,
            hi: *p.iter().max()?,
        })
    }
    fn map(self, f: impl Fn(i128) -> i128) -> Self {
        Self {
            lo: f(self.lo),
            hi: f(self.hi),
        }
    }
    fn contains(self, x: i64) -> bool {
        self.lo <= i128::from(x) && i128::from(x) <= self.hi
    }
    fn narrow(self) -> Option<Self> {
        (self.lo >= i128::from(i64::MIN) && self.hi <= i128::from(i64::MAX)).then_some(self)
    }
    fn join(self, b: Self) -> Self {
        Self {
            lo: self.lo.min(b.lo),
            hi: self.hi.max(b.hi),
        }
    }
}
fn round_away(x: i128) -> Option<i128> {
    if x >= 0 {
        Some(x.checked_add(1 << 31)? >> 32)
    } else {
        Some(-(x.checked_neg()?.checked_add(1 << 31)? >> 32))
    }
}
fn ceil_div(x: i128, d: i128) -> i128 {
    x.div_euclid(d) + i128::from(x.rem_euclid(d) != 0)
}

/// O(63) range-reduction branches, each seven interval multiply/round steps; O(1) scratch.
/// The quotient-bin endpoints come from the executing floor((x*R+2^63)/2^64).
fn exp_iv(x: Iv) -> Option<Iv> {
    let one = i128::from(ONE);
    if x.lo < -16 * one || x.hi > 21 * one {
        return None;
    }
    let recip = 6_196_328_019i128;
    let ln2 = 2_977_044_472i128;
    let k_of = |v: i128| (v * recip + (1 << 63)) >> 64;
    let mut result: Option<Iv> = None;
    for k in k_of(x.lo)..=k_of(x.hi) {
        let lo = x.lo.max(ceil_div((k << 64) - (1 << 63), recip));
        let hi = x.hi.min(ceil_div(((k + 1) << 64) - (1 << 63), recip) - 1);
        if lo > hi {
            continue;
        }
        let r = Iv {
            lo: lo - k * ln2,
            hi: hi - k * ln2,
        };
        let mut acc = Iv::point(852_176);
        for c in [
            5_965_232,
            35_791_394,
            178_956_971,
            715_827_883,
            2_147_483_648,
            4_294_967_296,
            4_294_967_296,
        ] {
            let product = acc.mul(r)?;
            acc = Iv {
                lo: round_away(product.lo)?,
                hi: round_away(product.hi)?,
            }
            .add(c)?;
        }
        let scaled = if k >= 0 {
            acc.mul(Iv::point(1i128.checked_shl(u32::try_from(k).ok()?)?))?
        } else {
            let n = u32::try_from(-k).ok()?;
            if n >= 64 {
                Iv::point(0)
            } else {
                acc.add(1i128 << (n - 1))?.map(|v| v >> n)
            }
        }
        .narrow()?;
        result = Some(result.map_or(scaled, |v| v.join(scaled)));
    }
    result
}

/// At most four sign/saturation pieces; each invokes the bounded integer exponential interval.
/// Quotients use minimum numerator/maximum positive denominator and the reverse for the maximum.
fn silu_iv(g: Iv) -> Option<Iv> {
    g.narrow()?;
    let one = i128::from(ONE);
    let mut result: Option<Iv> = None;
    let mut include = |v: Iv| {
        result = Some(result.map_or(v, |old| old.join(v)));
    };
    if g.lo <= -21 * one {
        include(Iv::point(0));
    }
    if g.hi >= 16 * one {
        include(Iv {
            lo: g.lo.max(16 * one),
            hi: g.hi,
        });
    }
    let lo = g.lo.max(-21 * one + 1);
    let hi = g.hi.min(16 * one - 1);
    if lo <= hi {
        for (a, b, negative) in [(lo, hi.min(-1), true), (lo.max(0), hi, false)] {
            if a > b {
                continue;
            }
            let e = exp_iv(Iv { lo: -b, hi: -a })?;
            let den = e.add(one)?;
            if den.lo <= 0 || den.hi > i128::from(i64::MAX) {
                return None;
            }
            let mag = if negative {
                Iv { lo: -b, hi: -a }
            } else {
                Iv { lo: a, hi: b }
            };
            let num = mag.mul(Iv::point(one))?;
            let q = Iv {
                lo: (num.lo + den.hi / 2) / den.hi,
                hi: (num.hi + den.lo / 2) / den.lo,
            };
            include(if negative {
                Iv {
                    lo: -q.hi,
                    hi: -q.lo,
                }
            } else {
                q
            });
        }
    }
    result?.narrow()
}

/// O(n_in) per row in checked scalar multiply-adds; O(1) scratch. Each signed weight is
/// floor(w/2^bits)*2^bits plus an unknown residual in [0,2^bits-1]. All terms are summed before
/// the unchanged ties-up row rounding. The bound reads high codes only; the oracle reads all bits.
fn row_iv(raw: &[u8], q: &QuantAct, row: usize, bits: u32) -> Option<Iv> {
    let nb = q.scales().len();
    let data = raw.get(row.checked_mul(nb * 34)?..(row + 1).checked_mul(nb * 34)?)?;
    let mut acc = Iv::point(0);
    let remainder = (1i128 << bits) - 1;
    for b in 0..nb {
        let block = &data[b * 34..(b + 1) * 34];
        let (m, k) = f16_split(u16::from_le_bytes([block[0], block[1]]))?;
        let scale = i128::from(m)
            .checked_mul(1i128 << k)?
            .checked_mul(i128::from(q.scales()[b]))?;
        let mut dot = Iv::point(0);
        for j in 0..32 {
            let w = i128::from(block[j + 2] as i8);
            let high = (w >> bits) << bits;
            let term = Iv {
                lo: high,
                hi: high + remainder,
            }
            .mul(Iv::point(i128::from(q.codes()[b * 32 + j])))?;
            dot = Iv {
                lo: dot.lo.checked_add(term.lo)?,
                hi: dot.hi.checked_add(term.hi)?,
            };
        }
        let term = dot.mul(Iv::point(scale))?;
        acc = Iv {
            lo: acc.lo.checked_add(term.lo)?,
            hi: acc.hi.checked_add(term.hi)?,
        };
    }
    acc.add(1 << 31)?.map(|v| v >> 32).narrow()
}
fn code(x: i128, s: i128) -> i8 {
    if s == 0 {
        return 0;
    }
    let m = x.abs();
    let v = (m + s / 2) / s;
    let v = if x < 0 { -v } else { v };
    i8::try_from(v).expect("certificate scale covers each endpoint")
}

/// O(block width) comparisons and rounding operations; O(block width) output. A common scale
/// exists only if act_scale(max minimum magnitude) equals act_scale(max maximum magnitude).
fn certify(xs: &[Iv]) -> Option<(i64, Vec<i8>)> {
    let mut lower = 0i128;
    let mut upper = 0i128;
    for x in xs {
        x.narrow()?;
        let min = if x.lo <= 0 && x.hi >= 0 {
            0
        } else {
            x.lo.abs().min(x.hi.abs())
        };
        lower = lower.max(min);
        upper = upper.max(x.lo.abs().max(x.hi.abs()));
    }
    let sl = act_scale(u64::try_from(lower).ok()?)?;
    let su = act_scale(u64::try_from(upper).ok()?)?;
    if sl != su {
        return None;
    }
    let s = i64::try_from(sl).ok()?;
    let mut codes = Vec::with_capacity(xs.len());
    for x in xs {
        let a = code(x.lo, i128::from(s));
        let b = code(x.hi, i128::from(s));
        if a != b {
            return None;
        }
        i64::from(a).checked_mul(s)?;
        codes.push(a);
    }
    Some((s, codes))
}
static CALLS: AtomicUsize = AtomicUsize::new(0);

/// Sample one actual batched-prefill column from each of the24 Qwen layers across4 prefill groups.
/// The full existing row kernel supplies gate/up oracles; the executing fused output supplies h.
/// O(4*n_ff*n_in) scalar multiply-adds plus bounded interval nonlinear execution per sample.
/// Oracle reads and diagnostic overhead cannot count as savings; no value is substituted.
pub(super) fn observe_batch(
    graw: &[u8],
    uraw: &[u8],
    n_in: usize,
    qs: &[QuantAct],
    cols: &[Vec<i64>],
) {
    if std::env::var("APEIRON_CERTIFICATE").as_deref() != Ok("1") {
        return;
    }
    let call = CALLS.fetch_add(1, Ordering::Relaxed);
    let layer = call % 24;
    if call >= 96 || call / 24 != layer % 4 {
        return;
    }
    let column = (layer * 11) % qs.len();
    let q = &qs[column];
    let hidden = &cols[column];
    let gates = matvec_q8act(8, graw, hidden.len(), n_in, q).expect("full executing gate oracle");
    let ups = matvec_q8act(8, uraw, hidden.len(), n_in, q).expect("full executing up oracle");
    eprintln!(
        "CERTIFICATE_SAMPLE call={call} layer={layer} group={} column={column} columns={}",
        call / 24,
        qs.len()
    );
    let start = std::time::Instant::now();
    for bits in [1, 2, 3, 4] {
        let mut intervals = Vec::with_capacity(hidden.len());
        let mut rows = 0;
        for i in 0..hidden.len() {
            let bounds = row_iv(graw, q, i, bits).zip(row_iv(uraw, q, i, bits));
            let h = bounds.and_then(|(g, u)| {
                assert!(g.contains(gates[i]), "gate interval containment");
                assert!(u.contains(ups[i]), "up interval containment");
                let s = silu_iv(g)?;
                assert!(
                    s.contains(silu_fixed(gates[i]).expect("executing gate succeeds")),
                    "SiLU interval containment"
                );
                let h = s.mul(u)?.add(1 << 31)?.map(|v| v >> 32).narrow()?;
                assert!(h.contains(hidden[i]), "hidden interval containment");
                rows += 1;
                Some(h)
            });
            intervals.push(h);
        }
        let mut certified = 0;
        let mut stable_scales = 0;
        let mut stable_codes = 0;
        for (b, block) in intervals.chunks(32).enumerate() {
            if let Some(xs) = block.iter().copied().collect::<Option<Vec<_>>>() {
                let lower = xs
                    .iter()
                    .map(|x| {
                        if x.lo <= 0 && x.hi >= 0 {
                            0
                        } else {
                            x.lo.abs().min(x.hi.abs())
                        }
                    })
                    .max()
                    .unwrap_or(0);
                let upper = xs
                    .iter()
                    .map(|x| x.lo.abs().max(x.hi.abs()))
                    .max()
                    .unwrap_or(0);
                let sl = act_scale(u64::try_from(lower).expect("narrowed interval"));
                let su = act_scale(u64::try_from(upper).expect("narrowed interval"));
                if let Some(scale) = sl.filter(|_| sl == su) {
                    stable_scales += 1;
                    stable_codes += xs
                        .iter()
                        .filter(|x| code(x.lo, i128::from(scale)) == code(x.hi, i128::from(scale)))
                        .count();
                }
                if let Some((scale, codes)) = certify(&xs) {
                    let oracle = quant_act(&hidden[b * 32..(b * 32 + 32).min(hidden.len())])
                        .expect("executing hidden quantizes");
                    assert_eq!(
                        scale,
                        oracle.scales()[0],
                        "certified scale disagrees with full oracle"
                    );
                    assert_eq!(
                        codes,
                        oracle.codes(),
                        "certified codes disagree with full oracle"
                    );
                    certified += 1;
                }
            }
        }
        eprintln!(
            "CERTIFICATE call={call} omitted_bits={bits} rows={rows}/{} blocks={certified}/{} stable_scales={stable_scales} stable_codes={stable_codes}",
            hidden.len(),
            hidden.len().div_ceil(32)
        );
    }
    eprintln!(
        "CERTIFICATE_OVERHEAD call={call} ns={}",
        start.elapsed().as_nanos()
    );
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn interval_operations_contain_executing_boundaries() {
        for v in [
            -21 * ONE,
            -21 * ONE + 1,
            -ONE,
            -ONE / 2,
            -1,
            0,
            1,
            ONE,
            16 * ONE - 1,
            16 * ONE,
        ] {
            for radius in [0, 1, ONE / 8] {
                let g = Iv {
                    lo: i128::from(v - radius),
                    hi: i128::from(v + radius),
                };
                if let Some(iv) = silu_iv(g) {
                    for x in [v - radius, v, v + radius] {
                        assert!(
                            iv.contains(silu_fixed(x).unwrap()),
                            "SiLU fixture {x} {iv:?}"
                        );
                    }
                }
            }
        }
        for x in [-16 * ONE, -ONE, 0, ONE, 21 * ONE] {
            assert!(exp_iv(Iv::point(i128::from(x)))
                .unwrap()
                .contains(crate::numeric::fixed_exp::fixed_exp(x).unwrap()));
        }
        assert!(exp_iv(Iv {
            lo: -17 * i128::from(ONE),
            hi: 0
        })
        .is_none());
        let xs = [Iv::point(130); 32];
        let (scale, codes) = certify(&xs).unwrap();
        let oracle = quant_act(&[130; 32]).unwrap();
        assert_eq!(scale, oracle.scales()[0], "certificate fixture scale");
        assert_eq!(codes, oracle.codes(), "certificate fixture codes");
        assert!(certify(&[Iv { lo: 127, hi: 128 }; 32]).is_none());
        assert!(certify(&[Iv { lo: 129, hi: 131 }; 32]).is_none());
    }
}
