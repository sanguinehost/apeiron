import os, pathlib, shutil, subprocess, time, json, hashlib, re
ROOT=pathlib.Path('/home/socol/oc-tmp/decode-dispatch/worktree-agent-APEIRON-STRUCTURAL-SPIKE-quant-certificate')
LOG=pathlib.Path('/tmp/opencode/structural-dispatch/quant-certificate')
TARGET='/home/socol/oc-tmp/decode-dispatch/target-quant-certificate'
CONTROL=pathlib.Path('/home/socol/oc-tmp/decode-dispatch/control-quant-certificate')
start=time.monotonic();events=[]
def run(name,args,cwd=ROOT,target=TARGET,extra=None,expect=0,needle=None):
    env=os.environ.copy();env.update(CARGO_TARGET_DIR=target,APEIRON_F32_CARRIER='0',APEIRON_CERTIFICATE='0',APEIRON_PREFILL_COLS='64',TMPDIR='/home/socol/oc-tmp')
    if extra:env.update(extra)
    t=time.monotonic();r=subprocess.run(args,cwd=cwd,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=max(1,530-(t-start)))
    out=r.stdout;(LOG/(name+'.log')).write_text(out)
    events.append(dict(name=name,args=args,cwd=str(cwd),status=r.returncode,elapsed=time.monotonic()-t))
    assert r.returncode==expect,(name,r.returncode,out[-4000:])
    if needle:assert needle in out,(name,'missing attributable diagnostic')
    print(name,r.returncode,round(events[-1]['elapsed'],2),flush=True)
    return out
try:
    assert not CONTROL.exists(),'control target already exists; inspect first'
    fixture=['cargo','test','--release','--locked','--lib','interval_operations_contain_executing_boundaries','--','--nocapture']
    run('positive',fixture,needle='1 passed')
    run('build',['cargo','build','--release','--locked','--example','quant_certificate'])
    model='/home/socol/models/qwen3.5-0.8b/Qwen3.5-0.8B-Q8_0.gguf';ids='/home/socol/Workspace/apeiron/tests/fixtures/qwen35-prompt2.ids'
    binary=TARGET+'/release/examples/quant_certificate'
    off=run('probe-off',[binary,model,ids])
    on=run('probe-on',[binary,model,ids],extra={'APEIRON_CERTIFICATE':'1','APEIRON_PREFILL_COLS':'64'},needle='CERTIFICATE call=')
    assert re.findall(r'^TOKENS .+$',off,re.M)==re.findall(r'^TOKENS .+$',on,re.M),'probe token identity'
    samples=[dict(call=int(a),bits=int(b),rows=int(c),total_rows=int(d),certified=int(e),blocks=int(f)) for a,b,c,d,e,f in re.findall(r'CERTIFICATE call=(\d+) omitted_bits=(\d+) rows=(\d+)/(\d+) blocks=(\d+)/(\d+)',on)]
    assert len(samples)==96,('actual model layer population',len(samples))
    CONTROL.mkdir()
    for n in ['src','derive','fold-abi','examples','tests']:
        if (ROOT/n).exists():shutil.copytree(ROOT/n,CONTROL/n)
    for n in ['Cargo.toml','Cargo.lock','build.rs']:
        if (ROOT/n).exists():shutil.copy2(ROOT/n,CONTROL/n)
    p=CONTROL/'src/engine/kern/certificate_probe.rs';original=p.read_text()
    needle='let s = i64::try_from(sl).ok()?;'
    assert original.count(needle)==1
    p.write_text(original.replace(needle,'let s = i64::try_from(sl).ok()?.checked_add(1)?;'))
    run('corrupted-scale',fixture,cwd=CONTROL,target=TARGET+'-mutant',expect=101,needle='certificate fixture scale')
    p.write_text(original)
    run('restored',fixture,cwd=CONTROL,target=TARGET+'-restored',needle='1 passed')
    summary={}
    for bits in [1,2,3,4]:
        xs=[s for s in samples if s['bits']==bits];blocks=sum(s['blocks'] for s in xs);cert=sum(s['certified'] for s in xs)
        diag=[(int(a),int(b)) for a,b in re.findall(r'CERTIFICATE call=\d+ omitted_bits='+str(bits)+r' rows=\d+/\d+ blocks=\d+/\d+ stable_scales=(\d+) stable_codes=(\d+)',on)]
        summary[bits]=dict(blocks=blocks,certified=cert,fraction=cert/blocks,stable_scales=sum(a for a,b in diag),stable_codes_at_certified_scale=sum(b for a,b in diag),ideal_single_column_gate_up_plane_fraction_saved=cert/blocks*bits/8)
    receipt=dict(status=0,elapsed=time.monotonic()-start,budget=540,events=events,samples=samples,coverage=summary,
      overhead_ns=[int(x) for x in re.findall(r'CERTIFICATE_OVERHEAD call=\d+ ns=(\d+)',on)],
      population='README200 actual batched prefill,64-column groups;24 sampled columns, one from each layer across4 groups. Coverage feasibility, no runtime skipping or speedup claim.',trust='Q32 diagnostic, no production skipping. Interval containment tested, universal soundness/extraction open. Oracle reads and scalar diagnostic overhead excluded from claimed savings.',
      identity={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [ROOT/'src/engine/kern/gemm.rs',ROOT/'src/engine/kern/certificate_probe.rs',ROOT/'examples/quant_certificate.rs',pathlib.Path(binary),pathlib.Path(model),pathlib.Path(ids)]})
    (LOG/'receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(summary),flush=True)
except BaseException as e:
    (LOG/'failure.json').write_text(json.dumps(dict(elapsed=time.monotonic()-start,events=events,error=str(e)),indent=2));raise
