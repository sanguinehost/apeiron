# Undispatched prefill follow-up

User stop applies. No new edits or gates.

Proposed test task owns src/engine/step/spec.rs only, retains attn/mixer live-state comparators, starts both arms from actual empty constructors. Compare actual compose_cols widths1/2/4/8/32/64/128/256 against one-column ordered execution on200 tokens, including partial tails; compare each hidden output and full live state at every boundary. Public prefill_cols/prefill_state final head and continuation remain required. In a disposable source copy, omit the last input of multi-column compose_cols; require live-state rejection and restoration. Gate MISSING, budget540 seconds for both carriers and controls. No acceptance claim.

Structural follow-up after that gate: delta_heads_cols_impl clones StagedConv before read-only pooled f32 execution, copying k*channels staged floats and persistent convolution history. Borrowing the staged mutex guard through processing and dropping it before cache clear could remove that transient copy while preserving numeric order and error semantics. Candidate scope mixer.rs plus focused spec.rs tests. This is an unmeasured source seam, not an expected speedup. Exact-ring recurrence laws do not license float reassociation.
