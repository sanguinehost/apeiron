import pathlib, subprocess, time, os, json, hashlib, shutil, signal
root=pathlib.Path('/home/socol/oc-tmp/decode-dispatch/worktree-agent-APEIRON-STRUCTURAL-SPIKE-selective-state')
logs=pathlib.Path('/tmp/opencode/structural-dispatch/selective-state')
copy=pathlib.Path('/home/socol/oc-tmp/decode-dispatch/control-selective-state')
start=time.monotonic(); records=[]
baseenv=os.environ.copy();baseenv.update(APEIRON_STATE_MODEL='/home/socol/models/qwen3.5-0.8b/Qwen3.5-0.8B-Q8_0.gguf',APEIRON_STATE_IDS='/home/socol/Workspace/apeiron/tests/fixtures/qwen35-prompt2.ids',APEIRON_THREADS='24',APEIRON_EXACT_SCAN='0',APEIRON_PREFILL_BLOCK='32')
def run(name,cwd,target,carrier):
    env=baseenv.copy();env['CARGO_TARGET_DIR']=target;env['APEIRON_F32_CARRIER']=carrier
    command=['cargo','test','--release','--locked','--lib','selective_live_state_boundaries','--','--nocapture','--test-threads=1']
    before=time.monotonic();remaining=530-(before-start)
    if remaining<=0:raise TimeoutError('whole invocation budget')
    p=subprocess.Popen(command,cwd=cwd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,start_new_session=True)
    try:output,_=p.communicate(timeout=remaining)
    except subprocess.TimeoutExpired:
        os.killpg(p.pid,signal.SIGKILL);output,_=p.communicate();(logs/(name+'.log')).write_bytes(output);raise
    (logs/(name+'.log')).write_bytes(output);records.append(dict(name=name,exit=p.returncode,elapsed=time.monotonic()-before,command=command,cwd=str(cwd),target=target,carrier=carrier));print(records[-1],flush=True)
    return p.returncode,output.decode(errors='replace')
try:
    for c in ['0','1']:
        code,output=run('baseline-'+c,root,'/home/socol/oc-tmp/decode-dispatch/target-selective-state',c)
        assert code==0,output[-4000:]
        assert 'STATE actual lookup:' in output and '1 passed' in output
    assert not copy.exists(),'control directory already exists'
    copy.mkdir()
    for d in ['src','derive','fold-abi','examples','tests']:
        if (root/d).exists():shutil.copytree(root/d,copy/d)
    for f in ['Cargo.toml','Cargo.lock','build.rs']:
        if (root/f).exists():shutil.copy2(root/f,copy/f)
    p=copy/'src/engine/step/spec.rs';saved=p.read_bytes();text=saved.decode()
    needle='let _ = self.compose_cols(&mut st.kv, st.affine.as_mut(), &tokens[1..accepted + 1],\n                        Sched::Resident, KernelMode::Q8Act, true, None)?;'
    assert text.count(needle)==1
    p.write_text(text.replace(needle,'let _ = &tokens; // mutation: omitted accepted-prefix replay'))
    code,output=run('omitted-replay',copy,'/home/socol/oc-tmp/decode-dispatch/target-selective-state-mutant','0')
    assert code!=0 and 'live-state KV metadata' in output,output[-4000:]
    p.write_bytes(saved)
    code,output=run('restored',copy,'/home/socol/oc-tmp/decode-dispatch/target-selective-state-restored','0')
    assert code==0 and 'STATE actual lookup:' in output
    status='passed'
except BaseException as e:
    status='failed';error=repr(e);print(error,flush=True)
finally:
    files={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for d in ['src','derive','fold-abi'] for p in (root/d).rglob('*.rs')}
    receipt=dict(status=status,elapsed=time.monotonic()-start,budget=540,records=records,source_sha256=files,model_sha256=hashlib.sha256(pathlib.Path(baseenv['APEIRON_STATE_MODEL']).read_bytes()).hexdigest(),fixture_sha256=hashlib.sha256(pathlib.Path(baseenv['APEIRON_STATE_IDS']).read_bytes()).hexdigest())
    if status!='passed':receipt['error']=error
    (logs/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print('GATE',status,receipt['elapsed'],flush=True)
    if status!='passed':raise SystemExit(1)
