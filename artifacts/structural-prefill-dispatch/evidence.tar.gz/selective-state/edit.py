from pathlib import Path
root=Path('/home/socol/oc-tmp/decode-dispatch/worktree-agent-APEIRON-STRUCTURAL-SPIKE-selective-state')
p=root/'src/engine/attn.rs';s=p.read_text();idx=s.index('    /// Rewind every layer to `m` positions.')
s=s[:idx]+'''    /// Diagnostic equality of geometry, capacity, occupancy and all live KV rows.
    /// Time: O(live KV words) comparisons; space: O(1). Rows beyond occupancy are
    /// excluded: append overwrites a whole row before increasing occupancy, and attention
    /// rejects a position at or beyond occupancy. Successful continuation checks this boundary.
    pub(crate) fn probe_assert_live_eq(&self, other: &Self) {
        assert_eq!((self.carrier, self.n_layer, self.n_head, self.n_head_kv,
            self.head_dim, self.cap, self.scale, &self.occupied),
            (other.carrier, other.n_layer, other.n_head, other.n_head_kv,
            other.head_dim, other.cap, other.scale, &other.occupied), "live-state KV metadata");
        for layer in 0..self.n_layer {
            let end = self.occupied[layer] * self.n_head_kv * self.head_dim;
            match (&self.storage, &other.storage) {
                (KvStorage::Q32 { k, v }, KvStorage::Q32 { k: ok, v: ov }) => {
                    assert!(k[layer][..end] == ok[layer][..end], "live-state KV key layer {layer}");
                    assert!(v[layer][..end] == ov[layer][..end], "live-state KV value layer {layer}");
                }
                (KvStorage::F32 { k, v }, KvStorage::F32 { k: ok, v: ov }) => {
                    assert!(k[layer][..end].iter().zip(&ok[layer][..end]).all(|(a,b)| a.to_bits()==b.to_bits()), "live-state KV f32 key layer {layer}");
                    assert!(v[layer][..end].iter().zip(&ov[layer][..end]).all(|(a,b)| a.to_bits()==b.to_bits()), "live-state KV f32 value layer {layer}");
                }
                _ => panic!("live-state KV carrier"),
            }
        }
    }

'''+s[idx:];p.write_text(s)
p=root/'src/engine/mixer.rs';s=p.read_text();idx=s.index('impl Clone for AffineLayer {');s=s[:idx]+'''impl AffineLayer {
    /// Diagnostic equality of persistent convolution and recurrent state.
    /// Time: O(convolution words + head state words) comparisons; space: O(1).
    /// Staged convolution/readout caches are excluded: the next convolution overwrites
    /// them before delta_heads reads them. Packed weight caches contain immutable weights.
    pub(crate) fn probe_assert_live_eq(&self, other: &Self, layer: usize) {
        assert_eq!((self.slices, self.heads.len()), (other.slices, other.heads.len()), "live-state affine shape layer {layer}");
        match (&self.conv, &other.conv) {
            (ConvState::Q32(a), ConvState::Q32(b)) => assert!(a == b, "live-state conv q32 layer {layer}"),
            (ConvState::F32(a), ConvState::F32(b)) => assert!(a.len()==b.len() && a.iter().zip(b).all(|(x,y)| x.to_bits()==y.to_bits()), "live-state conv f32 layer {layer}"),
            _ => panic!("live-state conv carrier layer {layer}"),
        }
        for (head, (a,b)) in self.heads.iter().zip(&other.heads).enumerate() {
            let a=a.lock().unwrap_or_else(std::sync::PoisonError::into_inner);
            let b=b.lock().unwrap_or_else(std::sync::PoisonError::into_inner);
            match (&a.state, &b.state) {
                (HeadState::Q32 {s, c}, HeadState::Q32 {s: os, c: oc}) => {
                    assert_eq!(c, oc, "live-state deferred decay layer {layer} head {head}");
                    assert!(s==os, "live-state accumulator layer {layer} head {head}");
                }
                (HeadState::F32 {s}, HeadState::F32 {s: os}) => assert!(s.len()==os.len() && s.iter().zip(os).all(|(x,y)| x.to_bits()==y.to_bits()), "live-state accumulator f32 layer {layer} head {head}"),
                _ => panic!("live-state head carrier layer {layer} head {head}"),
            }
        }
    }
}

'''+s[idx:];p.write_text(s)
p=root/'src/engine/step/spec.rs';s=p.read_text();s=s.replace('        let started = std::time::Instant::now();\n        while out.len() < n {','''        let mut reference = (std::env::var("APEIRON_LOOKUP_STATE_CHECK").as_deref() == Ok("1")).then(|| st.clone());
        let oracle = reference.is_some() && std::env::var("APEIRON_LOOKUP_ORACLE").as_deref() == Ok("1");
        let started = std::time::Instant::now();
        while out.len() < n {''');s=s.replace('            if draft.is_empty() {\n                stats[2]', '''            if oracle && min_suffix != 1024 {
                draft.clear();
                let mut proposed_state = reference.as_ref().expect("diagnostic reference").clone();
                let mut token = x;
                for _ in 0..(width - 1).min((n - out.len()).saturating_sub(1)) {
                    token = self.next_token_state(&mut proposed_state, token, KernelMode::Q8Act)?;
                    draft.push(token);
                }
            }
            if draft.is_empty() {
                let input = x;
                stats[2]''');s=s.replace('                context.push(x);\n                continue;', '''                context.push(x);
                if let Some(ref mut r) = reference {
                    assert_eq!(self.next_token_state(r, input, KernelMode::Q8Act)?, x, "live-state miss token");
                    assert_live_decode_eq(&st, r);
                }
                continue;''');s=s.replace('            out.extend(&draft[..accepted]);','''            if let Some(ref mut r) = reference {
                for (column, &input) in tokens[..accepted + 1].iter().enumerate() {
                    assert_eq!(self.next_token_state(r, input, KernelMode::Q8Act)?, t[column], "live-state committed token column {column}");
                }
                assert_live_decode_eq(&st, r);
            }
            out.extend(&draft[..accepted]);''');s+='''
// Time: O(live decode-state words), delegated to exact component comparisons; space: O(1).
fn assert_live_decode_eq(a: &super::DecodeState, b: &super::DecodeState) {
    a.kv.probe_assert_live_eq(&b.kv);
    match (&a.affine, &b.affine) {
        (Some(a), Some(b)) => {
            assert_eq!(a.layers().len(), b.layers().len(), "live-state affine layer count");
            for (layer, (a,b)) in a.layers().iter().zip(b.layers()).enumerate() {
                a.probe_assert_live_eq(b, layer);
            }
        }
        (None, None) => (),
        _ => panic!("live-state affine presence"),
    }
}

#[cfg(test)]
mod selective_state_tests {
    use super::*;
    #[test]
    fn selective_live_state_boundaries() {
        let model = std::env::var("APEIRON_STATE_MODEL").expect("real model required");
        let engine = Engine::open(&model).expect("open model");
        let prompt: Vec<u32> = std::fs::read_to_string(std::env::var("APEIRON_STATE_IDS").expect("fixture required"))
            .expect("read fixture").split_whitespace().map(|s| s.parse().expect("token id")).collect();
        std::env::set_var("APEIRON_LOOKUP_STATE_CHECK", "1");
        let a=engine.state(prompt.len()+68).expect("constructor");
        let b=engine.state(prompt.len()+68).expect("constructor");
        assert_live_decode_eq(&a, &b);
        assert!(matches!(engine.probe_lookup_decode(&[],16,2,4), Err(StepError::BadConfig("empty prompt"))));
        assert!(matches!(engine.probe_lookup_decode(&prompt,16,2,5), Err(StepError::BadConfig("probe width outside 2..=4"))));
        assert!(engine.probe_lookup_decode(&[engine.config.vocab_size as u32],16,2,4).is_err(), "out-of-vocabulary embedding refusal");
        assert_eq!(engine.probe_lookup_decode(&prompt,0,2,4).expect("empty result").0.len(),0);
        std::env::set_var("APEIRON_LOOKUP_ORACLE", "1");
        let (reference, all, _) = engine.probe_lookup_decode(&prompt,16,2,4).expect("all accept");
        assert!(all[0]>0 && all[1]==3*all[0] && all[3]==0, "all-accept witness {all:?}");
        for index in 0..3 {
            std::env::set_var("APEIRON_LOOKUP_CORRUPT",index.to_string());
            let (ids,stats,_) = engine.probe_lookup_decode(&prompt,16,2,4).expect("forced rejection");
            assert_eq!(ids,reference,"forced rejection continuation {index}");
            assert!(stats[0]>0, "rejection witness");
            if index==0 { assert_eq!(stats[1],0); assert_eq!(stats[3],0); }
            else { assert!(stats[1]>0 && stats[3]>0, "later-rejection replay witness {stats:?}"); }
            println!("STATE forced rejection {index}: {stats:?}");
        }
        std::env::remove_var("APEIRON_LOOKUP_CORRUPT");
        std::env::remove_var("APEIRON_LOOKUP_ORACLE");
        let (ids,stats,_) = engine.probe_lookup_decode(&prompt,16,1024,4).expect("miss only");
        assert_eq!(ids,reference); assert_eq!(stats[0],0); assert_eq!(stats[2],15);
        let (_,stats,_) = engine.probe_lookup_decode(&prompt,64,2,4).expect("actual lookup state");
        assert!(stats[0]>0, "lookup witness");
        println!("STATE actual lookup: {stats:?}; live KV and affine boundaries passed");
    }
}
''';p.write_text(s)
