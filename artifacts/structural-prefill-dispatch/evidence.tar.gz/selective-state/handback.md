# Selective state comparison

Task: APEIRON-STRUCTURAL-SPIKE-selective-state. Owner: selective_state. Base: 3f29041 plus the lead-staged lookup helper and example; baseline.json records incoming digests. Private worktree: /home/socol/oc-tmp/decode-dispatch/worktree-agent-APEIRON-STRUCTURAL-SPIKE-selective-state. Shared lanes untouched.

SCOPE: src/engine/step/spec.rs, src/engine/mixer.rs, src/engine/attn.rs; diagnostic live-state equality at committed lookup boundaries, forced rejection and continuation controls.
REGISTER: state/test; numeric changes, performance claims and source refinement excluded.
CORPUS: SpeculativeRollback.spec_round_state_eq_greedy states returned model state equals greedyRun state; JacobiDecode.verify_accept_prefix states accepted tokens equal a greedy prefix. Model pointers only; no Lean gate ran.
REFERENCE: /home/socol/oc-tmp/decode-dispatch/worktree-agent-APEIRON-STRUCTURAL-SPIKE-selective-state/src/engine/step/spec.rs, read.
GATE: initially MISSING; written gate.py in this directory. timeout --kill-after=5 540 python3 /tmp/opencode/structural-dispatch/selective-state/gate.py; exact cwd, environment, commands and elapsed in receipt.json.
GRADE: tested only if receipt.json status is passed; no new proved or measured-performance result.

Observation set:

- KV carrier, geometry, capacity, scale, per-layer occupancy, every occupied key/value element. F32 elements compared by to_bits.
- Affine layer count, slice count, head count, complete persistent convolution history, every head accumulator, every Q32 deferred decay. F32 elements compared by to_bits.
- Every committed column's actual greedy token, and subsequent state/token continuation through all later rounds.

Excluded storage:

- Unoccupied KV tail. attn.rs append overwrites an entire row before advancing occupancy; attn_head rejects positions outside occupancy. Subsequent successful decode exercises overwrite and read. Refusing append branches are not a rollback claim.
- Staged convolution and readout scratch. mixer.rs refreshes them from the new inputs before delta_heads reads them; clone_from invalidates staged data/readout count. Packed convolution weights are immutable derived caches. Their representation is not compared; continuation is compared.
- Physical allocation identities, spare Vec capacity, mutex/atomic internals, worker scheduling and external codegen/ABI/GPU/unsafe-container correctness.

Fixtures:

- Strict actual GGUF open and fixture read, no missing-model skip. Initial states from two actual constructors compare.
- Empty prompt and width5 refuse with BadConfig; out-of-vocabulary prefill refuses; n0 returns an empty result.
- Diagnostic oracle draft, used only with state-check flag, gives reachable all-accept and first/second/third draft rejection fixtures. Ordinary greedy execution constructs each draft; corruptions change the selected draft token. Forced rejections continue for16 emitted tokens.
- Suffix1024 misses throughout15 steps. Actual suffix2/width4 lookup runs64 emitted tokens with diagnostic state checking at every commit.
- Omitted-prefix replay mutation removes the real compose_cols call in a complete disposable source copy. Distinct baseline, mutant and restored Cargo targets avoid cached-source restoration errors. The intended red is a live-state KV metadata mismatch at a later rejection, before outer token-output comparison.

No numeric kernels, recurrence order, rounding, tie rules, premises or pins changed. Source is a diagnostic candidate; full Rust tests/clippy/fmt, Aeneas extraction/link, bounded Lean builds and integration acceptance remain open. The inherited unrelated table test warning is retained in logs. Root and webfold VOICE copies were absent; existing song/VOICE.md was read as the supplied fallback.

Next bounded prefill task: reuse KvState::probe_assert_live_eq and AffineLayer::probe_assert_live_eq in the known-token column executor. Construct two empty states with the same capacity. Execute each prompt chunk through the actual compose_cols path on one state; execute those exact tokens as one-column compose_cols calls on the other. Compare live components at every chunk boundary and compare every column's returned hidden state, without using generated draft tokens. Register chunk lengths1/2/4/8/32/64, partial final chunks, both carriers and refusal/overflow controls. This current decode gate does not establish constructor-to-prefill one-column equivalence: both decode arms start from the same cloned completed prefill.

Question to lead: retain these diagnostic comparators for the prefill chunk/state gate, with scratch observation exclusions unchanged, before assigning any new carrier or composition rewrite?
