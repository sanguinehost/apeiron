from pathlib import Path
root=Path('/home/socol/oc-tmp/decode-dispatch/worktree-agent-APEIRON-STRUCTURAL-SPIKE-benchmarks')
p=root/'examples/lookup_probe.rs'
s=p.read_text()
s=s.replace('// Check mode runs actual greedy', '''// Time: one full prompt execution; state allocation and model loading are excluded.
// Space: the executing KV/recurrent state and projection buffers.
fn prefill(engine: &Engine, prompt: &[u32]) -> Result<(u32, u128), Box<dyn Error>> {
    let mut state = engine.state(prompt.len() + 5)?;
    let started = Instant::now();
    let token = engine.prefill_state(&mut state, prompt, KernelMode::Q8Act)?;
    Ok((token, started.elapsed().as_nanos()))
}

// Check mode runs actual greedy''')
s=s.replace('if args[3] == "check" {','''if args[3] == "pp" {
        let warm = prefill(&engine, &prompt)?;
        let measured = prefill(&engine, &prompt)?;
        assert_eq!(warm.0, measured.0, "fresh prefill token");
        println!("PREFILL {} {} {}", prompt.len(), measured.1, measured.0);
    } else if args[3] == "check" {''')
p.write_text(s)
p=root/'examples/llama_context.cpp'
s=p.read_text()
s=s.replace('int nv, int n) {','int nv, int n, bool pp) {')
s=s.replace('    for(size_t offset=0;offset<prompt.size();offset+=512) {','    auto prefill_start=std::chrono::steady_clock::now();\n    for(size_t offset=0;offset<prompt.size();offset+=512) {')
s=s.replace('    std::vector<llama_token> ids{x};ids.reserve(n);','''    std::vector<llama_token> ids{x};ids.reserve(n);
    if(pp) {
        double ns=std::chrono::duration<double,std::nano>(std::chrono::steady_clock::now()-prefill_start).count();
        return {ids,ns};
    }''')
s=s.replace('if(argc!=5)', 'if(argc!=5 && argc!=6)')
s=s.replace('    int n=std::stoi(argv[4]);if(n<2)throw std::runtime_error("n below2");','''    bool pp=argc==6 && std::string(argv[5])=="pp";
    int n=std::stoi(argv[4]);if(n<(pp?1:2))throw std::runtime_error("invalid generation count");''')
s=s.replace('sample(ctx,prompt,nv,n)', 'sample(ctx,prompt,nv,n,pp)')
s=s.replace('    std::cout<<"SAMPLE "<<measured.second<<" [";','''    if(pp) {
        std::cout<<"PREFILL "<<prompt.size()<<" "<<static_cast<long long>(measured.second)<<" "<<measured.first[0]<<"\\n";
        llama_free(ctx);llama_model_free(model);llama_backend_free();return 0;
    }
    std::cout<<"SAMPLE "<<measured.second<<" [";''')
p.write_text(s)
