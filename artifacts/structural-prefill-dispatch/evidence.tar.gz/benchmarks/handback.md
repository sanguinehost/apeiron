# Prefill benchmark draft

Owner: lead. Base: 3f29041c23697ab7aebab23da95fa900d3ff27b4 plus incoming lookup helper; baseline.json records staged source. User stops this dispatch after agent handbacks.

Owned files: examples/lookup_probe.rs; examples/llama_context.cpp; tools/structural_decode_bench.py. They are unbuilt and unrun. No acceptance or performance result follows.

The Rust and C++ pp modes time actual full prompt processing and one final greedy head. State/context allocation, reset and model loading are excluded. Both warm an identical execution and compare the next-token ID between warm and measured fresh states. The C++ prompt batch/ubatch is512 with f16 KV, flash auto, CPU-only. Rust prefill columns64, performance participants8 plus detected efficiency workers. The draft runner rotates five rounds, sweeps comparator threads8/16/24/32, retains first-token divergence, rejects a count mutation and invalid IDs, and requires host busy<5% before each sample. It requires a four-case immutable protocol with exact fixture digests; that protocol and fixtures are not written. The benchmark has not reached its gate-first exit.

Next bounded task: compile both probes, create/read same-GGUF code/prose fixtures at200 and1024 tokens, register the four-case protocol and run controls plus all five rounds under one540-second invocation on a quiet host. Source/API compile errors, prompt/ID differences and budget/quiet failures remain possible. No general2x result is established. The source-only draft is retained for continuation rather than integrated.
